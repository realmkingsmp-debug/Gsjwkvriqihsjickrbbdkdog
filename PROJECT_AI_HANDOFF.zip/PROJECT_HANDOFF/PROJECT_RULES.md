# PROJECT_RULES (dauerhafte Regeln)

1. **Keine Komplett-Rewrites.** Bestehende Module erweitern; funktionierende
   Features erhalten.
2. **Deliverables nur in `ysm-studio/pakete/`.** Niemals Ordner mit Namen
   `out/`, `dist/`, `build/`, `target/`, `coverage/`, `node_modules/` für
   Ergebnisse nutzen (Workspace-Snapshot verwirft sie – bereits passiert, BUG-006).
3. **Validator-first.** Nach JEDER Änderung: `verify.py`, `verify_bedrock.py`,
   `schema_check.py` ausführen; zusätzlich Front-Render (`character_front.png`)
   und bei Positionsänderungen Seiten-Render prüfen.
4. **YSM-Required-Bone-Namen nicht ändern** (`REQUIRED_BONES` in `ysm_gen.py`):
   Root, AllBody, UpBody, UpperBody, DownBody, AllHead, Head, Arm, LeftArm,
   LeftForeArm, LeftHandLocator, RightArm, RightForeArm, RightHandLocator,
   LeftLeg, LeftLowerLeg, RightLeg, RightLowerLeg. Zusätzliche Bones erlaubt.
5. **`mirror: true` spiegelt NUR UVs.** Rechte Körperhälfte immer mit explizit
   negativen x-Koordinaten bauen (BUG-002/011).
6. **Bedrock-Wrapper ohne `minecraft:`-Präfix** für `render_controllers` und
   `animation_controllers` (Vanilla-Format); `minecraft:entity`,
   `minecraft:client_entity`, `minecraft:geometry` MIT Präfix.
7. **`minecraft:scale` immer als Objekt** (`{"value": …}`), nie als Zahl.
8. **Box-UV** (`"uv":[u,v]`) verwenden; kein per-face-UV mit identischem
   Ursprung pro Fläche (BUG-007).
9. **Keine Secrets speichern oder nutzen.** Nutzer-Token sind widerrufen/
   wertlos; alles mit unauthentifizierter API bzw. lokal arbeiten.
10. **Keine Fremd-Assets in Deliverables.** Eigenes Design; gesammelte YSM-
    Modelle von Elaina69 bleiben unberührt (Lizenz-/Herkunftslage unklar).
11. **Credit „by Jan Wolf"** in jeder neuen Ausgabe (ysm.json, CREDITS.txt,
    Manifest-Description, en_US.lang, bbmodel-Name, Dateiname).
12. **Addon-Icon IMMER per Bildgenerator** erzeugen (2 Optionen anbieten,
    Auswahl in `assets/pack_icon.png`, 512x512 in beide Packs).
13. **Ehrlichkeit über Testgrenzen:** Ingame-Tests sind Umgebung-unmöglich;
    dem Nutzer nie vorspielen, etwas sei „im Spiel getestet".
14. **Keine Piraterie/Malware-Quellen** (MediaFire-Cracks etc.) – offizielle
    Quellen nutzen; wenn blockiert, dokumentieren und Alternative wählen.
15. **Änderungen im CHANGELOG.md** (Projekt-Ordner ysm-studio/CHANGELOG bzw.
    Handoff-CHANGELOG) dokumentieren.
16. **Backward Compatibility:** Pack-UUIDs fest (nicht regenerieren), Versions-
    bumps nur bei inhaltlichen Änderungen (Bedrock zieht sonst Updates nicht).
17. Vor größeren Änderungen: DECISIONS.md lesen; Entscheidungen nur mit
    dokumentiertem Grund ändern.
