# SECURITY

## Status
- **Keine Secrets im ZIP.** Vollständiger Scan aller Handoff-Dateien: einziger
  Treffer = `elaina/analyze.py` enthält **Secret-Erkennungs-Regexe** (Strings
  wie `gh[pousr]_…`), keine echten Credentials.
- Das Projekt betreibt keinen Server, speichert keine Passwörter, verarbeitet
  keine Nutzerdaten – keine Angriffsoberfläche im klassischen Sinn.

## Vorfall (dokumentiert)
- Nutzer teilte im Chat einen GitHub-PAT (`ghp_…`) mit der Bitte, Repos auf
  seinen Account zu spiegeln. Der Token wurde **nicht gespeichert** und die
  Anfrage abgelehnt (Entscheidung D-04).
- Empfehlung an Nutzer (weiterhin offen): Token in GitHub-Settings widerrufen.
  Status beim Nutzer: UNKNOWN.

## Risiken & Maßnahmen
| Risiko | Einschätzung | Maßnahme |
|---|---|---|
| Weitergabe eigener PATs an KI-Dienste | hoch (Rotation nötig) | niemals speichern; widerrufen |
| GitHub-API-Rate-Limit ohne Token (60/h) | niedrig | Batch-Dateien, Subtree-Filter (msamples.json) |
| Schema-Check lädt remote $refs | niedrig (nur GET, read-only) | raw.githubusercontent, optional offline einfrieren |
| Fremd-Code aus Elaina69-Klonen | mittel (unauditierte Third-Party-Skripte) | Klone NIE ausführen; nur statische Analyse |
| Generierte Pakete in Minecraft | niedrig | eigene Assets; BP-Entity ohne schädliche Komponenten |
| `elaina/repos` enthält LoL-Client-Mods | ToS-Grauzone beim *Nutzer*, nicht hier | keine Weiterverwendung (Regel 10) |

## Vorgaben für zukünftige Arbeit
- Keine Tokens/Passwörter in Code, Paketen, Doku oder Chat-Antworten.
- Platzhalter-Beispiel liegt bei: `.env.example` (nur `GITHUB_TOKEN=`).
- Falls je Authentifizierung nötig: Umgebung, nie Datei im Projekt.
