# DATABASE

> Es gibt **keine Datenbank** (kein SQL/NoSQL, keine ORM, keine Migrationen).
> Alle Daten sind Dateien auf Platte. Dieses Dokument beschreibt den Datenstand.

## Datenbestände

| Pfad | Inhalt | Quelle/Stand |
|---|---|---|
| `elaina/data/user.json` | Account-Metadaten Elaina69 | GitHub API, 2026-09-23 |
| `elaina/data/repos_p1.json` | 36 Repos (Seite 1, per_page=100) | GitHub API |
| `elaina/data/stars_p1.json` | 11 Sterne | GitHub API |
| `elaina/data/gists.json` | 3 Gists | GitHub API |
| `elaina/data/analyse_raw.json` | Lokale Analyse der Klone (Dateien/Zeilen/Sprachen/Secrets/READMEs) | analyze.py |
| `elaina/data/stars_lang/*.json` | Sprachen je Stern-Repo | GitHub API (Sprache-Feld) |
| `elaina/out_repos.csv` | 35 Repos (Skadi-Theme 404) | Endstand Analyse |
| `elaina/out_stars.csv` | 11 Sterne | Endstand |
| `elaina/repos/` | 35 shallow-Klone, **bereinigt** (Großdateien & .git entfernt; `Skadi-Theme` fehlt) | bei Bedarf: `elaina/clone_all.sh` |
| `ysm-studio/assets/pack_icon.png` | Gewähltes KI-Icon 1024² | Bildgenerator, Auswahl durch Nutzer |
| `ysm-studio/pakete/**` | Alle Builds/Render/Showcase | Generatoren |
| `/tmp/msamples.json`, `/tmp/cow_bp.json` | Vanilla-Formatreferenzen | NICHT persistent (tmp) – bei Bedarf neu von `raw.githubusercontent.com/Mojang/bedrock-samples` laden |

## Konsistenzregeln
- `report.html`-Tabelle wurde gegen `out_repos.csv` verifiziert (35/35, Summen
  inkl. Tausender-Separator) – Regenerierung nur über `build_report.py`.
- YSM-Paket und mcaddon sind generiert: Quelle der Wahrheit sind die Python-
  Dateien; Pakete nie von Hand editieren, sonst Drift zum Generator.
- Pack-UUIDs sind fest in `build_bedrock.py`; Änderungen brächen Update-Pfade.

## Backups/Wiederherstellung
- Alles unter `/home/user` ist der Workspace-Snapshot (ausgenommen u. a. `out/`,
  `dist/`, `.git`, `__pycache__`).
- `elaina/repos` rekonstruierbar via `clone_all.sh` (Internet + Rate-Limit).
- Keine externen Backups/Clouds konfiguriert.
