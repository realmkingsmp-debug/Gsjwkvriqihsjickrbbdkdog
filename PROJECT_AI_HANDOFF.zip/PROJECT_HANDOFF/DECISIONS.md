# DECISIONS

| # | Entscheidung | Begründung | Alternative(n) |
|---|---|---|---|
| D-01 | Deliverables als **ZIP** (YSM), nicht `.ysm` | `.ysm`-Format verschlüsselt („crypto 3"), ohne Mod-Quellcode nicht erzeugbar; ZIP wird von YSM offiziell importiert | .ysm-Reverse (aufgegeben) |
| D-02 | Bedrock als **beschwörbare Entity**, kein Spieler-Skin | Eigene Geometrie ist als Skin offiziell nicht möglich; Entity liefert volle Kontrolle (Animationen, Größe) | Marketplace-Skin (kostenpflichtig, fremde Tools) |
| D-03 | Credit **„by Jan Wolf"** in ysm.json (authors/tips), CREDITS.txt, bbmodel-Name, Manifesten, en_US.lang | Nutzer-Anforderung (Markenzeichen) | – |
| D-04 | **Kein Push/Spiegelung** auf Nutzer-GitHub | Abgelehnt: kein Platzgewinn, Fremdinhalt, Abuse-Risiko; Token verbrannt | GitHub-Import (abgelehnt) |
| D-05 | **Box-UV**, 512²-Atlas mit 256er-UV-Raum | Bedrock-Standard; Faktor 2 = doppelte Texeldichte ohne UV-Neubau | per-face-UV (Fehleranfällig, BUG-007) |
| D-06 | Feste **Pack-UUIDs** + RP↔BP-Dependencies | Update-Fähigkeit der Packs in bestehenden Welten | zufällige UUIDs (bricht Updates) |
| D-07 | Addon-Icon **immer per Bildgenerator**, 2 Optionen, Nutzer wählt | Nutzer-Vorgabe (stehend); Konsistenz über künftige Add-ons | gezeichneter Fallback (nur wenn Generator ausfällt) |
| D-08 | **Validator-first**: 3-stufiges Gate (40+46+Schema-Checks) | Runtime-Test unmöglich; statische Prüfung fand alle Ingame-Bugs | nur manueller Test (abgelehnt) |
| D-09 | Controller-Wrapper **ohne** `minecraft:`-Präfix | Vanilla-Beispiele (allay) verifiziert; mit Präfix = unsichtbar (BUG-001) | – |
| D-10 | `minecraft:scale` als **Objekt** `{"value": …}` | cow.json (1.26.10) verifiziert; Zahl = Entity-Fehler | – |
| D-11 | Deliverables nur in **`pakete/`** | Snapshot verwirft `out/`, `dist/`, `build/` (BUG-006) | – |
| D-12 | **Keine Fremd-Assets** (Elaina69-Sammlung bleibt unangetastet) | Lizenz unklar, Respekt vor Dritt-Content | Remix (abgelehnt) |
| D-13 | `elaina/repos/` (61 MB) **aus ZIP ausgeschlossen** | Größe; via `clone_all.sh` rekonstruierbar | Vollkopie (verworfen) |
| D-14 | Design **Amethyst-Anime-Drachenmädchen** | Nutzer-Wahl aus 3 Vorschlägen | Cyan-Roboter, Smarald-Knight (abgelehnt) |
| D-15 | Scope: **ein Charakter richtig** statt viele mittelmäßige | Nutzer-Wahl | – |
| D-16 | Offizielle Quellen only (MediaFire-Crack abgelehnt; BDS-Blockade akzeptiert) | Legalität/Malware-Risiko; statische Validatoren als Ersatz | – |
