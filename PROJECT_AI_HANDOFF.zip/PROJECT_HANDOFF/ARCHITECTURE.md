# ARCHITECTURE

## 1) ysm-studio (Generator-Kit)

```
assets/pack_icon.png   (vom Nutzer gewähltes KI-Icon, 1024², wird auf 512² skaliert)
        │
textures.py  Atlas-Painter: reserviert Box-UV-Regionen im 256er-Raum, malt auf
        │    512²-PNG (S=2 → 2 Texel/Einheit in Bedrock); liefert (png, origins, dims)
        ▼
dragon_girl.py  Geometrie v2: 52 Bones / 45 Cubes, baut auf YSM-Kernskelett;
        │       Rotationen für Schwanzbogen, Zopf, Flügel, Rock-Flare, Hörner
        ▼
ysm_gen.py  Model/Bone-Datenklassen, REQUIRED_BONES, validate() (Box-UV+per-face),
        │   idle/walk-Animationen (Molang 1.8.0), ysm.json-Spec-2-Writer
        ├──▶ build.py        → pakete/DragonGirl_by_JanWolf.zip   (YSM, Textur 256-Downscale)
        │                    → pakete/….bbmodel                   (box_uv=true, Textur Base64)
        │                    → preview.png, avatar.png, character_front.png, model_preview.svg
        ├──▶ build_bedrock.py→ pakete/bedrock/…_RP.mcpack / _BP.mcpack / .mcaddon
        │                    (Manifest v2, Dependencies RP<->BP, Icon 512², min_engine 1.16)
        └──▶ make_preview_html.py → pakete/showcase.html (self-contained, Data-URIs)

Quality-Gate: verify.py (40) · verify_bedrock.py (46) · schema_check.py (8 Dateien
              gegen Blockception-Schemas, $refs live aufgelöst)
```

### Erzeugte Formate (reverse-engineered, verifiziert)
- **YSM-ZIP:** `ysm.json` spec 2 (`files.player.texture` = LISTE `[{"uv": …}]`!),
  `models/main.json` (Bedrock-Geometry 1.12.0, Box-UV), `models/arm.json`
  (32×32), `animations/main.animation.json`, `textures/default.png`,
  `avatar/*.png`, `CREDITS.txt`. `.ysm` = UTF-8-BOM + „YSGP" + Metadaten +
  verschlüsselter Payload (`<crypto> 3`) → NICHT erzeugbar.
- **Bedrock-RP:** manifest v2 · `entity/*.entity.json` (1.10.0, material
  `entity_alphatest`, spawn_egg-Farben) · `models/entity/*.geo.json` ·
  `animations/` (IDs `animation.dragon_girl.*`) · `animation_controllers/`
  (Wrapper OHNE Präfix; idle<->walk über `query.modified_move_speed`) ·
  `render_controllers/` (Wrapper OHNE Präfix) · `texts/en_US.lang` ·
  `pack_icon.png`.
- **Bedrock-BP:** manifest v2 (dependency auf RP-UUID) · `entities/*.behavior.json`
  (1.16.0; health 20, collision 0.6×2.0, scale-Objekt 0.75, navigation.walk mit
  `can_walk`, nameable, random-stroll/look-AI, `is_summonable`).

### Beziehungen (Datenfluss)
Nutzerwunsch → dragon_girl.py/textures.py (Design) → Builds → Validatoren →
pakete/ → Nutzer (Import in Minecraft/YSM/Blockbench).

## 2) elaina/ (Analyse-Pipeline, abgeschlossen)
GitHub-REST (unauthentisiert) → data/*.json → analyze.py (lokale Auswertung der
Klone: Zeilen/Dateien/Sprachen/Secrets/READMEs) → build_report.py (report.html
mit eingebauter Selbstprüfung gegen out_repos.csv) → report.md/CSVs.
`clone_all.sh` klont alle 36 Repos parallel (shallow) – wiederverwendbar.

## 3) Nicht vorhanden (bewusst/umgebungsbedingt)
Kein Web-Backend, keine Datenbank, kein Discord/RCON/Dashboard – die Vorlage
des Handoff-Masterprompts stammt aus anderem Kontext; siehe API.md/DATABASE.md.
