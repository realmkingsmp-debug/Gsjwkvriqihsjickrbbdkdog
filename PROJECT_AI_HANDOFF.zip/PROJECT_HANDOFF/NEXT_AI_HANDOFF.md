# NEXT_AI_HANDOFF — Dragon Girl / ysm-studio + Elaina69-Analyse

> ERSTE DATEI, DIE DU LIEST. Danach: PROJECT_RULES.md → DECISIONS.md → CHANGELOG.md → README.md (im Projekt).

## Projekt
Zwei zusammenhängende Arbeitsstränge in einem Workspace:

1. **elaina/** – Vollständige Analyse des GitHub-Accounts `Elaina69`
   (https://github.com/Elaina69): 36 öffentliche Repos geklont (shallow),
   11 Stern-Markierungen, 3 Gists. Ergebnis: `report.html`, `report.md`,
   `out_repos.csv`, `out_stars.csv`, Rohdaten in `data/`.
2. **ysm-studio/** – Eigenes Generator-Kit, das originale Minecraft-Charakter-
   Inhalte erzeugt: das Modell **„Dragon Girl" (Amethyst-Anime-Drachenmädchen)**
   als (a) YSM-Modell-ZIP für den Java-Mod *Yes Steve Model*, (b) Blockbench-
   Projekt `.bbmodel`, (c) **Bedrock-Add-on** `.mcaddon` (Entity
   `janwolf:dragon_girl`). Credit überall: **„by Jan Wolf"**, Lizenz CC BY-NC 4.0.

## Ziel
- Wiederholbar eigene, hochwertige Charakter-Modelle für Minecraft (Java/YSM +
  Bedrock) erzeugen können, mit generierten Icons, validiert gegen echte
  Format-Spezifikationen.
- Die Elaina69-Analyse diente als Forschungsbasis (YSM-Format reverse-
  engineered aus `Yes-Steve-Model-Repo`).

## Aktueller Stand (IMPLEMENTED, falls nicht anders markiert)
- Analyse komplett (Reports + CSVs + Roh-JSONs).
- ysm-studio-Kit komplett: Generator, Textur-Painter (512er-Atlas, 2x
  Texeldichte in Bedrock), Geometrie v2 (52 Bones/45 Cubes), Animationen v2,
  drei Validatoren (`verify.py` 40 Checks, `verify_bedrock.py` 46 Checks,
  `schema_check.py` gegen Blockception-Bedrock-Schemas, 0 Fehler).
- Deliverables in `ysm-studio/pakete/`: YSM-ZIP, .bbmodel, .mcaddon (+einzelne
  .mcpack), showcase.html, Previews, Debug-Render.
- PARTIALLY IMPLEMENTED: Ingame-Verifikation – **in dieser Umgebung nicht
  möglich** (kein Minecraft-Client; offizieller Bedrock-Dedicated-Server-
  Download wird vom CDN blockiert). Nutzer hat bestätigt: Entity ist sichtbar
  und „einigermaßen OK"; letzte Platzierungs-Fixes (Torso/Hüfte-Lücke,
  schwebender Schwanz, Rock-Panels, Lider) sind eingebaut, aber vom Nutzer
  noch nicht rückbestätigt.

## Architektur (Kurzfassung, Details in ARCHITECTURE.md)
```
textures.py  ->  dragon_girl.py  ->  build.py      -> pakete/ (YSM-ZIP, bbmodel, Previews)
                                  ->  build_bedrock.py -> pakete/bedrock/ (.mcaddon)
verify.py / verify_bedrock.py / schema_check.py  ->  Quality-Gate vor jedem Release
```
Formate: YSM-ZIP = `ysm.json` (spec 2, `texture` ist LISTE) + Bedrock-Geometry
(Box-UV!) + Molang-Animationen; `.ysm`-Dateien sind verschlüsselt (crypto 3)
und werden NICHT erzeugt (Export nur ingame per `/ysm export`).
Bedrock: RP+BP mit Manifest-Dependencies, Controller-Wrapper OHNE
`minecraft:`-Präfix (Vanilla-Format!), `scale` als Objekt.

## Wichtige Dateien
Siehe FILE_STRUCTURE.md. Kern: `ysm_gen.py` (Skelett/Validator/Animationen/
ysm.json), `textures.py` (Atlas-Painter), `dragon_girl.py` (Geometrie v2),
`build.py`, `build_bedrock.py`, die drei Validatoren, `make_preview_html.py`.

## Bereits umgesetzt
Siehe CHANGELOG.md (Phasen 1–10).

## Bekannte Probleme (Details BUGS.md)
-_runtime-Test unmöglich_ (Umgebung) → Nutzer muss ingame testen; bei Fehlern
  Content-Log-Zeilen mit `dragon_girl` anfordern.
- Workspace-Snapshots ignorieren Verzeichnisnamen wie `out/`, `dist/`,
  `build/` → Deliverables MÜSSEN in `pakete/` liegen (bereits umgestellt;
  NIEMALS wieder `out/` verwenden).
- `elaina/repos/` wurde zwischen Runden bereinigt (Großdateien/.git weg,
  `Skadi-Theme` fehlt) → bei Bedarf neu klonen mit `elaina/clone_all.sh`.

## Offene Aufgaben (Prioritäten in TODO.md)
- P1: Nutzer-Rückmeldung zu letztem Stand einholen; ggf. Feinjustierung
  (Positionen/Proportionen) – Kit erlaubt schnelle Iteration.
- P2: Zweite Farbvariante / weiterer Charakter; Sitz-/Emote-Animationen.
- P2: Nutzer muss geleakten GitHub-Token widerrufen (wurde im Chat geteilt;
  NIE gespeichert; siehe SECURITY.md).
- P3: YSM-ZIP ingame testen; Blockbench-Feinschliff durch Nutzer.

## Wichtige Entscheidungen (Details DECISIONS.md)
- ZIP statt .ysm (Verschlüsselung nicht erzeugbar).
- Bedrock = beschwörbare Entity, KEIN Spieler-Skin (offiziell nicht möglich).
- Credit „by Jan Wolf" in ysm.json (authors/tips), CREDITS.txt, bbmodel-Name,
  Manifesten, en_US.lang.
- Keine Fremd-Assets: alles Originaldesign; gesammelte YSM-Modelle werden
  nicht neu veröffentlicht.
- Box-UV; 512er-Atlas mit 256er-UV-Raum (Bedrock), 256er-Downscale für YSM/
  bbmodel.
- Feste Pack-UUIDs; Manifest-Dependencies RP<->BP.
- Addon-Icons IMMER per Bildgenerator (Asset `assets/pack_icon.png`, 512x512).
- Validator-first: jede Änderung läuft durch alle drei Validatoren.

## Projektregeln
Siehe PROJECT_RULES.md. Kern: keine Komplett-Rewrites; YSM-Required-Bone-
Namen erhalten; `mirror` spiegelt NUR UVs (Positionen explizit spiegeln);
keine Secrets speichern; Deliverables nur in `pakete/`; nach Änderungen
immer alle Validatoren + visuellen Render prüfen; ehrlich bleiben, was
Ingame-Tests angeht.

## Nächster sinnvoller Schritt
1. Nutzer fragen, ob der letzte Stand ingame gefällt; sonst gezielte
   Positions-/Proportions-Änderung in `dragon_girl.py` + Rebuild + Validatoren.
2. Danach TODO P2 (Varianten/Animationen).

## Dinge, die NICHT erneut gemacht werden sollen
- Token des Nutzers verwenden oder speichern (widerraten; siehe SECURITY.md).
- Repos auf Nutzer-Account pushen/spiegeln (abgelehnt: kein Platzgewinn,
  Fremdinhalt, Abuse-Risiko).
- MediaFire-/Piraterie-Downloads (abgelehnt).
- `out/`- oder `dist/`-Ordner für Deliverables (Snapshot-Verlust).
- `.ysm`-Erzeugung versuchen (verschlüsselt).
- Per-face-UV mit identischem Ursprung pro Face (Bug BUG-007).

## Vor Änderungen prüfen
- `verify.py`, `verify_bedrock.py`, `schema_check.py` laufen lassen.
- Front- UND Seiten-Render ansehen (`build.py` schreibt `character_front.png`;
  Seitenansicht-Debug wie in BUG-010 beschrieben).
- YSM-Required-Bones dürfen nicht umbenannt werden (Liste in ysm_gen.py).

# INSTRUCTIONS FOR NEXT AI
Du übernimmst dieses Projekt.
Lies zuerst:
1. NEXT_AI_HANDOFF.md
2. PROJECT_RULES.md
3. DECISIONS.md
4. CHANGELOG.md
5. README.md (ysm-studio/README.md)
Danach analysiere die relevanten Dateien.
Gehe nicht davon aus, dass bereits geplante Features implementiert sind.
Unterscheide immer zwischen: IMPLEMENTED / PARTIALLY IMPLEMENTED / PLANNED /
UNKNOWN.
Beginne nicht mit einem kompletten Rewrite.
Prüfe zuerst den vorhandenen Code.
Erhalte funktionierende Features.
Behebe zuerst kritische Fehler und Sicherheitsprobleme.
Wenn Anforderungen unklar sind, orientiere dich an den dokumentierten
Entscheidungen und dem bisherigen Projektverlauf.
Führe nach Änderungen Tests durch (die drei Validatoren + Render).
Dokumentiere wichtige Änderungen anschließend im CHANGELOG.
