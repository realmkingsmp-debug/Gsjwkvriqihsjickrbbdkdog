# BUGS

> Alle gefundenen Fehler sind BEHOBEN (Status „BEHOBEN"), sonst stünden sie
> unten als OFFEN. „Reproduktion" beschreibt, wie der Fehler sichtbar wurde –
> wichtig für Regressionstests.

## BEHOBEN

**BUG-001 – Bedrock-Entity unsichtbar**
- Ort: `rp/render_controllers/*.json`, `rp/animation_controllers/*.json`
- Symptome: Entity spawnt, kein Modell.
- Ursache: Wrapper-Keys `minecraft:render_controllers` /
  `minecraft:animation_controllers` – Vanilla verlangt die **nackten** Keys.
  (RP-`*.entity.json` braucht `minecraft:client_entity` – Inkonsistenz der
  Engine, aus Mojang-Beispielen verifiziert.)
- Lösung: nackte Keys. Regressionsschutz: verify_bedrock.py + schema_check.py.

**BUG-002 – YSM: Ohren/Hörner/Flügel fehlten**
- Ort: `build.py` (alt), `ysm_gen.validate()` (alt)
- Ursache: `mirror: true` spiegelt nur UVs; rechte Hälfte lag exakt auf der
  linken. Validator prüfte Positionen nicht.
- Lösung: negative x-Koordinaten + Validator-Checks (x-Range, Spiegel-Täuschung).

**BUG-003 – Bedrock-Add-on wurde nicht gezogen**
- Ort: Manifeste
- Ursache: Versions-/Engine-Mismatch + fehlende RP↔BP-Dependencies.
- Lösung: min_engine 1.16.0, Version 1.1.0/1.2.0, gegenseitige Dependencies,
  46-Checks in verify_bedrock.py.

**BUG-004 – `NameError: tex_png`**
- Ort: `build.py make_extras()`
- Ursache: nach v2-Refactor hieß der Parameter `tex256`; Body nutzte alten Namen.
- Lösung: Body auf `tex256` umgestellt.

**BUG-005 – Avatar-/Front-Render-Pfade**
- Ort: `build.py`
- Symptome: Dateien fehlten/leer.
- Lösung: PNG-Speicherung + absolute Pfade (cwd-Parameter unzuverlässig).

**BUG-006 – Deliverables verschwanden aus Snapshot**
- Ort: `ysm-studio/out/`
- Ursache: Workspace-Snapshot verwirft Ordner namens `out/`, `dist/`, `build/`.
- Lösung: Zielordner `pakete/`; Regel 2.

**BUG-007 – Per-face-UV-Kollision**
- Ort: frühe Geometrie-Versuche
- Ursache: identischer Ursprung je Face → Overdraw.
- Lösung: Box-UV-Standard (`Atlas.fr` liefert disjunkte Rechtecke).

**BUG-008 – verify.py Texturgröße**
- Ort: `verify.py`
- Ursache: YSM/bbmodel brauchen 256², nur Bedrock 512² (2×-Texeldichte).
- Lösung: Check nach Ziel formatiert.

**BUG-009 – BDS-Download blockiert**
- Ort: Umgebung (HTTP/2 INTERNAL_ERROR)
- Lösung: keine – statische Validatoren als Ersatz; NICHT erneut versuchen.

**BUG-010 – Körperpartien falsch platziert (vom Nutzer gemeldet)**
- Ort: `dragon_girl.py`
- Symptome: Lücke Torso/Hüfte; Schwanz schwebte; Rock-Panels mit Spalt;
  Lider unsichtbar (0.3u im Kopf versenkt).
- Lösung (Seiten-Debug-Render als Diagnose): Torso (−4,20,−2) 8×11×4;
  Hüfte 8×5×4 → y16..21; Rock-Panels z 3.9/−4.5/4.9/−5.5 (überlappend);
  Lider z 6.0..6.25; Schwanzkette Tail1..4 verankert (Details CHANGELOG #73).

**BUG-011 – Rechter Flügel nicht gespiegelt (Nachzügler von BUG-002)**
- Ort: `dragon_girl.py` (Flügel)
- Lösung: wb_x 2/−11, mm_x 11/−23, Membran-Pivot s*11.

## OFFEN (Bekannte Einschränkungen, keine Code-Defekte)
- **Kein Ingame-Runtime-Test möglich** (kein Client, BDS blockiert) –
  letzte Platzierungs-Fixes visuell via Render verifiziert, ingame-Rückmeldung
  des Nutzers ausstehend.
- `elaina/repos/` bereinigt (Großdateien/.git/Skadi-Theme fehlen) – rekonstruierbar.
- DeprecationWarnings in Validatoren (Pillow `getdata`, jsonschema `RefResolver`) –
  kosmetisch, keine Aktion nötig.
