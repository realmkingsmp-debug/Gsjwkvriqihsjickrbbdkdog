# FEATURES

| Feature | Status | Hinweise |
|---|---|---|
| GitHub-Account-Vollanalyse (Repos+Stars+Gists, lokal geklont) | IMPLEMENTED | report.html/md, CSVs, Roh-JSONs |
| Report-Selbstprüfung (HTML-Tabelle vs. CSV, Tausender-Format) | IMPLEMENTED | 35/35 Zeilen, Summen geprüft |
| YSM-Modell-ZIP „Dragon Girl" (Java) | IMPLEMENTED | ingame-Import vom Nutzer nicht rückbestätigt (UNKNOWN ingame) |
| Blockbench-Projekt .bbmodel | IMPLEMENTED | Box-UV, Textur Base64-embedded |
| Bedrock-Add-on .mcaddon (RP+BP, Entity `janwolf:dragon_girl`) | IMPLEMENTED | Nutzer: sichtbar, „einigermaßen OK" (älterer Stand) |
| Pack-Icon-Pipeline (KI-Icon → beide Packs) | IMPLEMENTED | `assets/pack_icon.png` → 512² |
| 3-stufiges Validation-Kit (40+46+Schema) | IMPLEMENTED | schema_check benötigt Internet |
| Self-contained showcase.html | IMPLEMENTED | Data-URIs, kein Netzwerk |
| Geometrie v2 (52 Bones, 45 Cubes) + Platzierungs-Fixes | IMPLEMENTED | finale visuelle Rückbestätigung ausstehend |
| Ingame-/Server-Verifikation | PARTIALLY IMPLEMENTED | Umgebung: kein Client, BDS-Download blockiert; Nutzer testet |
| `.ysm`-Dateien erzeugen | UNKNOWN (vermutlich nicht machbar) | Verschlüsselung „crypto 3" ungeklärt; Export nur ingame `/ysm export` |
| Weitere Farbvarianten / zweiter Charakter | PLANNED | Kit bereit (Palette + `dragon_girl.py`-Klonen) |
| Erweiterte Animationen (sit/emote/wave) | PLANNED | Struktur in ysm_gen.py vorhanden |
| Nutzer-GitHub-Spiegelung / Push | ABGELEHNT | Entscheidung D-04, nicht implementieren |
| YSM-Modell-Sammlung weiterverteilen | ABGELEHNT | Fremde Inhalte, Lizenz unklar |

## Details zu Schlüsselfeatures
- **Bedrock-Entity:** beschwörbar (`is_summonable`), passiv, nameable,
  Collision 0.6×2.0, Skalierung 0.75, idle/walk-Controller über
  `query.modified_move_speed`, spawn_egg-Farben Amethyst (123/80/195,
  Highlight 205/170/245).
- **Validatoren lesen von Platte** (ZIP/mcaddon) und prüfen nicht nur den
  Generator-Speicherzustand – dadurch wurden BUG-001/002/005 überhaupt gefunden.
- **Textur-Atlas:** ein 512²-Bild, UV-Raum 256 (Faktor 2 → 2 Texel/Blockeinheit);
  YSM-ZIP/bbmodel erhalten 256²-Downscale, Bedrock 512².
