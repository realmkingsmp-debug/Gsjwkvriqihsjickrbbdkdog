# API

> Es existiert KEIN eigener Web-Server/REST-Service. „API" bedeutet hier:
> (1) genutzte externe APIs, (2) interne Python-APIs des Kits, (3) Minecraft-
> „Befehle" (Spawn/Commands). Alles ohne Backend.

## 1) Externe APIs (unauthentisiert, Rate-Limit beachten: 60 req/h pro IP)
GitHub REST (nur Lesezugriff, keine Tokens):
- `GET /users/Elaina69` (+ `/repos`, `/starred`, `/gists`)
- `GET /repos/{owner}/{repo}/git/trees/{branch}?recursive=1`
- `GET /repos/{owner}/{repo}/git/trees/{sha}` (Subtree)
- `GET /repos/{owner}/{repo}/contents/{path}`
- `GET /repos/Mojang/bedrock-samples/git/trees/main?recursive=1` (Formatforschung)
Blockception (Schemas): `https://raw.githubusercontent.com/Blockception/Minecraft-Bedrock-Json-Schemas/main/types/…` (manifest, entity, geo, animation, controller, render-controller; per `?ref=1.21.120.25`).

## 2) Interne Python-API (ysm-studio)
```python
# ysm_gen.py
Bone(name, parent, pivot, rotation, cubes, texture_size)
Model(name, bones, texture_width/height, description_update)
validate(model, require_skeleton=False) -> None   # wirft Exception
idle_animation() -> dict                          # Molang 1.8.0
REQUIRED_BONES: set[str]                          # YSM-Pflichtknochen

# textures.py
build() -> (PIL.Image 512², origins: dict[str,(u,v)], dims: dict[str,(w,h,d)])
Atlas.reserve(name, w, h, d) -> (u, v)            # Box-UV-Ursprung
Atlas.fr(name) -> (u, v, w, h)                    # Face-Rechteck für per-face-UV

# dragon_girl.py
build(origins) -> (main: Model, arm: Model)       # 52 Bones / 45 Cubes

# build.py / build_bedrock.py / make_preview_html.py
#   als Skripte ausführbar, schreiben nach pakete/ bzw. pakete/bedrock/
```

## 3) Minecraft-seitige „API"/Befehle
- Bedrock: `/summon janwolf:dragon_girl` (BP-Entity, `is_summonable: true`)
- Bedrock: Spawn-Ei (im Kreativ-Inventar; Farben im client_entity definiert)
- YSM (Java, Mod installiert): ZIP importieren per `/ysm import <pfad.zip>`
  bzw. Mods-Ordner-Konfiguration; Export ingame `/ysm export`.
- Keine Discord-/RCON-/Web-Integration (nie Teil des Projekts).

## 4) Authentifizierung/Secrets
Keine erforderlich bzw. keine gespeichert. Nutzer-PAT wurde geteilt und sofort
verworfen/widerraten (SECURITY.md). Falls je wieder GitHub-Rate-Limit nötig:
`GITHUB_TOKEN` per `.env.example`-Muster, niemals ins Repo.
