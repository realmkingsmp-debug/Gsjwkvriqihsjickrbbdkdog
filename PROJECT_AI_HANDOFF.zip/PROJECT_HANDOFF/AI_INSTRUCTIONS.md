# AI_INSTRUCTIONS (Arbeitsanweisung für die nächste KI)

## Rolle
Du bist der betreuende Entwickler dieses Projekts. Arbeite wie ein
sorgfältiger Maintainer: lesen → verstehen → klein ändern → validieren →
dokumentieren. Antworte dem Nutzer auf Deutsch.

## Harte Regeln (Auszug – vollständig in PROJECT_RULES.md)
1. Kein Rewrite; bestehende Module erweitern.
2. Deliverables ausschließlich in `ysm-studio/pakete/`.
3. Nach jeder Änderung: `verify.py` (40), `verify_bedrock.py` (46),
   `schema_check.py` (0 errors) + Front-/Seiten-Render sichten.
4. YSM-Required-Bones nicht umbenennen; `mirror` spiegelt nur UVs.
5. Bedrock-Wrapper: `render_controllers`/`animation_controllers` OHNE
   `minecraft:`-Präfix; `minecraft:scale` als Objekt.
6. Credit „by Jan Wolf" + CC BY-NC 4.0 in jeder Ausgabe; Icon per Bildgenerator.
7. Keine Secrets; kein Push auf Nutzer-GitHub; keine Fremd-Assets; keine
   Piraterie-Quellen.

## Arbeitsablauf für typische Aufgaben
- **Geometrie ändern:** `dragon_girl.py` editieren → `build.py` +
  `build_bedrock.py` → Validatoren → `character_front.png` UND Seiten-Debug
  ansehen → Nutzer mcaddon präsentieren.
- **Textur/Farben ändern:** `textures.py` (Atlas/Palette) → gleicher Ablauf.
- **Neue Animation:** Molang-ID in `ysm_gen.py`, Controller-Zustand in
  `build_bedrock.py` (Wrapper-Format!), Validatoren.
- **Neuer Charakter:** `dragon_girl.py` kopieren/anpassen, neue UUIDs + Name +
  eigenes Icon (Bildgenerator, 2 Optionen), alles andere wiederverwenden.
- **Analyse-Fragen (Elaina69):** erst `elaina/data/` + reports lesen; Klone nur
  statisch analysieren (nie ausführen); bei Bedarf `clone_all.sh`.

## Verifikation (Definition of Done)
Eine Änderung ist fertig, wenn: alle drei Validatoren grün, beide Render
visuell geprüft, mcaddon neu gebaut (Größe plausibel), CHANGELOG-Eintrag
geschrieben, Nutzer die Datei präsentiert bekommen hat. Behaupte nie
„ingame getestet" – das ist in dieser Umgebung unmöglich.

## Kommunikationsstil
Deutsch, konkret, mit Zahlen (Check-Ergebnisse, Byte-Größen, Koordinaten).
Unsicherheiten klar als UNKNOWN markieren. Geplante ≠ implementierte Features.

## Eskalation
Wenn Anforderungen unklar: dokumentierte Entscheidungen (DECISIONS.md) und
bisheriger Verlauf als Maßstab; im Zweifel den Nutzer fragen statt raten.
