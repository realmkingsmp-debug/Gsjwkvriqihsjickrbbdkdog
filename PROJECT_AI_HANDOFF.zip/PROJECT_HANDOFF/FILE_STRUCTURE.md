# FILE_STRUCTURE

```
/home/user/
├── PROJECT_AI_HANDOFF.zip          ← dieses Übergabepaket
├── PROJECT_HANDOFF/                ← diese Dokumentation (15 Dateien)
├── ysm-studio/                     ← HAUPTPROJEKT
│   ├── README.md                   Kit-Doku, Konventionen, Installationswege
│   ├── ysm_gen.py                  Skelett/Validator/Animationen/ysm.json-Writer
│   ├── textures.py                 Atlas-Painter v2 (512², Gradienten, Muster)
│   ├── dragon_girl.py              Geometrie v2 (52 Bones/45 Cubes)
│   ├── build.py                    → YSM-ZIP, bbmodel, Previews, avatar, front-render
│   ├── build_bedrock.py            → RP/BP/.mcaddon (Icon-Pipeline, Dependencies)
│   ├── verify.py                   40 Checks (YSM-Paket, liest von Platte)
│   ├── verify_bedrock.py           46 Checks (mcaddon, liest von Platte)
│   ├── schema_check.py             jsonschema vs. Blockception-Schemas ($refs remote)
│   ├── make_preview_html.py        → pakete/showcase.html
│   ├── assets/pack_icon.png        gewähltes KI-Icon (Quelle für Pack-Icons)
│   └── pakete/                     DELIVERABLES (snapshot-sicherer Name!)
│       ├── DragonGirl_by_JanWolf.zip / .bbmodel
│       ├── showcase.html, preview.png, avatar.png, character_front.png,
│       │   model_preview.svg, debug_front.png, debug_side.png
│       └── bedrock/  DragonGirl_by_JanWolf.mcaddon, _RP.mcpack, _BP.mcpack,
│                     rp/… bp/… (entpackte Stände)
└── elaina/                         ← ANALYSE (abgeschlossen)
    ├── report.html / report.md     Hauptdeliverables der Analyse
    ├── out_repos.csv / out_stars.csv
    ├── clone_all.sh, clone_status.log, repos_to_clone.txt
    ├── analyze.py, build_report.py
    ├── data/                       API-Antworten + analyse_raw.json + stars_lang/
    └── repos/                      35 Klone, BEREINIGT (Großdateien/.git fehlen;
                                    Skadi-Theme fehlt; bei Bedarf neu klonen)
```

## Wichtige Dateien im Detail

**ysm_gen.py** – Funktion: Kernbibliothek. Zustand: stabil, v2-Animationen.
Abhängigkeiten: stdlib. APIs: `Bone`, `Model`, `validate(model, require_skeleton)`,
`idle_animation()`, `REQUIRED_BONES`. Probleme: keine bekannten. Geplant: ggf.
weitere Animationen (sit/emote) als zusätzliche IDs.

**textures.py** – Funktion: Atlas + Palette. Zustand: v2 (Gradienten, Augen mit
Iris-Tiefe, Schuppen-, Membran-, Haar-Muster). API: `build() -> (png512, origins, dims)`,
`Atlas.reserve(name,w,h,d)`, `Atlas.fr(name)` (Face-Rechtecke). Probleme: Pack-
Algorithmus simpel (Zeilenumbruch) – reicht aktuell.

**dragon_girl.py** – Funktion: Geometrie. Zustand: v2 + Platzierungs-Fixes
(Torso/Hüfte, Schwanzkette, Rock-Panels, Lider, Bein-Abstand, Flügel gespiegelt).
API: `build(origins) -> (main, arm)`. Probleme: kosmetische Feinjustierung offen.

**build.py / build_bedrock.py** – Funktion: Packaging. Zustand: inkl. Icon-
Pipeline (Asset → 512², Fallback gezeichnet) und CREDITS.txt. Probleme: keine.

**verify.py / verify_bedrock.py / schema_check.py** – Funktion: Quality-Gate.
Zustand: 40/46/8-Checks; schema_check braucht Netzwerk (raw.githubusercontent).
Probleme: DeprecationWarnings (getdata, RefResolver) kosmetisch.

**elaina/build_report.py** – Funktion: Report-Generator MIT Selbstprüfung der
HTML-Tabelle gegen out_repos.csv + Tausender-Normierung. Zustand: final.
