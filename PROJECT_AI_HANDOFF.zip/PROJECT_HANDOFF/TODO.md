# TODO

## P1 – zuerst
- [ ] Nutzer-Feedback zum letzten mcaddon-Stand einholen (Platzierungs-Fixes);
      bei Beanstandungen: gezielte Änderungen in `dragon_girl.py`, Rebuild,
      Validatoren, Front- UND Seiten-Render.
- [ ] Nutzer daran erinnern: geleakten GitHub-Token widerrufen.

## P2 – als nächstes
- [ ] Farbvariante/en der Dragon Girl (Palette in `textures.py` parametrisieren;
      Pack bleibt identisch strukturiert, neue UUIDs/Name je Variante).
- [ ] Weitere Animationen: sit, emote/wave (zusätzliche Molang-IDs in
      `ysm_gen.py`, `animation_controllers` erweitern – Wrapper-Format wahren!).
- [ ] Zweiter eigener Charakter auf Basis des Kits (neue Geometrie-Datei,
      eigenes Icon per Bildgenerator, Credit-Zeile beibehalten).
- [ ] `.env.example`-Muster für optionalen `GITHUB_TOKEN` ist hinterlegt – nur
      bei Bedarf nutzen, nie committen.

## P3 – später/optional
- [ ] YSM-ZIP vom Nutzer ingame testen lassen (Java + YSM-Mod); Feedback
      einarbeiten.
- [ ] Blockbench-Feinschliff durch Nutzer (.bbmodel öffnen, Proportionen
      feinjustieren, zurückexportieren lassen und Generator angleichen).
- [ ] Schema-Check offline-fähig machen (Schemas lokal einfrieren), falls
      Netzwerk wegbricht.
- [ ] Showcase-Seite um Seiten-/Rückansicht erweitern.

## Explizit NICHT tun
- Repos auf Nutzer-GitHub spiegeln/pushen (abgelehnt).
- `.ysm` erzeugen versuchen (Verschlüsselung unbekannt).
- BDS-Download erneut versuchen (blockiert).
- Fremd-Modelle aus Elaina69-Sammlung weiterverwenden.
