# SETUP

## Voraussetzungen
- Python ≥ 3.10 (getestet: 3.13), `pip install pillow jsonschema`
- Netzwerk nur für `schema_check.py` (Blockception-Schemas via raw.githubusercontent)
- Kein Minecraft-Client nötig (Bauen/Validieren geht ohne); zum Testen der
  Pakete: Minecraft Bedrock (Win10/11, Mobil, Konsole) bzw. Java + YSM-Mod

## Installation (aus dem ZIP)
```bash
unzip PROJECT_AI_HANDOFF.zip
cd PROJECT/ysm-studio
pip install pillow jsonschema        # falls nicht vorhanden
```

## Bauen
```bash
python3 build.py                 # → pakete/ (YSM-ZIP, bbmodel, Previews, front-render)
python3 build_bedrock.py         # → pakete/bedrock/ (.mcaddon, .mcpack)
python3 make_preview_html.py     # → pakete/showcase.html
```
Reihenfolge ist egal; alle Skripte sind unabhängig, teilen aber textures.py/
dragon_girl.py/ysm_gen.py.

## Validieren (Pflicht nach jeder Änderung)
```bash
python3 verify.py                # 40 Checks YSM-Paket  → erwartet 40/40
python3 verify_bedrock.py        # 46 Checks mcaddon    → erwartet 46/46
python3 schema_check.py          # 8 Dateien vs. Blockception → erwartet 0 errors
```

## Testen im Spiel
- **Bedrock:** `pakete/bedrock/DragonGirl_by_JanWolf.mcaddon` doppelklicken
  (Win10/11) → Minecraft; in Welt: Aktivieren im Welt-Einstellungen-Menü
  (Experimente NICHT nötig) → `/summon janwolf:dragon_girl` oder Spawn-Ei.
- **Java/YSM:** YSM-Mod installieren (CurseForge/Modrinth, offiziell) →
  `/ysm import <pfad>/DragonGirl_by_JanWolf.zip` (Version/Importpfad siehe
  YSM-Wiki; bei Fehlern Content-Log mit „dragon" durchsuchen).
- **Blockbench:** `.bbmodel` öffnen (Box-UV voreingestellt).

## Umgebung/Secrets
- Keine Secrets nötig. Optionaler GitHub-Token für höhere API-Limits:
  `.env.example` kopieren, Wert nur lokal setzen, nie einchecken.
- Bekannte Umgebungs-Blocks: BDS-Download (CDN), kein Client → siehe BUGS.md.

## Analyse-Teil (elaina/) reproduzieren
```bash
cd PROJECT/elaina
bash clone_all.sh                # 36 Repos shallow (dauert; ~61 MB)
python3 analyze.py               # → data/analyse_raw.json
python3 build_report.py          # → report.html (+ Selbstprüfung gegen CSV)
```

## Troubleshooting
- Validatoren rot → erst BUGS.md prüfen (alle bekannten Fehler dokumentiert).
- Entity unsichtbar → Wrapper-Keys (BUG-001), dann Content-Log-Zeilen mit
  `dragon_girl` anfordern.
- Pakete „verschwinden" → niemals `out/`/`dist/`/`build/` als Ziel (Regel 2).
