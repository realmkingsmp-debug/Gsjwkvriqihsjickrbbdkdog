# PROJECT_OVERVIEW

## Worum es geht
Persönliches Kreativ-/Analyseprojekt von **Jan Wolf** (Nutzer), betreut über
mehrere Sitzungen:

### Strang A: GitHub-Analyse „Elaina69"
- Alle 36 öffentlichen Repos geklont (`git clone --depth 1`), alle 11 Stern-
  Markierungen und 3 Gists per GitHub-REST-API geholt und lokal ausgewertet.
- Deliverables: `elaina/report.html` (interaktiver Report), `report.md`,
  `out_repos.csv`, `out_stars.csv`, Rohdaten `elaina/data/`.
- Kernbefunde: 96 % der Sterne (3.363/3.495) aus `Yes-Steve-Model-Repo`
  (YSM-Modellsammlung, 137 Kategorien, 906 .ysm + 208 .zip); 25/36 Repos sind
  LoL-Client-Modding (Pengu Loader: Elaina-theme, Plugin-Serie); 2 vietnamesische
  Uni-Projekte (ML/CV); Sicherheits-Scan 0 Secret-Treffer; Klärungspunkte:
  YSM-Repo ohne Lizenz, 1,6-GB-CV-Repo, ToS-Grauzone einiger LoL-Plugins.

### Strang B: ysm-studio (Hauptprojekt)
Eigenes Kit zur Erzeugung originaler Minecraft-Charakter-Inhalte:
- **Dragon Girl** – Amethyst-Anime-Drachenmädchen (vom Nutzer gewähltes Design).
- Ausgaben: YSM-ZIP (Java), `.bbmodel` (Blockbench), **Bedrock-.mcaddon**
  (Entity `janwolf:dragon_girl`), Showcase-HTML, Icons per Bildgenerator.
- Credit **„by Jan Wolf"** in allen Beschreibungen; Lizenz CC BY-NC 4.0.
- Qualitätsnetz: 3 Validatoren (40 + 46 + 8-Schema-Checks) + Front-/Seiten-
  Render zur Sichtkontrolle.

## Warum Strang B existiert
Nutzer wollte „eigene coole Modelle/Charaktere hoher Qualität" und daraus
Minecraft-Mods mit seinem Markenzeichen. Dafür wurde das YSM-Dateiformat aus
den echten Modellen in Strang A reverse-engineered (YSM nutzt intern das
Bedrock-Add-on-Format) und ein eigenes, von Fremd-Assets unabhängiges Kit
gebaut.

## Beteiligte Personen/Rollen
- Jan Wolf = Nutzer/Autor der eigenen Designs (Credit-Zeile).
- Elaina69 = analysierter Dritt-Account (nur Forschung, keine Wiederverwertung
  seiner Inhalte in unseren Deliverables).

## Umgebung & Limits
- Sandbox /home/user; Python 3.13, Pillow, jsonschema; JDK 11 (kein 17+);
  KEIN Minecraft-Client; offizieller Bedrock-Server-Download CDN-blockiert;
  Workspace-Snapshots ignorieren `out/`, `dist/`, `build/` u. a. (→ `pakete/`).

## Status-Konvention
IMPLEMENTED / PARTIALLY IMPLEMENTED / PLANNED / UNKNOWN – siehe FEATURES.md.
