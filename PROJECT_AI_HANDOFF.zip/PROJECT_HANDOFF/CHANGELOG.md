# CHANGELOG

## v1.2 – Platzierungs-Fixes + Handoff (2026-09-23)
### Behoben
- Lücke Torso/Hüfte geschlossen (Torso y20..31, Hüfte y16..21, Überlappung 1u).
- Schwanz schwebte 2u hinter dem Körper → verankerte Kette Tail1..4
  (Pivots 0,17,−3 / 0,17.5,−7 / 0,18,−11.5 / 0,18.5,−15; Rotation −10/−14/−16/−18;
  Cubes 4×4×5 → 3×3×5 → 2×2×4 → 2×2×3).
- Rock-Panels schwebten → z auf 3.9 / −4.5 / 4.9 / −5.5 (überlappen Basis).
- Lider waren 0.3u im Kopf versenkt (unsichtbar) → z 6.0..6.25, Pivot y39/z6.0.
- Rechter Flügel nicht gespiegelt (nur UVs) → Positionen explizit negativ
  (wb_x 2/−11, mm_x 11/−23, Membran-Pivot s*11).
- `make_extras` NameError (`tex_png` → `tex256`).
- Beine hatten 0 Abstand → ±0.5 (x 0.5..4.5 links, −4.5..−0.5 rechts).
### Hinzugefügt
- Seiten-Debug-Render (debug_side.png) als Diagnose-Werkzeug.
- PROJECT_HANDOFF/-Dokumentation + PROJECT_AI_HANDOFF.zip.

## v1.1 – Bedrock-Add-on + Beautification v2
### Behoben
- Entity unsichtbar → Controller-Wrapper ohne `minecraft:`-Präfix (BUG-001).
- Add-on wurde nicht gezogen → Manifeste v2, Dependencies, min_engine 1.16.
- Ohren/Hörner/Flügel fehlten (mirror nur UV) → gespiegelte Positionen + Validator-Checks.
- Avatar-/Front-Render-Pfade; `out/` → `pakete/` (Snapshot-Verlust).
### Hinzugefügt
- Bedrock-Pipeline: RP/BP/mcaddon, Spawn-Ei, Icon-Pipeline (KI-Icon → 512²),
  `build_bedrock.py`, `verify_bedrock.py` (46 Checks), `schema_check.py`.
- Geometrie/Textur v2: 52 Bones, 45 Cubes, 512²-Atlas mit Gradienten,
  Augen-Tiefe, Schuppen/Membran/Haar-Muster; showcase.html; Avatar-Generierung.

## v1.0 – Grundkit + Analyse
### Hinzugefügt
- Elaina69-Vollanalyse: 36 Repos shallow-geklont, 11 Stars, 3 Gists;
  analyze.py, build_report.py (mit Selbstprüfung), report.html/md, CSVs.
- ysm-studio v1: ysm_gen.py (Skelett, REQUIRED_BONES, validate, idle/walk),
  textures.py, dragon_girl.py v1, build.py → YSM-ZIP + bbmodel + verify.py (40 Checks).
- Format-Forschung: YSM-ZIP spec 2 (`texture` = Liste), Box-UV, Molang 1.8.0;
  Bedrock-Referenzen (allay, cow 1.26.10) aus Mojang-Samples.

## Entscheidungen im Verlauf
Siehe DECISIONS.md (D-01 … D-16).
