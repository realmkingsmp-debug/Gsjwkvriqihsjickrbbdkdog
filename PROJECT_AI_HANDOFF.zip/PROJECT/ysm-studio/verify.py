#!/usr/bin/env python3
"""
verify.py — unabhaengige Pruefung des gebauten Pakets.

Liest die Dateien VON DER PLATTE (nicht aus dem Generator) und prueft sie gegen
das Schema, das aus den echten YSM-Modellen in Yes-Steve-Model-Repo abgeleitet
wurde. So wird der Generator selbst getestet, nicht seine eigenen Annahmen.
"""
from __future__ import annotations
import io, json, os, sys, zipfile
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pakete")
ZIP = os.path.join(OUT, "DragonGirl_by_JanWolf.zip")
BBM = os.path.join(OUT, "DragonGirl_by_JanWolf.bbmodel")

# Pflicht-Bones, verifiziert gegen 60 echte YSM-Modelle (59-60/60 Vorkommen)
REQUIRED = {"Root", "AllBody", "UpBody", "AllHead", "Head", "DownBody",
            "LeftArm", "LeftForeArm", "LeftHandLocator",
            "RightArm", "RightForeArm", "RightHandLocator",
            "LeftLeg", "LeftLowerLeg", "RightLeg", "RightLowerLeg", "Arm"}

fails, checks = [], 0


def check(ok: bool, msg: str):
    global checks
    checks += 1
    if not ok:
        fails.append(msg)
    print(("  ok   " if ok else "  FEHLT ") + msg)


print("=== ZIP vorhanden und lesbar ===")
check(os.path.exists(ZIP), f"{os.path.basename(ZIP)} existiert")
z = zipfile.ZipFile(ZIP)
names = set(z.namelist())
print("  Inhalt:", sorted(names))

print("\n=== ysm.json (Spec 2) ===")
y = json.loads(z.read("ysm.json"))
check(y.get("spec") == 2, "spec == 2")
check(isinstance(y.get("metadata"), dict), "metadata vorhanden")
check(bool(y["metadata"].get("name")), f"Modellname: {y['metadata'].get('name')}")
auth = y["metadata"].get("authors") or []
check(bool(auth) and "Jan Wolf" in auth[0].get("name", ""),
      f"Autor-Credit gesetzt: {auth[0].get('name') if auth else '-'}")
check("Jan Wolf" in (auth[0].get("comment", "") if auth else ""),
      "'by Jan Wolf' im Kommentar")
check(isinstance(y["files"]["player"]["texture"], list),
      "files.player.texture ist eine Liste (wie bei echten YSM-Modellen)")

print("\n=== alle referenzierten Dateien liegen im ZIP ===")
refs = []
refs += list(y["files"]["player"]["model"].values())
refs += list(y["files"]["player"]["animation"].values())
refs += [t["uv"] for t in y["files"]["player"]["texture"]]
refs.append(y["files"]["avatar"])
for r in refs:
    check(r in names, f"{r} vorhanden")

print("\n=== Geometrie main.json ===")
d = json.loads(z.read("models/main.json"))
check("minecraft:geometry" in d, "minecraft:geometry vorhanden")
check(d.get("format_version", "").startswith("1."), f"format_version {d.get('format_version')}")
g = d["minecraft:geometry"][0]
desc = g["description"]
tw, th = desc["texture_width"], desc["texture_height"]
check((tw, th) == (256, 256), f"Texturgroesse {tw}x{th}")
bones = g["bones"]
bn = [b["name"] for b in bones]
check(len(bn) == len(set(bn)), "keine doppelten Bone-Namen")
missing = REQUIRED - set(bn)
check(not missing, f"alle {len(REQUIRED)} YSM-Pflicht-Bones vorhanden"
      + (f" (fehlen: {sorted(missing)})" if missing else ""))
known = set(bn)
bad_parent = [b["name"] for b in bones if b.get("parent") and b["parent"] not in known]
check(not bad_parent, "alle Bone-Parents existieren")
ncubes = sum(len(b.get("cubes", [])) for b in bones)
check(ncubes >= 25, f"{ncubes} Cubes gebaut")

print("\n=== Cubes: Masse und UV im Atlas ===")
bad_size = bad_uv = 0
for b in bones:
    for c in b.get("cubes", []):
        w, h, d = c["size"]
        if len(c["origin"]) != 3 or len(c["size"]) != 3 or any(v <= 0 for v in c["size"]):
            bad_size += 1
        uv = c["uv"]
        if isinstance(uv, list):
            u, v = uv
            bw, bh = 2 * (w + d), h + d
            if u < 0 or v < 0 or u + bw > tw or v + bh > th:
                bad_uv += 1
        elif isinstance(uv, dict):
            for f, spec in uv.items():
                uu, vv = spec["uv"]; sw, sh = spec["uv_size"]
                if uu < 0 or vv < 0 or uu + abs(sw) > tw or vv + abs(sh) > th:
                    bad_uv += 1
        else:
            bad_uv += 1
check(bad_size == 0, f"alle Cube-Masse gueltig ({bad_size} Fehler)")
check(bad_uv == 0, f"alle UVs innerhalb des Atlas ({bad_uv} Fehler)")

print("\n=== Symmetrie: rechte Koerperhaelfte wirklich gespiegelt ===")
def xs(name):
    return [c["origin"][0] + c["size"][0] / 2 for b in bones if b["name"] == name
            for c in b.get("cubes", [])]
pairs = [("LeftArm", "RightArm"), ("LeftForeArm", "RightForeArm"), ("LeftHand", "RightHand"),
         ("LeftLeg", "RightLeg"), ("LeftLowerLeg", "RightLowerLeg"),
         ("LeftFoot", "RightFoot"), ("HornLeft", "HornRight"), ("EarLeft", "EarRight")]
asym = []
for l, r in pairs:
    lx, rx = xs(l), xs(r)
    if not lx or not rx:
        asym.append(f"{l}/{r}: keine Cubes")
    elif abs(lx[0] + rx[0]) > 0.01:
        asym.append(f"{l}({lx[0]:+.2f}) vs {r}({rx[0]:+.2f}) nicht gespiegelt")
check(not asym, "alle Paare x-symmetrisch zur Mitte" + (f" -> {asym}" if asym else ""))

print("\n=== Texturen sind gueltige PNGs ===")
for n in ("textures/default.png", "avatar/dragon_girl.png"):
    im = Image.open(io.BytesIO(z.read(n)))
    im.load()
    check(im.format == "PNG" and im.size[0] > 0, f"{n}: {im.size} {im.mode}")
tex = Image.open(io.BytesIO(z.read("textures/default.png")))
check(tex.size == (tw, th), f"Textur groesse passt zur Geometrie ({tex.size})")
# Atlas darf nicht leer sein
nonempty = sum(1 for p in tex.convert("RGBA").getdata() if p[3] > 0)
check(nonempty > 1000, f"Atlas ist bemalt ({nonempty:,} sichtbare Pixel)")

print("\n=== Animationen (Molang, format 1.8.0) ===")
a = json.loads(z.read("animations/main.animation.json"))
check(a.get("format_version") == "1.8.0", "format_version 1.8.0")
ids = list(a.get("animations", {}).keys())
check("idle" in ids, f"'idle' vorhanden (in ysm.json als preview_animation referenziert)")
check(y["properties"]["preview_animation"] in ids, "preview_animation existiert wirklich")
anim_bones = set()
for k, v in a["animations"].items():
    anim_bones |= set(v.get("bones", {}).keys())
check(anim_bones <= set(bn), f"Animationen nutzen nur existierende Bones ({len(anim_bones)} Bones)")

print("\n=== arm.json ===")
arm = json.loads(z.read("models/arm.json"))
ag = arm["minecraft:geometry"][0]
check(sum(len(b.get("cubes", [])) for b in ag["bones"]) >= 1, "arm hat mindestens einen Cube")
check(ag["description"]["texture_width"] == 32, "arm nutzt 32x32 (wie echte YSM-Modelle)")

print("\n=== Blockbench-Projekt ===")
check(os.path.exists(BBM), f"{os.path.basename(BBM)} existiert")
bb = json.load(open(BBM, encoding="utf-8"))
check(bb["meta"]["model_format"] == "modded_entity", "Format 'modded_entity'")
check(bb["meta"]["box_uv"] is True, "box_uv=true (Box-UV wie echte YSM-Modelle)")
check(len(bb["elements"]) == ncubes, f"{len(bb['elements'])} Elemente = {ncubes} Cubes")
check(len(bb["textures"]) == 1 and bb["textures"][0]["source"].startswith("data:image/png;base64,"),
      "Textur ist eingebettet (Base64)")
check("Jan Wolf" in bb["name"], f"Credit im Projektnamen: {bb['name']}")
outline_names = {n["name"] for n in bb["outliner"]}
check(REQUIRED <= outline_names, "alle Pflicht-Bones im Outliner")
# jedes Element muss einem Outliner-Knoten zugeordnet sein
assigned = {c for n in bb["outliner"] for c in n.get("children", [])}
allids = {e["uuid"] for e in bb["elements"]}
check(assigned == allids, "jedes Element ist im Outliner eingehaengt")

print("\n" + "=" * 60)
print(f"{checks - len(fails)}/{checks} Checks bestanden")
if fails:
    print("FEHLGESCHLAGEN:")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("PAKET VALIDE")
