#!/usr/bin/env python3
"""
schema_check.py — validiert die gebauten Packs gegen die community-gepflegten
Bedrock-JSON-Schemas (Blockception/Minecraft-bedrock-json-schemas, im Stil der
offiziellen Mojang-Formate). $refs werden live vom Repo aufgelöst.
"""
from __future__ import annotations
import json, os, sys, zipfile
import jsonschema
from jsonschema import Draft7Validator, Draft202012Validator

BASE = "https://raw.githubusercontent.com/Blockception/Minecraft-bedrock-json-schemas/main/"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pakete", "bedrock")

CASES = [
    # (pack, datei-im-pack, schema-pfad)
    ("RP", "manifest.json", "general/manifest.json"),
    ("RP", "entity/dragon_girl.entity.json", "resource/entity/entity.json"),
    ("RP", "models/entity/dragon_girl.geo.json", "resource/models/entity/model_entity.json"),
    ("RP", "animations/dragon_girl.animation.json", "resource/animations/actor_animation.json"),
    ("RP", "animation_controllers/dragon_girl.controller.json",
     "resource/animation_controllers/animation_controller.json"),
    ("RP", "render_controllers/dragon_girl.render_controller.json",
     "resource/render_controllers/render_controllers.json"),
    ("BP", "manifest.json", "general/manifest.json"),
    ("BP", "entities/dragon_girl.behavior.json", "behavior/entities/entities.json"),
]

import urllib.request
from functools import lru_cache


@lru_cache(maxsize=None)
def fetch(path: str):
    with urllib.request.urlopen(BASE + path, timeout=30) as r:
        return json.loads(r.read())


def make_validator(schema):
    resolver = jsonschema.RefResolver(BASE, schema, handlers={"https": fetch, "http": fetch})
    for cls in (Draft202012Validator, Draft7Validator):
        try:
            cls.check_schema(schema)
            return cls(schema, resolver=resolver)
        except Exception:
            continue
    return Draft7Validator(schema, resolver=resolver)


def short(err):
    p = "/".join(str(x) for x in list(err.absolute_path)[:4])
    return f"{p}: {err.message[:140]}"


def main():
    rp = zipfile.ZipFile(os.path.join(OUT, "DragonGirl_by_JanWolf_RP.mcpack"))
    bp = zipfile.ZipFile(os.path.join(OUT, "DragonGirl_by_JanWolf_BP.mcpack"))
    packs = {"RP": rp, "BP": bp}
    problems = 0
    checked = 0
    for pack, name, schema_path in CASES:
        z = packs[pack]
        data = json.loads(z.read(name))
        schema = fetch(schema_path)
        v = make_validator(schema)
        errs = sorted(v.iter_errors(data), key=lambda e: list(e.absolute_path))
        checked += 1
        if errs:
            problems += len(errs)
            print(f"[{pack}] {name}  ->  {len(errs)} Schema-Fehler")
            for e in errs[:8]:
                print("   ", short(e))
        else:
            print(f"[{pack}] {name}  ->  Schema OK")
    print(f"\n{checked} Dateien geprueft, {problems} Schema-Fehler")
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
