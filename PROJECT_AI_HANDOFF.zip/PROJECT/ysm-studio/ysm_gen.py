#!/usr/bin/env python3
"""
ysm_gen.py — Generator für Yes-Steve-Model-Modelle im ZIP-Format.

Das ZIP-Layout wurde aus den echten Modellen in Elaina69/Yes-Steve-Model-Repo
reverse-engineered (60 Modelle mit YSM-Kernskelett verglichen):

    ysm.json                              Spec 2: metadata / properties / files
    models/main.json                      minecraft:geometry (Bones + Cubes)
    models/arm.json                       First-Person-Arm
    animations/main.animation.json        Molang-Animationen
    textures/default.png                  Texturatlas
    avatar/<name>.png                     Icon fuer die YSM-GUI

YSM akzeptiert ZIP-Modelle direkt; nur das .ysm-Format ist verschluesselt
(<crypto> 3, ab Mod-Version 1.2.0 in C++ implementiert) und kann hier nicht
erzeugt werden. Export nach .ysm passiert ingame mit `/ysm export`.

Autor des Generators: Jan Wolf
"""
from __future__ import annotations
import json, os, zipfile, datetime
from dataclasses import dataclass, field

FORMAT_VERSION = "1.12.0"


@dataclass
class Cube:
    """Ein Quader im Bedrock-Format."""
    origin: tuple          # [x, y, z] Ecke mit kleinsten Koordinaten
    size: tuple            # [w, h, d]
    uv: tuple              # [u, v] linke obere Ecke des UV-Layouts
    inflate: float = 0.0
    mirror: bool = False
    rotation: tuple | None = None
    pivot: tuple | None = None

    def to_json(self):
        c = {"origin": list(self.origin), "size": list(self.size), "uv": list(self.uv)}
        if self.inflate:
            c["inflate"] = self.inflate
        if self.mirror:
            c["mirror"] = True
        if self.rotation is not None:
            c["rotation"] = list(self.rotation)
        if self.pivot is not None:
            c["pivot"] = list(self.pivot)
        return c


@dataclass
class Bone:
    name: str
    pivot: tuple
    parent: str | None = None
    rotation: tuple | None = None
    cubes: list = field(default_factory=list)
    mirror: bool = False
    neverRender: bool = False      # Locator-Bones haben keine Cubes

    def to_json(self):
        b = {"name": self.name, "pivot": list(self.pivot)}
        if self.parent:
            b["parent"] = self.parent
        if self.rotation is not None:
            b["rotation"] = list(self.rotation)
        if self.cubes:
            b["cubes"] = [c.to_json() if hasattr(c, "to_json") else c
                          for c in self.cubes]
        if self.mirror:
            b["mirror"] = True
        if self.neverRender:
            b["neverRender"] = True
        return b


class Model:
    def __init__(self, identifier: str, tex_w: int = 128, tex_h: int = 128):
        self.identifier = identifier
        self.tex_w = tex_w
        self.tex_h = tex_h
        self.bones: list[Bone] = []

    def add(self, bone: Bone) -> Bone:
        self.bones.append(bone)
        return bone

    def to_json(self) -> dict:
        return {
            "format_version": FORMAT_VERSION,
            "minecraft:geometry": [{
                "description": {
                    "identifier": self.identifier,
                    "texture_width": self.tex_w,
                    "texture_height": self.tex_h,
                    "visible_bounds_width": 6,
                    "visible_bounds_height": 6,
                    "visible_bounds_offset": [0, 2, 0],
                },
                "bones": [b.to_json() for b in self.bones],
            }],
        }


# ---------------------------------------------------------------------------
# Das YSM-Kernskelett.
#
# Bone-Namen sind PFLICHT: YSM bindet seine Animationen und das Expressions-
# Rigging (Eyes/Eyelid/Eyebrow) ueber diese Namen. Verifiziert gegen 60 Modelle
# aus Yes-Steve-Model-Repo: Root, AllBody, UpBody, AllHead, Head, DownBody,
# LeftArm, LeftForeArm, LeftHandLocator, RightArm, RightForeArm,
# RightHandLocator, LeftLeg, LeftLowerLeg, RightLeg, RightLowerLeg, Arm
# kamen in 59-60 von 60 Modellen vor; Eyes/Eyelid/Eyebrow in 46-51.
# ---------------------------------------------------------------------------
def ysm_skeleton() -> Model:
    m = Model("geometry.ysm_dragon_girl", 128, 128)
    A = m.add

    # --- Wirbelsaeule -------------------------------------------------------
    A(Bone("Root", (0, 0, 0)))
    A(Bone("AllBody", (0, 20, 0), "Root"))
    A(Bone("MAllBody", (0, 20, 0), "AllBody", neverRender=True))
    A(Bone("UpBody", (0, 22, 0), "AllBody"))
    A(Bone("UpperBody", (0, 22, 0), "UpBody"))
    A(Bone("MUpperBody", (0, 22, 0), "UpperBody", neverRender=True))
    A(Bone("DownBody", (0, 20, 0), "AllBody"))

    # --- Kopf + Gesichts-Rigging -------------------------------------------
    A(Bone("AllHead", (0, 29, 0), "UpperBody"))
    A(Bone("Head", (0, 29, 0), "AllHead"))
    A(Bone("MHead", (0, 29, 0), "Head", neverRender=True))
    A(Bone("Face", (0, 29, 0), "Head"))
    A(Bone("Eyes", (0, 29, 0), "Face"))
    A(Bone("Eyelid", (0, 29, 0), "Face"))
    A(Bone("LeftEyelid", (0, 29, 0), "Eyelid"))
    A(Bone("RightEyelid", (0, 29, 0), "Eyelid"))
    A(Bone("LeftEyebrow", (0, 29, 0), "Face"))
    A(Bone("RightEyebrow", (0, 29, 0), "Face"))
    A(Bone("Hair", (0, 29, 0), "Head"))

    # --- Arme ---------------------------------------------------------------
    A(Bone("Arm", (0, 27, 0), "UpperBody"))
    A(Bone("LeftShoulderLocator", (3, 36, 0), "UpperBody", neverRender=True))
    A(Bone("RightShoulderLocator", (-3, 36, 0), "UpperBody", neverRender=True))
    A(Bone("LeftArm", (3, 27, 0), "Arm"))
    A(Bone("LeftForeArm", (3, 22, 0), "LeftArm"))
    A(Bone("LeftHand", (3, 18, 0), "LeftForeArm"))
    A(Bone("LeftHandLocator", (3, 18, 0), "LeftHand", neverRender=True))
    A(Bone("RightArm", (-3, 27, 0), "Arm"))
    A(Bone("RightForeArm", (-3, 22, 0), "RightArm"))
    A(Bone("RightHand", (-3, 18, 0), "RightForeArm"))
    A(Bone("RightHandLocator", (-3, 18, 0), "RightHand", neverRender=True))
    A(Bone("ElytraLocator", (0, 27, 2), "UpperBody", neverRender=True))

    # --- Beine --------------------------------------------------------------
    A(Bone("LeftLeg", (1.9, 20, 0), "DownBody"))
    A(Bone("LeftLowerLeg", (1.9, 12, 0), "LeftLeg"))
    A(Bone("LeftFoot", (1.9, 2, 0), "LeftLowerLeg"))
    A(Bone("RightLeg", (-1.9, 20, 0), "DownBody"))
    A(Bone("RightLowerLeg", (-1.9, 12, 0), "RightLeg"))
    A(Bone("RightFoot", (-1.9, 2, 0), "RightLowerLeg"))

    return m


# ---------------------------------------------------------------------------
# Validierung gegen das beobachtete Schema
# ---------------------------------------------------------------------------
REQUIRED_BONES = {
    "Root", "AllBody", "UpBody", "AllHead", "Head", "DownBody",
    "LeftArm", "LeftForeArm", "LeftHandLocator",
    "RightArm", "RightForeArm", "RightHandLocator",
    "LeftLeg", "LeftLowerLeg", "RightLeg", "RightLowerLeg", "Arm",
}


def validate(model: Model, require_skeleton: bool = True) -> list[str]:
    """Prueft das Modell gegen das aus den echten YSM-Modellen abgeleitete Schema."""
    errors = []
    names = [b.name for b in model.bones]
    if len(names) != len(set(names)):
        dup = sorted({n for n in names if names.count(n) > 1})
        errors.append(f"doppelte Bone-Namen: {dup}")
    if require_skeleton:
        missing = REQUIRED_BONES - set(names)
        if missing:
            errors.append(f"YSM-Pflicht-Bones fehlen: {sorted(missing)}")
    known = set(names)
    for b in model.bones:
        if b.parent and b.parent not in known:
            errors.append(f"Bone '{b.name}': unbekannter Parent '{b.parent}'")
        if len(b.pivot) != 3:
            errors.append(f"Bone '{b.name}': pivot braucht 3 Werte")
        for c in b.cubes:
            cd = c.to_json() if hasattr(c, "to_json") else c
            if len(cd["origin"]) != 3 or len(cd["size"]) != 3:
                errors.append(f"Bone '{b.name}': origin/size brauchen je 3 Werte")
            if any(v <= 0 for v in cd["size"]):
                errors.append(f"Bone '{b.name}': Cube-Groesse muss > 0 sein")
            uv = cd.get("uv")
            if uv is None:
                errors.append(f"Bone '{b.name}': Cube ohne UV")
                continue
            w, h, d = cd["size"]
            if isinstance(uv, list):                       # Box-UV (YSM-Standard)
                u, v = uv
                bw, bh = 2 * (w + d), h + d
                if u < 0 or v < 0 or u + bw > model.tex_w or v + bh > model.tex_h:
                    errors.append(
                        f"Bone '{b.name}': Box-UV ({u},{v}) + {bw}x{bh} liegt "
                        f"ausserhalb des {model.tex_w}x{model.tex_h}-Atlas")
            else:                                          # per-face UV
                need = {"north", "south", "east", "west", "up", "down"} - set(uv)
                if need:
                    errors.append(f"Bone '{b.name}': UV-Flaechen fehlen {sorted(need)}")
                for f, spec in uv.items():
                    if not isinstance(spec, dict) or "uv" not in spec or "uv_size" not in spec:
                        errors.append(f"Bone '{b.name}': UV '{f}' ohne uv/uv_size")
                        continue
                    u, v = spec["uv"]; sw, sh = spec["uv_size"]
                    if u < 0 or v < 0 or u + abs(sw) > model.tex_w or v + abs(sh) > model.tex_h:
                        errors.append(
                            f"Bone '{b.name}': UV '{f}' ({u},{v}+{sw},{sh}) liegt "
                            f"ausserhalb des {model.tex_w}x{model.tex_h}-Atlas")
    return errors
    return errors


# ---------------------------------------------------------------------------
# Molang-Animationen
# ---------------------------------------------------------------------------
def idle_animation() -> dict:
    """v2: Atmen, Kopf-Sway, Schwanz- und Haarbogen, Fluegel-Flattern, Gehen."""
    def k(t, v):
        return {f"{t:.2f}": v}

    return {
        "format_version": "1.8.0",
        "animations": {
            "idle": {
                "loop": True,
                "animation_length": 2.8,
                "bones": {
                    "UpperBody": {"rotation": {**k(0, [1, 0, 0]), **k(1.4, [2.5, 0, 0]), **k(2.8, [1, 0, 0])}},
                    "AllHead": {"rotation": {**k(0, [0, 0, 0]), **k(1.4, [-2, 0, 2]), **k(2.8, [0, 0, 0])}},
                    "LeftArm": {"rotation": {**k(0, [0, 0, 6]), **k(1.4, [0, 0, 9]), **k(2.8, [0, 0, 6])}},
                    "RightArm": {"rotation": {**k(0, [0, 0, -6]), **k(1.4, [0, 0, -9]), **k(2.8, [0, 0, -6])}},
                    "Tail1": {"rotation": {**k(0, [-14, 0, 0]), **k(1.4, [-10, 0, 4]), **k(2.8, [-14, 0, 0])}},
                    "Tail2": {"rotation": {**k(0, [-16, 0, 0]), **k(1.4, [-20, 0, 6]), **k(2.8, [-16, 0, 0])}},
                    "Tail3": {"rotation": {**k(0, [-18, 0, 0]), **k(1.4, [-14, 0, 8]), **k(2.8, [-18, 0, 0])}},
                    "HairTail1": {"rotation": {**k(0, [14, 0, 0]), **k(1.4, [18, 0, 3]), **k(2.8, [14, 0, 0])}},
                    "HairTail2": {"rotation": {**k(0, [10, 0, 0]), **k(1.4, [6, 0, 4]), **k(2.8, [10, 0, 0])}},
                    "WingLeft": {"rotation": {**k(0, [18, 0, 24]), **k(1.4, [18, 0, 30]), **k(2.8, [18, 0, 24])}},
                    "WingRight": {"rotation": {**k(0, [18, 0, -24]), **k(1.4, [18, 0, -30]), **k(2.8, [18, 0, -24])}},
                },
            },
            "walk": {
                "loop": True,
                "animation_length": 0.8,
                "bones": {
                    "LeftLeg": {"rotation": {**k(0, [-38, 0, 0]), **k(0.4, [38, 0, 0]), **k(0.8, [-38, 0, 0])}},
                    "RightLeg": {"rotation": {**k(0, [38, 0, 0]), **k(0.4, [-38, 0, 0]), **k(0.8, [38, 0, 0])}},
                    "LeftArm": {"rotation": {**k(0, [32, 0, 6]), **k(0.4, [-32, 0, 6]), **k(0.8, [32, 0, 6])}},
                    "RightArm": {"rotation": {**k(0, [-32, 0, -6]), **k(0.4, [32, 0, -6]), **k(0.8, [-32, 0, -6])}},
                    "UpperBody": {"rotation": {**k(0, [4, 0, 0]), **k(0.4, [4, 0, 0]), **k(0.8, [4, 0, 0])}},
                    "Tail1": {"rotation": {**k(0, [-14, 0, 5]), **k(0.4, [-14, 0, -5]), **k(0.8, [-14, 0, 5])}},
                    "Tail2": {"rotation": {**k(0, [-16, 0, -6]), **k(0.4, [-16, 0, 6]), **k(0.8, [-16, 0, -6])}},
                    "HairTail1": {"rotation": {**k(0, [18, 0, 0]), **k(0.4, [10, 0, 0]), **k(0.8, [18, 0, 0])}},
                    "HairTail2": {"rotation": {**k(0, [6, 0, 0]), **k(0.4, [14, 0, 0]), **k(0.8, [6, 0, 0])}},
                },
            },
        },
    }


# ---------------------------------------------------------------------------
# Paketierung
# ---------------------------------------------------------------------------
def ysm_json(name: str, author: str, tips: str, model_name: str,
             height_scale: float = 0.7, width_scale: float = 0.7,
             license_type: str = "CC BY-NC 4.0") -> dict:
    return {
        "spec": 2,
        "metadata": {
            "name": name,
            "tips": tips,
            "license": {"type": license_type},
            "authors": [{
                "name": author,
                "role": "model",
                "comment": f"by {author}",
            }],
        },
        "properties": {
            "height_scale": height_scale,
            "width_scale": width_scale,
            "preview_animation": "idle",
            "default_texture": "default",
            "render_layers_first": False,
            "free": True,
        },
        "files": {
            "player": {
                "model": {"main": "models/main.json", "arm": "models/arm.json"},
                "animation": {"main": "animations/main.animation.json"},
            },
            "texture": {"default": "textures/default.png"},
            "avatar": f"avatar/{model_name}.png",
        },
    }


def write_package(out_path: str, model: Model, arm: Model, meta: dict,
                  texture_png: bytes, avatar_png: bytes) -> list[str]:
    errors = validate(model)
    errors += ["arm: " + e for e in validate(arm, require_skeleton=False)]
    if errors:
        return errors
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("ysm.json", json.dumps(meta, ensure_ascii=False, indent=2))
        z.writestr("models/main.json", json.dumps(model.to_json(), indent=1))
        z.writestr("models/arm.json", json.dumps(arm.to_json(), indent=1))
        z.writestr("animations/main.animation.json",
                   json.dumps(idle_animation(), ensure_ascii=False, indent=1))
        z.writestr("textures/default.png", texture_png)
        z.writestr(meta["files"]["avatar"], avatar_png)
    return []
