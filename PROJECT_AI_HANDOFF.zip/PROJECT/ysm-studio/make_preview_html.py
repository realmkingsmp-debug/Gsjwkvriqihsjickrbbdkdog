#!/usr/bin/env python3
"""Baut out/showcase.html — self-contained Praesentation des Modells (by Jan Wolf)."""
import base64, json, zipfile, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pakete")
z = zipfile.ZipFile(os.path.join(OUT, "DragonGirl_by_JanWolf.zip"))
ysm = json.loads(z.read("ysm.json"))
geo = json.loads(z.read("models/main.json"))["minecraft:geometry"][0]
bones = geo["bones"]
ncubes = sum(len(b.get("cubes", [])) for b in bones)

def b64(name):
    with open(os.path.join(OUT, name), "rb") as f:
        return base64.b64encode(f.read()).decode()

front = b64("character_front.png")
atlas = b64("preview.png")
avatar = b64("avatar.png")
svg = open(os.path.join(OUT, "model_preview.svg"), encoding="utf-8").read()

bone_list = "".join(f"<li><code>{b['name']}</code></li>" for b in bones)

html = f"""<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dragon Girl (by Jan Wolf) — YSM-Modell</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#0b1020;color:#e2e8f0;font:15px/1.65 system-ui,Segoe UI,Roboto,sans-serif}}
.wrap{{max-width:1000px;margin:0 auto;padding:36px 20px 90px}}
h1{{font-size:38px;margin:0;background:linear-gradient(90deg,#c084fc,#f0abfc);-webkit-background-clip:text;background-clip:text;color:transparent}}
.by{{color:#94a3b8;font-size:15px;margin:4px 0 26px}}
h2{{font-size:21px;margin:40px 0 12px;color:#f1f5f9;border-bottom:1px solid #1e293b;padding-bottom:8px}}
.grid{{display:grid;grid-template-columns:auto 1fr;gap:26px;align-items:start}}
@media(max-width:760px){{.grid{{grid-template-columns:1fr}}}}
img.pix{{image-rendering:pixelated;border:1px solid #2a2f4a;border-radius:12px;background:#12101f}}
.meta{{background:#111831;border:1px solid #1e293b;border-radius:14px;padding:18px 20px}}
.meta div{{margin:5px 0}}
.k{{color:#94a3b8;display:inline-block;min-width:150px}}
code{{background:#1a2340;color:#fbcfe8;padding:2px 6px;border-radius:5px;font-size:12.5px}}
ul{{padding-left:20px;columns:2}}
@media(max-width:760px){{ul{{columns:1}}}}
.note{{background:#141b33;border-left:4px solid #8b5cf6;padding:12px 16px;border-radius:0 10px 10px 0;margin:16px 0}}
pre{{background:#0d1329;border:1px solid #1e293b;border-radius:10px;padding:14px;overflow-x:auto;font-size:13px}}
</style></head><body><div class="wrap">
<h1>Dragon Girl</h1>
<div class="by">Amethyst-Drachenmaedchen · <b>by Jan Wolf</b> · YSM-Modell (ZIP) + Blockbench-Projekt</div>

<div class="grid">
<div>
<img class="pix" src="data:image/png;base64,{front}" style="width:300px" alt="Frontalansicht">
<div style="margin-top:14px"><img class="pix" src="data:image/png;base64,{avatar}" style="width:110px" alt="GUI-Avatar">
<span style="color:#94a3b8;font-size:13px">  GUI-Avatar (YSM-Auswahlmenue)</span></div>
</div>
<div class="meta">
<div><span class="k">Modellname</span> {ysm['metadata']['name']}</div>
<div><span class="k">Autor</span> {ysm['metadata']['authors'][0]['name']} — <code>by Jan Wolf</code></div>
<div><span class="k">Lizenz</span> {ysm['metadata']['license']['type']}</div>
<div><span class="k">Skalierung</span> {ysm['properties']['height_scale']} / {ysm['properties']['width_scale']}</div>
<div><span class="k">Bones</span> {len(bones)} (davon alle 17 YSM-Pflicht-Bones)</div>
<div><span class="k">Cubes</span> {ncubes}</div>
<div><span class="k">Textur</span> 256 x 256 RGBA, Box-UV</div>
<div><span class="k">Animationen</span> idle, walk (Molang)</div>
<div><span class="k">Features</span> Hoerner, Drachenohren, Fluegel + Membran, 3-gliedriger Schwanz, langer Zopf, Anime-Face</div>
<div><span class="k">Dateien</span> <code>DragonGirl_by_JanWolf.zip</code>, <code>.bbmodel</code></div>
</div></div>

<h2>Texturatlas (256 x 256)</h2>
<img class="pix" src="data:image/png;base64,{atlas}" style="width:520px;max-width:100%" alt="Texturatlas">

<h2>Geometrie-Schema (Vorderansicht X/Y)</h2>
{svg}

<h2>Skelett (Bones)</h2>
<ul>{bone_list}</ul>


<h2>Minecraft Bedrock Edition</h2>
<p>Bedrock unterstuetzt keine eigenen <b>Spieler</b>-Geometrien — der offizielle Weg ist eine
beschwörbare Entitaet. Dafuer gibt es <code>bedrock/DragonGirl_by_JanWolf.mcaddon</code>
(Resource Pack + Behavior Pack, Doppelklick-Import auf Windows/Android):</p>
<pre>1. .mcaddon doppelklicken -> Minecraft importiert beide Packs automatisch.
   (Alternativ: .mcpack-Dateien einzeln doppeln oder in
    com.mojang/development_resource_packs bzw. development_behavior_packs legen.)
2. Welt erstellen/bearten -> BEIDE Packs unter "Ressourcenpakete"/"Behavior-Packs" aktivieren.
3. Im Spiel: /summon janwolf:dragon_girl  — oder das lila/goldene Spawn-Ei
   im Kreativ-Inventar benutzen.
4. Name ueber dem Kopf: "Dragon Girl (by Jan Wolf)".</pre>
<ul style="columns:1">
<li><code>entity/dragon_girl.entity.json</code> — Client-Entity (Material entity_alphatest, Spawn-Ei-Farben)</li>
<li><code>models/entity/dragon_girl.geo.json</code> — dieselbe Geometrie wie die YSM-Version</li>
<li><code>animations/</code> + <code>animation_controllers/</code> — idle/walk mit query.modified_move_speed-Umschaltung</li>
<li><code>render_controllers/</code> + <code>texts/en_US.lang</code> — Rendering und Anzeigename mit Credit</li>
<li>Behavior: health 20, Kollisionsbox 0.6x2.0, Scale 0.75, Random-Stroll/Look-AI, beschwoerbar</li>
</ul>
<div class="note"><b>Ehrlich:</b> Auch hier kein Live-Test in Minecraft moeglich (kein Bedrock in dieser
Umgebung). Die Struktur folgt exakt den offiziellen Add-on-Konventionen (Manifest v2, client_entity 1.10.0,
geo 1.12.0, Animations-Controller 1.10.0) und wurde mit 40 Checks gegen Cross-Referenzen validiert.</div>
<h2>Installation in Minecraft (Java, YSM)</h2>
<pre>1. Yes-Steve-Model-Mod installieren (Forge/Fabric, z.B. via Modrinth/CurseForge).
2. Minecraft starten, ins Spiel gehen.
3. YSM-Menue oeffnen (Standard: Taste G) -> "Import" -> DragonGirl_by_JanWolf.zip waehlen.
   Alternativ: Datei in .minecraft/ysm/models/ legen und ingame aktivieren.
4. Weiterbearbeiten: DragonGirl_by_JanWolf.bbmodel in Blockbench oeffnen
   (Format: Modded Entity, Box-UV, Textur eingebettet).</pre>

<div class="note"><b>Hinweis zur Ehrlichkeit:</b> Die Paketstruktur wurde 1:1 von funktionierenden
Modellen aus <code>Yes-Steve-Model-Repo</code> abgeleitet und mit 40 automatischen Checks validiert
(Schema, UVs, Symmetrie, Referenzen, PNGs, Animationen). Ein echter Ingame-Ladetest war in dieser
Umgebung nicht moeglich (kein Minecraft/JDK 17) — falls der Mod beim Import etwas bemängelt,
liegt die Diagnose in <code>verify.py</code> und die Konventionen in den Skripten.</div>
</div></body></html>"""

with open(os.path.join(OUT, "showcase.html"), "w", encoding="utf-8") as f:
    f.write(html)
print("showcase.html:", len(html), "Zeichen")
