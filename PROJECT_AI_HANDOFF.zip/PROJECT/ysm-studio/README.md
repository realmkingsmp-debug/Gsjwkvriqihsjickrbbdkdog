# ysm-studio — YSM-Modell-Generator (by Jan Wolf)

Eigenes Modell-Studio für **Yes Steve Model** (Minecraft-Mod). Reverse-engineert
aus den echten Modellen in `Elaina69/Yes-Steve-Model-Repo` (60 ZIP-Modelle
verglichen), inkl. 40-Punkte-Validator.

## Enthaltene Ergebnisse (`pakete/`)

| Datei | Was es ist |
|---|---|
| `DragonGirl_by_JanWolf.zip` | Fertiges YSM-Modell. Direkt im YSM-Mod importierbar. |
| `DragonGirl_by_JanWolf.bbmodel` | Blockbench-Projekt (Modded Entity, Box-UV, Textur eingebettet). |
| `showcase.html` | Self-contained Präsentationsseite (Front-View, Atlas, Skelett, Anleitung). |
| `character_front.png` | Gerenderte Frontalansicht des Charakters. |
| `preview.png` | Texturatlas 256×256. |
| `avatar.png` | GUI-Icon für das YSM-Auswahlmenü. |
| `model_preview.svg` | Drahtgitter-Vorderansicht der Geometrie. |

## Generator-Kit (eigene Charaktere bauen)

```bash
python3 build.py      # baut ZIP + bbmodel + Previews
python3 verify.py     # 40 Checks gegen das echte YSM-Schema
python3 make_preview_html.py
```

- `ysm_gen.py` — Skelett-Basis (alle 17 YSM-Pflicht-Bones, verifiziert gegen
  60 echte Modelle), Validator (Box-UV + per-face-UV), Molang-Animationen,
  `ysm.json`-Spec-2-Writer.
- `textures.py` — prozeduraler Atlas-Packer (Box-UV-Layout: Breite `2*(w+d)`,
  Höhe `h+d`; Vorderseite = `south` bei `u+w+d, v+d`), Amethyst-Palette.
- `dragon_girl.py` — Geometrie: 47 Bones, 37 Cubes (Hörner, Drachenohren,
  Flügel+Membran, 3-Glieder-Schwanz, Zopf, Anime-Gesicht mit Eyelid-Rig).

## Wichtige Konventionen (aus echten Modellen abgeleitet)

1. `ysm.json` → `files.player.texture` ist eine **Liste**: `[{"uv": "textures/default.png"}]`.
2. Cubes nutzen **Box-UV** (`"uv":[u,v]`) oder per-face-UV; beide kommen in
   echten Modellen vor. Dieses Kit nutzt Box-UV.
3. YSM bindet Animationen/Expressions an **Bone-Namen**: `Root, AllBody, UpBody,
   UpperBody, DownBody, AllHead, Head, Face, Eyes, Eyelid, LeftArm, LeftForeArm,
   LeftHandLocator, RightArm, RightForeArm, RightHandLocator, LeftLeg,
   LeftLowerLeg, RightLeg, RightLowerLeg, Arm` (59–60/60 Modellen).
4. `mirror: true` spiegelt **nur UVs**, nie die Position → rechte Körperhälfte
   immer mit eigenen negativen x-Koordinaten bauen.
5. `.ysm`-Dateien sind verschlüsselt (`<crypto> 3`) und können nicht erzeugt
   werden; Export nach `.ysm` passiert ingame per `/ysm export`. ZIP ist der
   offene Weg.
6. Skalierung typischer Modelle: `height_scale`/`width_scale` 0.65–0.75.

## Bedrock Edition

`python3 build_bedrock.py` baut `pakete/bedrock/DragonGirl_by_JanWolf.mcaddon`
(RP+BP). Bedrock erlaubt keine eigenen Spieler-Geometrien, daher Entität
`janwolf:dragon_girl`: `/summon` oder Spawn-Ei, Anzeigename „Dragon Girl
(by Jan Wolf)". Validiert mit `verify_bedrock.py` (40 Checks).

## Lizenz & Credit

Modelle aus diesem Kit sind eigene Originaldesigns. Credit-Zeile in
`ysm.json` (metadata.authors, tips), `CREDITS.txt` und im `.bbmodel`-Namen:
**by Jan Wolf**. Lizenz: CC BY-NC 4.0. Keine Fremd-Assets enthalten — die
906 gesammelten Modelle aus dem YSM-Repo bleiben Eigentum ihrer Autoren und
werden von diesem Kit nicht neu veröffentlicht.
