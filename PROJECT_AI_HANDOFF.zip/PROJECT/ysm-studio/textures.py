#!/usr/bin/env python3
"""
textures.py v2 — hochaufloesender Texturatlas fuer Dragon Girl (by Jan Wolf).

Trick fuer mehr Detail: Der Atlas ist 512x512 Pixel, der UV-Raum bleibt 256.
Bedrock skaliert UVs nach Bildgroesse -> jede Modelleinheit samplet 2 Texel.
Alle Zeichenkoordinaten laufen im 256er-Raum und werden intern x2 genommen.

Box-UV-Layout wie v1: Breite 2*(w+d), Hoehe h+d; Vorderseite = south.
"""
from __future__ import annotations
import math
from PIL import Image, ImageDraw

W = H = 256          # UV-Raum
S = 2                # Texel pro Einheit (Bild = 512)

PAL = {
    "skin":      (255, 226, 209),
    "skin_sh":   (233, 190, 172),
    "skin_hi":   (255, 242, 233),
    "blush":     (252, 172, 188),
    "hair":      (186, 158, 240),
    "hair_sh":   (140, 110, 205),
    "hair_hi":   (226, 210, 255),
    "hair_dk":   (112,  84, 178),
    "scale":     (148, 108, 224),
    "scale_hi":  (188, 156, 248),
    "scale_sh":  ( 98,  68, 164),
    "scale_dk":  ( 70,  46, 122),
    "dress":     ( 92,  64, 148),
    "dress_hi":  (130, 100, 194),
    "dress_sh":  ( 60,  40, 104),
    "dress_dk":  ( 42,  28,  76),
    "gold":      (244, 204, 112),
    "gold_hi":   (255, 232, 168),
    "gold_sh":   (188, 146,  66),
    "crystal":   (158, 228, 255),
    "crystal_hi":(224, 248, 255),
    "crystal_sh":( 84, 168, 216),
    "eye_w":     (255, 255, 255),
    "eye1":      (196, 128, 240),
    "eye2":      (148,  80, 212),
    "eye3":      ( 96,  44, 158),
    "pupil":     ( 34,  16,  56),
    "eye_hi":    (255, 255, 255),
    "mouth":     (204, 110, 132),
    "brow":      (124,  94, 190),
    "membrane":  (210, 180, 252),
    "membrane_hi":(236, 220, 255),
    "membrane_sh":(150, 118, 210),
}


def _mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


class Atlas:
    def __init__(self):
        self.img = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)
        self.origins, self.dims = {}, {}
        self._x = self._y = self._row = 0

    def reserve(self, name, w, h, d):
        w, h, d = map(lambda v: int(math.ceil(v)), (w, h, d))
        bw, bh = 2 * (w + d), h + d
        if self._x + bw > W:
            self._x, self._y, self._row = 0, self._y + self._row, 0
        if self._y + bh > H:
            raise RuntimeError(f"Atlas voll bei '{name}'")
        self.origins[name] = (self._x, self._y)
        self.dims[name] = (w, h, d)
        self._x += bw
        self._row = max(self._row, bh)
        return self.origins[name]

    def fr(self, name):
        u, v = self.origins[name]
        w, h, d = self.dims[name]
        return {
            "up":    (u + d, v, w, d),
            "down":  (u + w + d, v, w, d),
            "north": (u, v + d, w, h),
            "west":  (u + w, v + d, d, h),
            "south": (u + w + d, v + d, w, h),
            "east":  (u + 2 * w + d, v + d, d, h),
        }

    # ---- Zeichenhelfer (skalieren selbsttaetig) ----
    def px(self, x, y, col):
        self.d.rectangle([x * S, y * S, (x + 1) * S - 1, (y + 1) * S - 1], fill=col + (255,))

    def rect(self, box, col):
        x, y, w, h = box
        self.d.rectangle([x * S, y * S, (x + w) * S - 1, (y + h) * S - 1], fill=col + (255,))

    def grad(self, box, top, bottom):
        x, y, w, h = box
        for i in range(h):
            self.rect((x, y + i, w, 1), _mix(top, bottom, i / max(h - 1, 1)))

    def line(self, p0, p1, col):
        self.d.line([p0[0] * S, p0[1] * S, p1[0] * S, p1[1] * S], fill=col + (255,), width=S)

    def png(self):
        import io
        b = io.BytesIO()
        self.img.save(b, "PNG")
        return b.getvalue()


def build():
    a = Atlas()

    # ================= KOPF 12x11x12: grosses Anime-Gesicht =================
    a.reserve("head", 12, 11, 12)
    f = a.fr("head")
    a.grad(f["south"], PAL["skin_hi"], PAL["skin"])
    a.grad(f["north"], PAL["hair"], PAL["hair_sh"])
    a.grad(f["up"], PAL["hair_hi"], PAL["hair"])
    a.grad(f["west"], PAL["hair"], PAL["hair_sh"])
    a.grad(f["east"], PAL["hair"], PAL["hair_sh"])
    a.rect(f["down"], PAL["skin_sh"])
    x, y, w, h = f["south"]
    # Haarrahmen
    a.rect((x, y, w, 2), PAL["hair"])
    a.rect((x, y, 1, h), PAL["hair"])
    a.rect((x + w - 1, y, 1, h), PAL["hair"])
    for i in range(w):  # Zacken-Pony
        if i % 3 != 2:
            a.px(x + i, y + 2, PAL["hair"])
    # Augen je 3x4: weiss -> Iris-Gradient -> Pupille + 2 Glanzlichter
    for ex in (x + 2, x + 7):
        a.rect((ex, y + 4, 3, 4), PAL["eye_w"])
        a.grad((ex, y + 5, 3, 3), PAL["eye1"], PAL["eye3"])
        a.px(ex + 1, y + 6, PAL["pupil"]); a.px(ex + 1, y + 7, PAL["pupil"])
        a.px(ex, y + 5, PAL["eye_hi"]); a.px(ex + 2, y + 7, PAL["eye2"])
        a.line((ex - 1, y + 4), (ex + 3, y + 4), PAL["brow"])      # Wimpernlinie
    # Brauen, Wangenrot, Mund
    a.line((x + 2, y + 3), (x + 4, y + 3), PAL["brow"])
    a.line((x + 7, y + 3), (x + 9, y + 3), PAL["brow"])
    a.px(x + 1, y + 8, PAL["blush"]); a.px(x + 2, y + 8, PAL["blush"])
    a.px(x + 9, y + 8, PAL["blush"]); a.px(x + 10, y + 8, PAL["blush"])
    a.px(x + 5, y + 9, PAL["mouth"]); a.px(x + 6, y + 9, PAL["mouth"])

    # ================= HAAR-Teile =================
    def hair_part(name, w, h, d, strands=True):
        a.reserve(name, w, h, d)
        for fc, box in a.fr(name).items():
            a.grad(box, PAL["hair_hi"] if fc == "up" else PAL["hair"],
                   PAL["hair_sh"] if fc != "up" else PAL["hair"])
            if strands and fc in ("south", "north", "west", "east"):
                xx, yy, ww, hh = box
                for i in range(1, ww, 3):
                    a.line((xx + i, yy + 1), (xx + i, yy + hh - 1), PAL["hair_sh"])
                a.line((xx, yy), (xx + ww - 1, yy), PAL["hair_hi"])
    hair_part("hair_top", 13, 2, 13)
    hair_part("hair_back", 13, 12, 2)
    hair_part("hair_l", 2, 9, 12)
    hair_part("hair_r", 2, 9, 12)
    hair_part("hair_fringe", 13, 3, 2)
    hair_part("tail1", 5, 8, 5)
    hair_part("tail2", 4, 7, 4)
    hair_part("tail3", 3, 6, 3)
    # Haarspitze: Kristall-Fade
    a.reserve("tail4", 2, 5, 2)
    for box in a.fr("tail4").values():
        a.grad(box, PAL["hair"], PAL["crystal"])

    # ================= HOERNER (gold, gerillt) =================
    def horn(name):
        a.reserve(name, 3, 6, 3)
        for box in a.fr(name).values():
            a.grad(box, PAL["gold_hi"], PAL["gold_sh"])
            xx, yy, ww, hh = box
            for i in range(1, hh, 2):
                a.line((xx, yy + i), (xx + ww - 1, yy + i), PAL["gold_sh"])
    horn("horn_l"); horn("horn_r")

    # ================= OHREN (Schuppen + Membran) =================
    def ear(name):
        a.reserve(name, 4, 5, 2)
        for fc, box in a.fr(name).items():
            a.grad(box, PAL["scale_hi"], PAL["scale_sh"])
            xx, yy, ww, hh = box
            if fc in ("south", "north"):
                for i in range(ww):
                    a.px(xx + i, yy + hh - 1 - (i % 2), PAL["membrane"])
    ear("ear_l"); ear("ear_r")

    # ================= TORSO / KLEID =================
    a.reserve("torso", 8, 10, 4)
    for fc, box in a.fr("torso").items():
        a.grad(box, PAL["dress_hi"], PAL["dress_sh"])
    x, y, w, h = a.fr("torso")["south"]
    a.rect((x + 2, y, 4, 2), PAL["skin"])                     # Ausschnitt
    a.rect((x + 3, y + 3, 2, 2), PAL["crystal"])              # Brosche
    a.px(x + 3, y + 3, PAL["crystal_hi"])
    a.line((x, y + h - 1), (x + w - 1, y + h - 1), PAL["gold"])
    a.grad(a.fr("torso")["north"], PAL["dress_hi"], PAL["dress_dk"])

    a.reserve("hips", 8, 3, 4)
    for box in a.fr("hips").values():
        a.grad(box, PAL["dress"], PAL["dress_sh"])

    # Rock: Falten + Goldsaum auf allen Seiten
    a.reserve("skirt", 12, 7, 8)
    for fc, box in a.fr("skirt").items():
        if fc in ("up", "down"):
            a.rect(box, PAL["dress_sh"]); continue
        xx, yy, ww, hh = box
        a.grad(box, PAL["dress_hi"], PAL["dress_sh"])
        for i in range(2, ww, 3):
            a.line((xx + i, yy + 1), (xx + i, yy + hh - 2), PAL["dress_dk"])
        a.line((xx, yy + hh - 1), (xx + ww - 1, yy + hh - 1), PAL["gold"])

    # ================= ARME =================
    def part(name, dims, kind):
        a.reserve(name, *dims)
        cols = {"skin": (PAL["skin_hi"], PAL["skin_sh"]),
                "sleeve": (PAL["dress_hi"], PAL["dress_sh"]),
                "scale": (PAL["scale_hi"], PAL["scale_sh"])}[kind]
        for box in a.fr(name).values():
            a.grad(box, cols[0], cols[1])
    part("shoulder", (4, 4, 4), "scale")
    part("arm", (3, 6, 3), "sleeve")
    part("forearm", (3, 6, 3), "skin")
    part("hand", (3, 3, 3), "skin")

    # ================= BEINE =================
    part("leg", (4, 8, 4), "skin")
    a.reserve("lowerleg", 4, 7, 4)
    for box in a.fr("lowerleg").values():
        a.grad(box, PAL["scale_hi"], PAL["scale_sh"])
        xx, yy, ww, hh = box
        for i in range(0, ww, 2):   # Schuppenmuster
            for j in range(1, hh, 2):
                a.px(xx + min(i + (j % 4 == 1), ww - 1), yy + j, PAL["scale_dk"])
    a.reserve("foot", 4, 3, 6)
    for fc, box in a.fr("foot").items():
        a.grad(box, PAL["scale_hi"], PAL["scale_sh"])
        if fc == "south":
            a.line((box[0], box[1] + 1), (box[0] + box[2] - 1, box[1] + 1), PAL["gold_sh"])

    # ================= SCHWANK (Schuppen + Kristallspitze) =================
    for nm, dims in (("seg1", (4, 4, 5)), ("seg2", (3, 3, 5)), ("seg3", (2, 2, 4))):
        a.reserve(nm, *dims)
        for box in a.fr(nm).values():
            a.grad(box, PAL["scale_hi"], PAL["scale_sh"])
            xx, yy, ww, hh = box
            a.line((xx, yy + hh - 1), (xx + ww - 1, yy + hh - 1), PAL["scale_dk"])
    a.reserve("seg4", 2, 2, 3)
    for box in a.fr("seg4").values():
        a.grad(box, PAL["crystal"], PAL["crystal_sh"])
        a.px(box[0], box[1], PAL["crystal_hi"])

    # ================= FLUEGEL =================
    a.reserve("wingbone", 9, 2, 2)
    for box in a.fr("wingbone").values():
        a.grad(box, PAL["scale_hi"], PAL["scale_sh"])
    a.reserve("wingmem", 12, 10, 2)
    for fc, box in a.fr("wingmem").items():
        if fc in ("up", "down"):
            a.rect(box, PAL["membrane_sh"]); continue
        xx, yy, ww, hh = box
        a.grad(box, PAL["membrane_hi"], PAL["membrane_sh"])
        for i in (3, 6, 9):   # Fluegelknochen-Speichen
            a.line((xx, yy + hh - 1), (xx + i, yy + 1), PAL["membrane_sh"])
        a.line((xx, yy + hh - 1), (xx + ww - 1, yy + hh - 1), PAL["scale_sh"])

    # ================= LIDER (YSM-Rig) =================
    a.reserve("lid", 3, 2, 1)
    for box in a.fr("lid").values():
        a.rect(box, PAL["skin"])

    return a.png(), a.origins, a.dims
