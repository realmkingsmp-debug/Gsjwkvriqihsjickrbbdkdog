#!/usr/bin/env python3
"""
verify_bedrock.py — prueft das gebaute .mcaddon VON DER PLATTE gegen die
Bedrock-Add-on-Konventionen (Manifest-UUIDs, Cross-Referenzen, Geometrie).
"""
from __future__ import annotations
import io, json, os, sys, uuid, zipfile

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pakete", "bedrock")
ADDON = os.path.join(OUT, "DragonGirl_by_JanWolf.mcaddon")

fails, checks = [], 0


def check(ok, msg):
    global checks
    checks += 1
    if not ok:
        fails.append(msg)
    print(("  ok   " if ok else "  FEHLT ") + msg)


print("=== .mcaddon-Struktur ===")
check(os.path.exists(ADDON), ".mcaddon existiert")
az = zipfile.ZipFile(ADDON)
inner = az.namelist()
rp_name = [n for n in inner if n.endswith("_RP.mcpack")]
bp_name = [n for n in inner if n.endswith("_BP.mcpack")]
check(len(rp_name) == 1, "enthält genau ein RP-.mcpack")
check(len(bp_name) == 1, "enthält genau ein BP-.mcpack")
rp = zipfile.ZipFile(io.BytesIO(az.read(rp_name[0])))
bp = zipfile.ZipFile(io.BytesIO(az.read(bp_name[0])))
rpn, bpn = set(rp.namelist()), set(bp.namelist())
print("  RP:", sorted(rpn))
print("  BP:", sorted(bpn))

print("\n=== Manifeste ===")
rm = json.loads(rp.read("manifest.json"))
bm = json.loads(bp.read("manifest.json"))
uuids = []
for label, m, typ in (("RP", rm, "resources"), ("BP", bm, "data")):
    check(m.get("format_version") == 2, f"{label}: format_version 2")
    h, mods = m["header"], m["modules"]
    for u in (h["uuid"], mods[0]["uuid"]):
        try:
            uuid.UUID(u)
            uuids.append(u)
            ok = True
        except Exception:
            ok = False
        check(ok, f"{label}: UUID valide ({u[:13]}…)")
    check(mods[0]["type"] == typ, f"{label}: Modultyp '{typ}'")
    check("Jan Wolf" in h["description"], f"{label}: Credit im Manifest")
    check(len(h.get("min_engine_version", [])) == 3, f"{label}: min_engine_version gesetzt")
check(len(set(uuids)) == 4, "alle 4 UUIDs eindeutig")
rd = rm.get("dependencies", [{}])[0].get("uuid")
bd = bm.get("dependencies", [{}])[0].get("uuid")
check(rd == bm["header"]["uuid"], "RP haengt am BP (dependency-UUID stimmt)")
check(bd == rm["header"]["uuid"], "BP haengt am RP (dependency-UUID stimmt)")

print("\n=== JSONs parsen ===")
files = {}
for z in (rp, bp):
    for n in z.namelist():
        if n.endswith(".json"):
            files[n] = json.loads(z.read(n))
check(True, f"{len(files)} JSON-Dateien gelesen")

print("\n=== Cross-Referenzen RP ===")
ce = None
for n, d in files.items():
    if "minecraft:client_entity" in d:
        ce = d["minecraft:client_entity"]["description"]
check(ce is not None, "client_entity gefunden")
ident = ce["identifier"]
check(ident == "janwolf:dragon_girl", f"identifier {ident}")

geo = None
for n, d in files.items():
    if "minecraft:geometry" in d:
        geo = d["minecraft:geometry"][0]
check(geo is not None, "Geometrie gefunden")
gid = geo["description"]["identifier"]
check(ce["geometry"]["default"] == gid, f"client_entity -> geometry '{gid}'")

# Texturpfad: "textures/entity/dragon_girl" -> textures/entity/dragon_girl.png
tpath = ce["textures"]["default"] + ".png"
check(tpath in rpn, f"Texturdatei {tpath} liegt im RP")

# Animationen
anim_ids = set()
for n, d in files.items():
    if n.startswith("animations/"):
        anim_ids |= set(d["animations"].keys())
for key, val in ce["animations"].items():
    if val.startswith("animation."):
        check(val in anim_ids, f"Animation '{val}' definiert")

ctrl_ids = set()
for n, d in files.items():
    if "animation_controllers" in d:
        ctrl_ids |= set(d["animation_controllers"].keys())
for key, val in ce["animations"].items():
    if val.startswith("controller."):
        check(val in ctrl_ids, f"Animation-Controller '{val}' definiert")

rc_ids = set()
for n, d in files.items():
    if "render_controllers" in d:
        rc_ids |= set(d["render_controllers"].keys())
for r in ce["render_controllers"]:
    check(r in rc_ids, f"Render-Controller '{r}' definiert")

print("\n=== Geometrie-Inhalt ===")
bones = geo["bones"]
bn = [b["name"] for b in bones]
check(len(bn) == len(set(bn)), "keine doppelten Bones")
known = set(bn)
check(all(b.get("parent", b["name"]) in known for b in bones), "alle Parents existieren")
check(not any("neverRender" in b for b in bones), "kein neverRender (Vanilla-konform)")
REQ = {"Root", "AllBody", "Head", "LeftArm", "RightArm", "LeftLeg", "RightLeg"}
check(REQ <= set(bn), f"Kernskelett vorhanden ({len(REQ)} Bones)")
tw = geo["description"]["texture_width"]
bad = 0
for b in bones:
    for c in b.get("cubes", []):
        u, v = c["uv"]
        w, h, d = c["size"]
        if u + 2 * (w + d) > tw or v + h + d > 256:
            bad += 1
check(bad == 0, f"alle Box-UVs im 256er-Atlas ({bad} Fehler)")

# Animations-Bones muessen in der Geometrie existieren
ab = set()
for n, d in files.items():
    if n.startswith("animations/"):
        for a in d["animations"].values():
            ab |= set(a.get("bones", {}).keys())
check(ab <= known, f"Animations-Bones existieren in der Geometrie ({len(ab)} genutzt)")

print("\n=== Behavior Pack ===")
be = None
for n, d in files.items():
    if "minecraft:entity" in d:
        be = d["minecraft:entity"]
check(be is not None, "behavior entity gefunden")
check(be["description"]["identifier"] == ident, "behavior identifier == client identifier")
check(be["description"].get("is_summonable") is True, "is_summonable = true (/summon geht)")
comp = be["components"]
check("minecraft:health" in comp, "health definiert")
check(isinstance(comp.get("minecraft:scale"), dict), "scale ist ein Objekt (Vanilla-Format)")
check("minecraft:collision_box" in comp, "collision_box definiert")
check(comp.get("minecraft:navigation.walk", {}).get("can_walk") is True, "navigation kann laufen")
check("minecraft:nameable" in comp, "nameable (Namensschild zum Debuggen)")
check("pack_icon.png" in bpn and "pack_icon.png" in rpn, "Pack-Icons vorhanden")

print("\n=== Texte ===")
lang = rp.read("texts/en_US.lang").decode()
check(f"entity.{ident}.name=" in lang, "Entity-Name mit Credit in en_US.lang")
check("Dragon Girl (by Jan Wolf)" in lang, "'(by Jan Wolf)' im Anzeigename")
check(json.loads(rp.read("texts/languages.json")) == ["en_US"], "languages.json korrekt")

print("\n" + "=" * 60)
print(f"{checks - len(fails)}/{checks} Checks bestanden")
if fails:
    for f in fails:
        print("  -", f)
    sys.exit(1)
print("BEDROCK-ADDON VALIDE")
