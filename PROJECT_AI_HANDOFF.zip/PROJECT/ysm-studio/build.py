#!/usr/bin/env python3
"""
build.py — baut das Dragon-Girl-Paket (by Jan Wolf).

Erzeugt:
  out/DragonGirl_by_JanWolf.zip     YSM-Modell, laedt direkt im Yes-Steve-Model-Mod
  out/DragonGirl_by_JanWolf.bbmodel Blockbench-Projekt zum Weiterbearbeiten
  out/preview.png                   Texturatlas als Vorschau
  out/model_preview.svg             Seitenansicht der Geometrie (Drahtgitter)
"""
from __future__ import annotations
import json, os, zipfile, datetime
from PIL import Image, ImageDraw

import ysm_gen as Y
import dragon_girl as D
import textures as T

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pakete")
AUTHOR = "Jan Wolf"
NAME = "Dragon Girl"


def avatar_png(scale: int = 4) -> bytes:
    """GUI-Icon: stilisierter Drachenkopf, passend zur Amethyst-Palette."""
    S = 32
    im = Image.new("RGBA", (S, S), (24, 16, 40, 255))
    d = ImageDraw.Draw(im)
    P = T.PAL
    # Kopf
    d.rectangle([9, 8, 22, 23], fill=P["skin"] + (255,))
    # Haare
    d.rectangle([8, 6, 23, 11], fill=P["hair"] + (255,))
    d.rectangle([8, 6, 23, 7], fill=P["hair_hi"] + (255,))
    d.rectangle([8, 8, 9, 20], fill=P["hair"] + (255,))
    d.rectangle([22, 8, 23, 20], fill=P["hair"] + (255,))
    # Augen
    for ex in (11, 18):
        d.rectangle([ex, 14, ex + 2, 17], fill=P["eye_w"] + (255,))
        d.rectangle([ex + 1, 15, ex + 2, 17], fill=P["eye2"] + (255,))
        d.point((ex, 14), fill=P["eye_hi"] + (255,))
    # Hoerner
    for hx in (8, 21):
        for i in range(5):
            d.rectangle([hx, 6 - i, hx + 2, 6 - i],
                        fill=(P["gold"] if i % 2 else P["gold_sh"]) + (255,))
    # Ohren
    d.polygon([(7, 14), (4, 11), (7, 18)], fill=P["scale"] + (255,))
    d.polygon([(24, 14), (27, 11), (24, 18)], fill=P["scale"] + (255,))
    # Mund + Wangen
    d.rectangle([14, 20, 17, 20], fill=P["mouth"] + (255,))
    d.point((11, 19), fill=P["blush"] + (255,))
    d.point((20, 19), fill=P["blush"] + (255,))
    import io
    out = im.resize((S * scale, S * scale), Image.NEAREST)
    buf = io.BytesIO()
    out.save(buf, "PNG")
    return buf.getvalue()


def to_bbmodel(model: Y.Model, texture_png: bytes) -> dict:
    """Blockbench-Projekt (Modding-Entity-Format) aus der YSM-Geometrie."""
    import base64
    geo = model.to_json()["minecraft:geometry"][0]
    elements, outliner = [], []
    for i, b in enumerate(geo["bones"]):
        node = {"name": b["name"], "origin": [str(v) for v in b["pivot"]]}
        if b.get("parent"):
            node["parent"] = b["parent"]
        for j, c in enumerate(b.get("cubes", [])):
            eid = f"{b['name']}_cube_{j}"
            if isinstance(c["uv"], list):
                face_def = None
            else:
                face_def = c["uv"]
            elem = {
                "name": eid,
                "from": list(c["origin"]),
                "to": [c["origin"][k] + c["size"][k] for k in range(3)],
                "rotation": {"origin": b["pivot"], "axis": "y", "angle": 0},
                "uuid": eid,
            }
            if face_def is None:
                elem["uv"] = list(c["uv"])
            else:
                elem["faces"] = face_uv
            elements.append(elem)
        outliner.append({
            "name": b["name"],
            "origin": [str(v) for v in b["pivot"]],
            "children": [e["uuid"] for e in elements if e["uuid"].startswith(b["name"] + "_cube")],
        })
    return {
        "meta": {
            "format_version": "4.5",
            "model_format": "modded_entity",
            "box_uv": True,
            "creation_time": int(datetime.datetime.now().timestamp()),
            "author": AUTHOR,
            "model_identifier": model.identifier,
        },
        "name": f"{NAME} (by {AUTHOR})",
        "resolution": {"width": model.tex_w, "height": model.tex_h},
        "elements": elements,
        "outliner": outliner,
        "textures": [{
            "path": "",
            "name": "default.png",
            "folder": "textures",
            "namespace": "",
            "id": "0",
            "mode": "bitmap",
            "saved": True,
            "source": "data:image/png;base64," + base64.b64encode(texture_png).decode(),
        }],
    }


def side_view_svg(model: Y.Model, path: str, size: int = 640):
    """Einfache Draufsicht (X/Y) aller Cubes zum visuellen Gegencheck."""
    geo = model.to_json()["minecraft:geometry"][0]
    cubes = []
    for b in geo["bones"]:
        for c in b.get("cubes", []):
            o, s = c["origin"], c["size"]
            cubes.append((o[0], o[1], s[0], s[1]))
    if not cubes:
        return
    minx = min(c[0] for c in cubes); maxx = max(c[0] + c[2] for c in cubes)
    miny = min(c[1] for c in cubes); maxy = max(c[1] + c[3] for c in cubes)
    pad, h = 40, size
    sx = (size - 2 * pad) / max(maxx - minx, 1)
    sy = (h - 2 * pad) / max(maxy - miny, 1)
    sc = min(sx, sy)

    def X(v): return pad + (v - minx) * sc
    def Y(v): return h - pad - (v - miny) * sc   # y nach oben

    parts = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size} {h}" '
             f'style="background:#0b1020">']
    for x0, y0, w0, h0 in cubes:
        parts.append(f'<rect x="{X(x0):.1f}" y="{Y(y0+h0):.1f}" width="{w0*sc:.1f}" '
                     f'height="{h0*sc:.1f}" fill="#a78bfa" fill-opacity="0.28" '
                     f'stroke="#e9d5ff" stroke-width="1"/>')
    parts.append(f'<line x1="{X(0):.1f}" y1="{pad}" x2="{X(0):.1f}" y2="{h-pad}" '
                 f'stroke="#f472b6" stroke-dasharray="4"/>')
    parts.append(f'<text x="{pad}" y="24" fill="#94a3b8" font-family="sans-serif" '
                 f'font-size="14">Vorderansicht X/Y · {len(cubes)} Cubes · by {AUTHOR}</text>')
    parts.append('</svg>')
    open(path, "w", encoding="utf-8").write("".join(parts))


def main():
    os.makedirs(OUT, exist_ok=True)
    tex_png, origins, dims = T.build()          # 512er-Atlas (2x Dichte)
    # YSM/Blockbench bekommen die 1:1-Variante (256), Bedrock die 512er
    from PIL import Image as _Img
    import io as _io
    _im = _Img.open(_io.BytesIO(tex_png)).convert("RGBA").resize((256, 256), _Img.LANCZOS)
    _buf = _io.BytesIO(); _im.save(_buf, "PNG"); tex256 = _buf.getvalue()
    main_model, arm_model = D.build(origins)

    errors = Y.validate(main_model) + ["arm: " + e for e in Y.validate(arm_model, False)]
    if errors:
        for e in errors:
            print("FEHLER:", e)
        raise SystemExit(1)

    anim = Y.idle_animation()
    avatar = avatar_png()

    ysm_meta = {
        "spec": 2,
        "metadata": {
            "name": NAME,
            "tips": f"{NAME} — Amethyst-Drachenmaedchen (by {AUTHOR})",
            "license": {"type": "CC BY-NC 4.0"},
            "authors": [{
                "name": AUTHOR,
                "role": "model",
                "avatar": "avatar/dragon_girl.png",
                "comment": f"by {AUTHOR}",
            }],
        },
        "properties": {
            "height_scale": 0.75,
            "width_scale": 0.75,
            "preview_animation": "idle",
            "default_texture": "default",
            "render_layers_first": False,
            "free": True,
        },
        "files": {
            "player": {
                "model": {"main": "models/main.json", "arm": "models/arm.json"},
                "animation": {"main": "animations/main.animation.json"},
                # ACHTUNG: Liste, nicht Dict — so verwenden es die echten YSM-Modelle
                "texture": [{"uv": "textures/default.png"}],
            },
            "avatar": "avatar/dragon_girl.png",
        },
    }

    zip_path = os.path.join(OUT, f"{NAME.replace(' ', '')}_by_{AUTHOR.replace(' ', '')}.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("ysm.json", json.dumps(ysm_meta, ensure_ascii=False, indent=2))
        z.writestr("models/main.json", json.dumps(main_model.to_json(), indent=1))
        z.writestr("models/arm.json", json.dumps(arm_model.to_json(), indent=1))
        z.writestr("animations/main.animation.json", json.dumps(anim, indent=1))
        z.writestr("textures/default.png", tex256)
        z.writestr("avatar/dragon_girl.png", avatar)
        z.writestr("CREDITS.txt", (
            f"{NAME} - YSM-Modell\n"
            f"Autor: {AUTHOR} (by {AUTHOR})\n"
            f"Lizenz: CC BY-NC 4.0\n"
            f"Erstellt mit ysm-studio (Generator-Kit)\n"
            f"Kompatibel mit dem Yes-Steve-Model-Mod (ZIP-Import).\n"
            f"Hinweis: Eigenes Originaldesign. Keine Fremd-Assets enthalten.\n"
        ).encode("utf-8"))

    bb_path = zip_path.replace(".zip", ".bbmodel")
    with open(bb_path, "w", encoding="utf-8") as f:
        json.dump(to_bbmodel(main_model, tex256), f, ensure_ascii=False, indent=1)

    open(os.path.join(OUT, "preview.png"), "wb").write(tex_png)
    side_view_svg(main_model, os.path.join(OUT, "model_preview.svg"))
    make_extras(tex256, main_model)

    print("ZIP   :", zip_path, os.path.getsize(zip_path), "Bytes")
    print("BBMODEL:", bb_path, os.path.getsize(bb_path), "Bytes")
    print("Bones :", len(main_model.bones), "| Cubes:", sum(len(b.cubes) for b in main_model.bones))
    print("Atlas :", len(origins), "Regionen,", T.W, "x", T.H)
    return zip_path, bb_path




def make_extras(tex256, main_model):
    """avatar.png + character_front.png fuer die Showcase-Seite."""
    open(os.path.join(OUT, "avatar.png"), "wb").write(avatar_png())
    geo = main_model.to_json()["minecraft:geometry"][0]
    from PIL import Image
    import io
    tex = Image.open(io.BytesIO(tex256)).convert("RGBA")
    SCALE = 8
    W = H = 48 * SCALE
    canvas = Image.new("RGBA", (W, H), (18, 12, 30, 255))
    cubes = []
    for b in geo["bones"]:
        for c in b.get("cubes", []):
            ox, oy, oz = c["origin"]; w, h, d = c["size"]
            u, v = c["uv"]
            cubes.append((oz, ox, oy, w, h, int(u + w + d), int(v + d), int(w), int(h)))
    cubes.sort()
    for oz, ox, oy, w, h, su, sv, ww, hh in cubes:
        src = tex.crop((su, sv, su + ww, sv + hh)).resize(
            (int(w * SCALE), int(h * SCALE)), Image.NEAREST)
        canvas.alpha_composite(src, (int((ox + 16) * SCALE), int((40 - (oy + h)) * SCALE)))
    canvas.save(os.path.join(OUT, "character_front.png"))

if __name__ == "__main__":
    main()
