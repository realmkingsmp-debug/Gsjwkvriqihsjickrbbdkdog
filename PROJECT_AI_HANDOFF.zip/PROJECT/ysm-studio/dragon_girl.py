#!/usr/bin/env python3
"""
dragon_girl.py v2 — schoenere Geometrie (by Jan Wolf).

Anime-Chibi-Proportionen: grosser Kopf (12er-Wuerfel), lange Haare mit
fliessendem Zopf (4 rotierte Segmente), gebogene goldene Hoerner, gefaecherte
Fluegel, ausgestellter Rock (rotierte Panels), geschwungener Drachenschwanz
(4 Segmente mit Progression), Schuppen-Boots.

YSM-Kern-Bone-Namen bleiben erhalten (Required-Set), damit das YSM-Rig
(Animationen/Expressions) weiter funktioniert.
"""
from __future__ import annotations
from ysm_gen import Bone, Model


def build(origins) -> tuple[Model, Model]:
    m = Model("geometry.dragon_girl", 256, 256)

    def bone(name, pivot, parent=None, rotation=None, **kw):
        b = Bone(name, pivot, parent, rotation=rotation, **kw)
        m.bones.append(b)
        return b

    def cub(b, origin, size, region, mirror=False, inflate=0.0, rotation=None, pivot=None):
        u, v = origins[region]
        c = {"origin": list(origin), "size": list(size), "uv": [u, v]}
        if mirror:
            c["mirror"] = True
        if inflate:
            c["inflate"] = inflate
        if rotation is not None:
            c["rotation"] = list(rotation)
            c["pivot"] = list(pivot or b.pivot)
        b.cubes.append(c)
        return b

    # ---------------- Wirbelsaeule ----------------
    bone("Root", (0, 0, 0))
    bone("AllBody", (0, 19, 0), "Root")
    bone("MAllBody", (0, 19, 0), "AllBody", neverRender=True)
    bone("UpBody", (0, 21, 0), "AllBody")
    upper = bone("UpperBody", (0, 21, 0), "UpBody")
    bone("MUpperBody", (0, 21, 0), "UpperBody", neverRender=True)
    down = bone("DownBody", (0, 19, 0), "AllBody")

    cub(upper, (-4, 20, -2), (8, 11, 4), "torso")

    # ---------------- Huefte + Rock mit Flare ----------------
    cub(down, (-4, 16, -2), (8, 5, 4), "hips")
    cub(down, (-5, 13, -4), (10, 6, 8), "skirt")
    # 4 ausgestellte Panels (leicht rotiert, aussen versetzt gegen Z-Fighting)
    cub(down, (-5.2, 12.5, 3.9), (10.4, 7, 0.6), "skirt", rotation=[-10, 0, 0], pivot=(0, 19, 4))
    cub(down, (-5.2, 12.5, -4.5), (10.4, 7, 0.6), "skirt", rotation=[10, 0, 0], pivot=(0, 19, -4))
    cub(down, (4.9, 12.5, -4), (0.6, 7, 8), "skirt", rotation=[0, 0, -10], pivot=(5, 19, 0))
    cub(down, (-5.5, 12.5, -4), (0.6, 7, 8), "skirt", rotation=[0, 0, 10], pivot=(-5, 19, 0))

    # ---------------- Kopf ----------------
    bone("AllHead", (0, 31, 0), "UpperBody")
    head = bone("Head", (0, 31, 0), "AllHead")
    bone("MHead", (0, 31, 0), "Head", neverRender=True)
    cub(head, (-6, 31, -6), (12, 11, 12), "head")

    face = bone("Face", (0, 31, 0), "Head")
    bone("Eyes", (0, 35, 5.6), "Face")
    bone("Eyelid", (0, 35, 5.7), "Face")
    cub(bone("LeftEyelid", (3, 39, 6.0), "Eyelid"), (1.5, 38.5, 6.0), (3, 1.2, 0.25), "lid")
    cub(bone("RightEyelid", (-3, 39, 6.0), "Eyelid"), (-4.5, 38.5, 6.0), (3, 1.2, 0.25), "lid", mirror=True)
    bone("LeftEyebrow", (3, 38, 5.8), "Face")
    bone("RightEyebrow", (-3, 38, 5.8), "Face")

    # ---------------- Haare ----------------
    hair = bone("Hair", (0, 31, 0), "Head")
    cub(hair, (-6.5, 42, -6.5), (13, 2, 13), "hair_top", inflate=0.05)
    cub(hair, (-6.5, 31, -8), (13, 12, 2), "hair_back", inflate=0.05)
    cub(hair, (6, 32, -6), (2, 9, 12), "hair_l", inflate=0.05)
    cub(hair, (-8, 32, -6), (2, 9, 12), "hair_r", mirror=True, inflate=0.05)
    cub(hair, (-6.5, 39, 6), (13, 3, 2), "hair_fringe", inflate=0.05)
    # fliessender Zopf: 4 Segmente, immer weiter geneigt
    ht1 = bone("HairTail1", (0, 41, -7), "Hair", rotation=[14, 0, 0])
    cub(ht1, (-2.5, 33, -9.5), (5, 8, 5), "tail1")
    ht2 = bone("HairTail2", (0, 33, -10.5), "HairTail1", rotation=[10, 0, 0])
    cub(ht2, (-2, 26, -12), (4, 7, 4), "tail2")
    ht3 = bone("HairTail3", (0, 26, -13), "HairTail2", rotation=[8, 0, 0])
    cub(ht3, (-1.5, 20, -14), (3, 6, 3), "tail3")
    cub(bone("HairTail4", (0, 20, -14.5), "HairTail3", rotation=[6, 0, 0]),
        (-1, 15, -15), (2, 5, 2), "tail4")

    # ---------------- Hoerner (gebogen) ----------------
    hl = bone("HornLeft", (3.5, 42, -1), "Head", rotation=[-8, 0, -18])
    cub(hl, (2.5, 42, -2.5), (3, 6, 3), "horn_l")
    hr = bone("HornRight", (-3.5, 42, -1), "Head", rotation=[-8, 0, 18])
    cub(hr, (-5.5, 42, -2.5), (3, 6, 3), "horn_r", mirror=True)

    # ---------------- Drachenohren ----------------
    el = bone("EarLeft", (6, 37, 0), "Head", rotation=[0, 0, -24])
    cub(el, (6, 35, -1), (4, 5, 2), "ear_l")
    er = bone("EarRight", (-6, 37, 0), "Head", rotation=[0, 0, 24])
    cub(er, (-10, 35, -1), (4, 5, 2), "ear_r", mirror=True)

    # ---------------- Arme (leichter A-Pose) ----------------
    bone("Arm", (0, 29, 0), "UpperBody")
    bone("LeftShoulderLocator", (4, 30, 0), "UpperBody", neverRender=True)
    bone("RightShoulderLocator", (-4, 30, 0), "UpperBody", neverRender=True)

    larm = bone("LeftArm", (5, 30, 0), "Arm", rotation=[0, 0, 6])
    cub(larm, (3.5, 26, -2), (4, 4, 4), "shoulder")
    cub(larm, (3.8, 21, -1.5), (3, 6, 3), "arm")
    lfore = bone("LeftForeArm", (5.3, 21, 0), "LeftArm")
    cub(lfore, (3.8, 15.5, -1.5), (3, 6, 3), "forearm")
    lhand = bone("LeftHand", (5.3, 15.5, 0), "LeftForeArm")
    cub(lhand, (3.8, 12.5, -1.5), (3, 3, 3), "hand")
    bone("LeftHandLocator", (5.3, 12.5, 0), "LeftHand", neverRender=True)

    rarm = bone("RightArm", (-5, 30, 0), "Arm", rotation=[0, 0, -6])
    cub(rarm, (-7.5, 26, -2), (4, 4, 4), "shoulder", mirror=True)
    cub(rarm, (-6.8, 21, -1.5), (3, 6, 3), "arm", mirror=True)
    rfore = bone("RightForeArm", (-5.3, 21, 0), "RightArm")
    cub(rfore, (-6.8, 15.5, -1.5), (3, 6, 3), "forearm", mirror=True)
    rhand = bone("RightHand", (-5.3, 15.5, 0), "RightForeArm")
    cub(rhand, (-6.8, 12.5, -1.5), (3, 3, 3), "hand", mirror=True)
    bone("RightHandLocator", (-5.3, 12.5, 0), "RightHand", neverRender=True)
    bone("ElytraLocator", (0, 29, 2), "UpperBody", neverRender=True)

    # ---------------- Fluegel (gefaechert, nach oben hinten) ----------------
    for side, s in (("Left", 1), ("Right", -1)):
        w = bone(f"Wing{side}", (s * 3, 29, -2), "UpperBody",
                 rotation=[18, 0, s * 24])
        # rechte Seite: Positionen explizit gespiegelt (mirror spiegelt nur UVs)
        wb_x = 2 if s > 0 else -11
        cub(w, (wb_x, 28, -3), (9, 2, 2), "wingbone")
        mem = bone(f"WingMembrane{side}", (s * 11, 29, -3), f"Wing{side}",
                   rotation=[-12, 0, s * 8])
        mm_x = 11 if s > 0 else -23
        cub(mem, (mm_x, 19, -3.5), (12, 10, 1), "wingmem")

    # ---------------- Beine ----------------
    lleg = bone("LeftLeg", (2, 16, 0), "DownBody")
    cub(lleg, (0.5, 9, -2), (4, 8, 4), "leg")
    llow = bone("LeftLowerLeg", (2, 9, 0), "LeftLeg")
    cub(llow, (0.5, 2.5, -2), (4, 7, 4), "lowerleg")
    cub(bone("LeftFoot", (2, 2.5, 0), "LeftLowerLeg"), (0.5, 0, -3), (4, 3, 6), "foot")

    rleg = bone("RightLeg", (-2, 16, 0), "DownBody")
    cub(rleg, (-4.5, 9, -2), (4, 8, 4), "leg", mirror=True)
    rlow = bone("RightLowerLeg", (-2, 9, 0), "RightLeg")
    cub(rlow, (-4.5, 2.5, -2), (4, 7, 4), "lowerleg", mirror=True)
    cub(bone("RightFoot", (-2, 2.5, 0), "RightLowerLeg"), (-4.5, 0, -3), (4, 3, 6), "foot", mirror=True)

    # ---------------- Drachenschwanz (verankert, lueckenlos, Bogen) ----
    t1 = bone("Tail1", (0, 17, -3), "DownBody", rotation=[-10, 0, 0])
    cub(t1, (-2, 15, -7), (4, 4, 5), "seg1")
    t2 = bone("Tail2", (0, 17.5, -7), "Tail1", rotation=[-14, 0, 0])
    cub(t2, (-1.5, 15.8, -11.5), (3, 3, 5), "seg2")
    t3 = bone("Tail3", (0, 18, -11.5), "Tail2", rotation=[-16, 0, 0])
    cub(t3, (-1, 16.5, -15), (2, 2, 4), "seg3")
    cub(bone("Tail4", (0, 18.5, -15), "Tail3", rotation=[-18, 0, 0]),
        (-1, 17, -18), (2, 2, 3), "seg4")

    # ---------------- First-Person-Arm ----------------
    arm = Model("geometry.dragon_girl_arm", 32, 32)
    root = arm.add(Bone("Root", (8, 0, 0)))
    root.cubes.append({"origin": [5.5, -1, -12], "size": [3, 3, 12], "uv": [0, 0]})
    return m, arm
