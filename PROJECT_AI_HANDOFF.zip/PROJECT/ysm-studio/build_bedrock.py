#!/usr/bin/env python3
"""
build_bedrock.py — Dragon Girl (by Jan Wolf) als Minecraft-Bedrock-Add-on.

Erzeugt:
  out/bedrock/DragonGirl_by_JanWolf_RP.mcpack   Resource Pack
  out/bedrock/DragonGirl_by_JanWolf_BP.mcpack   Behavior Pack
  out/bedrock/DragonGirl_by_JanWolf.mcaddon     beide Packs, Doppelklick-Import

Die Geometrie kommt unveraendert aus dragon_girl.py — das YSM-Format IST das
Bedrock-Entity-Format (geometry 1.12.0, per-bone pivots, Box-UV, neverRender).
"""
from __future__ import annotations
import json, os, shutil, zipfile

import ysm_gen as Y
import dragon_girl as D
import textures as T

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pakete", "bedrock")
ID = "janwolf:dragon_girl"

# Feste UUIDs, damit Updates die Packs nicht "neu" machen
UUID_RP_HEADER = "2ba25fbd-e986-456a-a28a-f2a65f15076d"
UUID_RP_MODULE = "d06b87ad-6594-46e1-a34e-299d7603aa2e"
UUID_BP_HEADER = "f81651d5-31a7-4af4-991f-fe41edb4ced0"
UUID_BP_MODULE = "e8613076-97d6-4d35-a877-d84aef5127ef"

AUTHOR = "Jan Wolf"


def manifest(kind: str, title: str, header: str, module: str,
             depends_on: str) -> dict:
    """Manifest v2 mit Dependency auf das jeweils andere Pack.

    Ohne diese Verknüpfung aktiviert Bedrock beim .mcaddon-Import mitunter nur
    eine Hälfte -> die Entität existiert, wird aber ohne Geometrie/Textur
    dargestellt (unsichtbar). Offizielle Empfehlung fuer Entity-Add-ons."""
    return {
        "format_version": 2,
        "header": {
            "name": title,
            "description": f"Dragon Girl - Amethyst-Drachenmaedchen (by {AUTHOR})",
            "uuid": header,
            "version": [1, 0, 1],
            "min_engine_version": [1, 16, 0],
        },
        "modules": [{
            "type": kind,
            "uuid": module,
            "version": [1, 0, 1],
        }],
        "dependencies": [{
            "uuid": depends_on,
            "version": [1, 0, 1],
        }],
    }


def main():
    shutil.rmtree(OUT, ignore_errors=True)
    rp = os.path.join(OUT, "rp")
    bp = os.path.join(OUT, "bp")
    for d in (rp, bp):
        os.makedirs(d, exist_ok=True)

    tex_png, origins, _dims = T.build()
    main_model, _arm = D.build(origins)

    errs = Y.validate(main_model)
    if errs:
        for e in errs:
            print("FEHLER:", e)
        raise SystemExit(1)

    # ---------------- Resource Pack ----------------
    json.dump(manifest("resources", f"Dragon Girl RP (by {AUTHOR})",
                       UUID_RP_HEADER, UUID_RP_MODULE, UUID_BP_HEADER),
              open(f"{rp}/manifest.json", "w"), indent=2)

    geo = main_model.to_json()
    def _strip_neverrender(d):
        if isinstance(d, dict):
            d.pop("neverRender", None)
            for v in d.values():
                _strip_neverrender(v)
        elif isinstance(d, list):
            for v in d:
                _strip_neverrender(v)
    _strip_neverrender(geo)          # von Vanilla-Schemas nicht akzeptiert
    os.makedirs(f"{rp}/models/entity", exist_ok=True)
    json.dump(geo, open(f"{rp}/models/entity/dragon_girl.geo.json", "w"), indent=1)

    os.makedirs(f"{rp}/textures/entity", exist_ok=True)
    open(f"{rp}/textures/entity/dragon_girl.png", "wb").write(tex_png)

    # Animationen: IDs muessen "animation.<...>" heissen
    anims = Y.idle_animation()
    renamed = {
        "animation.dragon_girl.idle": anims["animations"]["idle"],
        "animation.dragon_girl.walk": anims["animations"]["walk"],
    }
    os.makedirs(f"{rp}/animations", exist_ok=True)
    json.dump({"format_version": "1.8.0", "animations": renamed},
              open(f"{rp}/animations/dragon_girl.animation.json", "w"), indent=1)

    os.makedirs(f"{rp}/animation_controllers", exist_ok=True)
    json.dump({
        "format_version": "1.10.0",
        "animation_controllers": {
            "controller.animation.dragon_girl.move": {
                "initial_state": "idle",
                "states": {
                    "idle": {
                        "animations": ["idle"],
                        "transitions": [{"walking": "query.modified_move_speed > 0.1"}],
                    },
                    "walking": {
                        "animations": ["walk"],
                        "transitions": [{"idle": "query.modified_move_speed < 0.1"}],
                    },
                },
            }
        },
    }, open(f"{rp}/animation_controllers/dragon_girl.controller.json", "w"), indent=2)

    os.makedirs(f"{rp}/render_controllers", exist_ok=True)
    json.dump({
        "format_version": "1.10.0",
        "render_controllers": {
            "controller.render.dragon_girl": {
                "geometry": "Geometry.default",
                "materials": [{"*": "Material.default"}],
                "textures": ["Texture.default"],
            }
        },
    }, open(f"{rp}/render_controllers/dragon_girl.render_controller.json", "w"), indent=2)

    os.makedirs(f"{rp}/entity", exist_ok=True)
    json.dump({
        "format_version": "1.10.0",
        "minecraft:client_entity": {
            "description": {
                "identifier": ID,
                "min_engine_version": "1.16.0",
                "materials": {"default": "entity_alphatest"},
                "textures": {"default": "textures/entity/dragon_girl"},
                "geometry": {"default": "geometry.dragon_girl"},
                "animations": {
                    "idle": "animation.dragon_girl.idle",
                    "walk": "animation.dragon_girl.walk",
                    "move": "controller.animation.dragon_girl.move",
                },
                "scripts": {"animate": ["move"]},
                "render_controllers": ["controller.render.dragon_girl"],
                "spawn_egg": {
                    "base_color": "#7c5cbf",
                    "overlay_color": "#f0c86e",
                },
            }
        },
    }, open(f"{rp}/entity/dragon_girl.entity.json", "w"), indent=2)

    os.makedirs(f"{rp}/texts", exist_ok=True)
    open(f"{rp}/texts/en_US.lang", "w").write(
        f"entity.{ID}.name=Dragon Girl (by {AUTHOR})\n"
        f"item.spawn_egg.entity.{ID}.name=Dragon Girl spawnen\n")
    json.dump(["en_US"], open(f"{rp}/texts/languages.json", "w"))

    # Pack-Icon: generiertes Icon nutzen, falls vorhanden (fuer kuenftige
    # Addons: erst Bildgenerator-Artefakt in assets/pack_icon.png legen),
    # sonst gezeichneter Fallback.
    import io
    from PIL import Image
    asset = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "pack_icon.png")
    if os.path.exists(asset):
        img = Image.open(asset).convert("RGBA").resize((512, 512), Image.LANCZOS)
        buf = io.BytesIO(); img.save(buf, "PNG"); icon = buf.getvalue()
        print("Icon: generiertes Asset (512x512)")
    else:
        icon = _avatar()
        print("Icon: Fallback (gezeichnet)")
    open(f"{rp}/pack_icon.png", "wb").write(icon)

    # ---------------- Behavior Pack ----------------
    json.dump(manifest("data", f"Dragon Girl BP (by {AUTHOR})",
                       UUID_BP_HEADER, UUID_BP_MODULE, UUID_RP_HEADER),
              open(f"{bp}/manifest.json", "w"), indent=2)

    os.makedirs(f"{bp}/entities", exist_ok=True)
    json.dump({
        "format_version": "1.16.0",
        "minecraft:entity": {
            "description": {
                "identifier": ID,
                "is_summonable": True,
                "is_experimental": False,
            },
            "components": {
                "minecraft:type_family": {"family": ["mob", "dragon_girl"]},
                "minecraft:scale": {"value": 0.75},
                "minecraft:health": {"value": 20, "max": 20},
                "minecraft:collision_box": {"width": 0.6, "height": 2.0},
                "minecraft:movement": {"value": 0.3},
                "minecraft:movement.basic": {},
                "minecraft:navigation.walk": {
                    "can_walk": True,
                    "can_path_over_water": False,
                    "avoid_damage_blocks": True,
                },
                "minecraft:nameable": {},
                "minecraft:jump.static": {},
                "minecraft:physics": {},
                "minecraft:behavior.float": {"priority": 0},
                "minecraft:behavior.random_stroll": {"priority": 6, "speed_multiplier": 1.0},
                "minecraft:behavior.look_at_player": {
                    "priority": 7, "look_distance": 6.0, "probability": 0.02},
                "minecraft:behavior.random_look_around": {"priority": 7},
                "minecraft:experience_reward": {"on_death": "query.last_hit_by_player ? 5 : 0"},
            },
        },
    }, open(f"{bp}/entities/dragon_girl.behavior.json", "w"), indent=2)
    open(f"{bp}/pack_icon.png", "wb").write(icon)

    # ---------------- Packen ----------------
    def zipdir(root, path):
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for dp, _, fs in os.walk(root):
                for f in sorted(fs):
                    p = os.path.join(dp, f)
                    z.write(p, os.path.relpath(p, root))

    rp_pack = os.path.join(OUT, f"DragonGirl_by_{AUTHOR.replace(' ', '')}_RP.mcpack")
    bp_pack = os.path.join(OUT, f"DragonGirl_by_{AUTHOR.replace(' ', '')}_BP.mcpack")
    addon = os.path.join(OUT, f"DragonGirl_by_{AUTHOR.replace(' ', '')}.mcaddon")
    zipdir(rp, rp_pack)
    zipdir(bp, bp_pack)
    with zipfile.ZipFile(addon, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(rp_pack, os.path.basename(rp_pack))
        z.write(bp_pack, os.path.basename(bp_pack))

    for p in (rp_pack, bp_pack, addon):
        print(os.path.basename(p), os.path.getsize(p), "Bytes")


def _avatar() -> bytes:
    import io
    from PIL import Image, ImageDraw
    S = 64
    im = Image.new("RGBA", (S, S), (24, 16, 40, 255))
    d = ImageDraw.Draw(im)
    P = T.PAL
    d.rectangle([18, 16, 45, 47], fill=P["skin"] + (255,))
    d.rectangle([16, 12, 47, 22], fill=P["hair"] + (255,))
    d.rectangle([16, 12, 47, 14], fill=P["hair_hi"] + (255,))
    d.rectangle([16, 16, 19, 40], fill=P["hair"] + (255,))
    d.rectangle([44, 16, 47, 40], fill=P["hair"] + (255,))
    for ex in (22, 36):
        d.rectangle([ex, 28, ex + 5, 34], fill=P["eye_w"] + (255,))
        d.rectangle([ex + 2, 30, ex + 5, 34], fill=P["eye"] + (255,))
        d.point((ex, 28), fill=P["eye_hi"] + (255,))
    for hx in (16, 42):
        for i in range(10):
            d.rectangle([hx, 12 - i, hx + 4, 12 - i],
                        fill=(P["gold"] if i % 2 else P["gold_sh"]) + (255,))
    d.polygon([(14, 28), (8, 22), (14, 36)], fill=P["scale"] + (255,))
    d.polygon([(49, 28), (55, 22), (49, 36)], fill=P["scale"] + (255,))
    d.rectangle([28, 40, 35, 41], fill=P["mouth"] + (255,))
    d.point((22, 38), fill=P["blush"] + (255,))
    d.point((41, 38), fill=P["blush"] + (255,))
    b = io.BytesIO()
    im.save(b, "PNG")
    return b.getvalue()


if __name__ == "__main__":
    main()
