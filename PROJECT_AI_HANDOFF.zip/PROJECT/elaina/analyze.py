#!/usr/bin/env python3
"""Analysiert alle geklonten Repos von Elaina69 lokal (ohne API-Kosten)."""
import os, re, json, subprocess, sys
from collections import Counter, defaultdict

ROOT = "/home/user/elaina"
REPOS = os.path.join(ROOT, "repos")

SKIP_DIRS = {".git", "node_modules", "dist", "build", ".next", "__pycache__",
             ".venv", "venv", "coverage", ".idea", ".vscode", "target", "out"}

EXT_LANG = {
    ".js": "JavaScript", ".mjs": "JavaScript", ".cjs": "JavaScript",
    ".ts": "TypeScript", ".tsx": "TypeScript (JSX)", ".jsx": "JavaScript (JSX)",
    ".py": "Python", ".ipynb": "Jupyter Notebook", ".css": "CSS", ".scss": "SCSS",
    ".html": "HTML", ".json": "JSON", ".md": "Markdown", ".yml": "YAML", ".yaml": "YAML",
    ".sh": "Shell", ".bat": "Batch", ".cmd": "Batch", ".c": "C", ".cpp": "C++", ".h": "C/C++ Header",
    ".cs": "C#", ".java": "Java", ".rs": "Rust", ".go": "Go", ".toml": "TOML",
    ".cfg": "Config", ".ini": "Config", ".env": "Config", ".user.js": "Userscript",
    ".txt": "Text", ".svg": "SVG", ".sql": "SQL",
}

# Dateien, die wir beim Zaehlen ignorieren (generiert / Binaerdaten / Lockfiles)
GENERATED_NAMES = {"package-lock.json", "pnpm-lock.yaml", "yarn.lock", "composer.lock",
                   "Cargo.lock", "poetry.lock", "Gemfile.lock"}

SECRET_PATTERNS = [
    ("GitHub-Token",            r"gh[pousr]_[A-Za-z0-9]{20,}"),
    ("GitHub fine-grained",     r"github_pat_[A-Za-z0-9_]{20,}"),
    ("Discord Webhook",         r"discord(?:app)?\.com/api/webhooks/\d+/[A-Za-z0-9_\-]+"),
    ("Discord Bot Token",       r"[MN][A-Za-z\d]{23,}\.[\w-]{6}\.[\w-]{27,}"),
    ("Slack Token",             r"xox[baprs]-[A-Za-z0-9-]{10,}"),
    ("AWS Access Key",          r"AKIA[0-9A-Z]{16}"),
    ("Google API Key",          r"AIza[0-9A-Za-z\-_]{35}"),
    ("OpenAI Key",              r"sk-[A-Za-z0-9]{20,}"),
    ("Anthropic Key",           r"sk-ant-[A-Za-z0-9\-_]{20,}"),
    ("Telegram Bot Token",      r"\b\d{8,10}:[A-Za-z0-9_\-]{30,}\b"),
    ("Private Key Block",       r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    ("Riot/LoL Auth Token",     r"(?i)\b(riot_?auth|auth_?token|access_?token)\b\s*[:=]\s*['\"][^'\"]{20,}"),
    ("Hartcodiertes Passwort",  r"(?i)\b(password|passwd|pwd)\b\s*[:=]\s*['\"][^'\"]{6,}['\"]"),
    ("Generisches Geheimnis",   r"(?i)\b(secret|api_?key|apikey|token)\b\s*[:=]\s*['\"][A-Za-z0-9_\-\.]{16,}['\"]"),
]
SECRET_RE = [(n, re.compile(p)) for n, p in SECRET_PATTERNS]

TEXT_EXT = {".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".py", ".css", ".scss", ".html",
            ".json", ".md", ".yml", ".yaml", ".sh", ".bat", ".cmd", ".c", ".cpp", ".h",
            ".cs", ".java", ".rs", ".go", ".toml", ".cfg", ".ini", ".txt", ".svg", ".sql",
            ".user.js", ".env", ".example", ".ipynb", ".sln", ".vcxproj", ".props", ".targets"}


def is_text(path):
    name = os.path.basename(path)
    if name in GENERATED_NAMES:
        return True
    ext = os.path.splitext(name)[1].lower()
    return ext in TEXT_EXT


def iter_files(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for fn in filenames:
            yield os.path.join(dirpath, fn)


def git(root, *args):
    try:
        return subprocess.run(["git", "-C", root, *args], capture_output=True,
                              text=True, timeout=60).stdout.strip()
    except Exception:
        return ""


def analyze_repo(path):
    name = os.path.basename(path)
    r = {"repo": name}
    ext_lines = Counter(); ext_bytes = Counter(); ext_files = Counter()
    total_files = 0; total_bytes = 0
    biggest = []
    secrets = []
    exts_all = Counter()

    for f in iter_files(path):
        rel = os.path.relpath(f, path)
        try:
            size = os.path.getsize(f)
        except OSError:
            continue
        total_files += 1; total_bytes += size
        base = os.path.basename(f)
        ext = os.path.splitext(base)[1].lower()
        if base.endswith(".user.js"):
            ext = ".user.js"
        exts_all[ext or "(keine)"] += 1
        biggest.append((size, rel))
        if is_text(f):
            try:
                with open(f, "r", encoding="utf-8", errors="replace") as fh:
                    data = fh.read()
            except Exception:
                continue
            n_lines = data.count("\n") + (1 if data and not data.endswith("\n") else 0)
            ext_lines[ext or "(keine)"] += n_lines
            ext_bytes[ext] += len(data)
            ext_files[ext or "(keine)"] += 1
            if base not in GENERATED_NAMES and size < 400_000:
                for i, line in enumerate(data.splitlines(), 1):
                    for label, rx in SECRET_RE:
                        if rx.search(line):
                            secrets.append({"datei": rel, "zeile": i, "typ": label,
                                            "kontext": line.strip()[:160]})

    biggest.sort(reverse=True)
    r["dateien"] = total_files
    r["bytes"] = total_bytes
    r["zeilen"] = sum(ext_lines.values())
    r["sprachen"] = ext_lines.most_common(8)
    r["dateitypen"] = exts_all.most_common(10)
    r["groesste_dateien"] = [(s, p) for s, p in biggest[:6]]
    r["secrets"] = secrets[:25]

    # Git-Infos (shallow -> nur lokaler Commit, aber Autor/Datum nutzbar)
    log = git(path, "log", "--pretty=%H%x09%an%x09%ae%x09%ad%x09%s", "--date=short", "-20")
    commits = [l.split("\t") for l in log.splitlines() if l]
    r["letzte_commits"] = commits[:10]
    r["commit_anzahl_lokal"] = len(commits)

    # README
    readme = None
    for cand in ("README.md", "readme.md", "README.MD", "README.txt", "Readme.md"):
        p = os.path.join(path, cand)
        if os.path.exists(p):
            readme = p; break
    if readme:
        with open(readme, "r", encoding="utf-8", errors="replace") as fh:
            txt = fh.read()
        r["readme_zeichen"] = len(txt)
        heads = [l.strip() for l in txt.splitlines() if l.strip().startswith("#")]
        r["readme_headlines"] = heads[:12]
        r["readme_anfang"] = txt[:600]
    else:
        r["readme_zeichen"] = 0
        r["readme_headlines"] = []
        r["readme_anfang"] = ""

    # package.json
    pk = os.path.join(path, "package.json")
    if os.path.exists(pk):
        try:
            with open(pk, encoding="utf-8") as fh:
                d = json.load(fh)
            r["pkg"] = {"name": d.get("name"), "version": d.get("version"),
                        "deps": sorted((d.get("dependencies") or {}).keys()),
                        "devDeps": sorted((d.get("devDependencies") or {}).keys()),
                        "scripts": list((d.get("scripts") or {}).keys())}
        except Exception:
            r["pkg"] = None
    else:
        r["pkg"] = None

    req = os.path.join(path, "requirements.txt")
    r["requirements"] = None
    if os.path.exists(req):
        with open(req, encoding="utf-8", errors="replace") as fh:
            r["requirements"] = [l.strip() for l in fh if l.strip() and not l.startswith("#")]

    r["dateiliste"] = [os.path.relpath(f, path) for f in iter_files(path)][:400]
    return r


def main():
    out = {}
    for name in sorted(os.listdir(REPOS)):
        p = os.path.join(REPOS, name)
        if not os.path.isdir(p):
            continue
        print("analysiere", name, flush=True)
        try:
            out[name] = analyze_repo(p)
        except Exception as e:
            out[name] = {"error": str(e)}
    with open(os.path.join(ROOT, "data", "analyse_raw.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    print("fertig:", len(out), "Repos")


if __name__ == "__main__":
    main()
