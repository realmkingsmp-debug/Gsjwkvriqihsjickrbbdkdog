# GitHub-Analyse: **Elaina69** („Elaina Da Catto")

**Stand:** 20.09.2026 · **Ort:** Viet Nam · **Blog:** elainadacatto.online ·
**Account seit:** 15.11.2021 · **Follower:** 252 · **Following:** 0
**Datenbasis:** GitHub-REST-API (User, Repos, Stars, Gists, Languages) + 36 lokale Klone (`git clone --depth 1`)

---

## Kurzfazit

Kein Sammelbecken, sondern ein klar umrissenes Portfolio:

- **96 % aller Sterne (3.363 von 3.495)** kommen aus einem einzigen Repo: `Yes-Steve-Model-Repo`.
- Die eigentliche Engineering-Arbeit steckt in einem zweiten Cluster: **25 von 36 Repos** sind Themes und
  Plugins für den League-of-Legends-Client (Pengu Loader / League Loader).
- Dazu zwei vietnamesische Uni-Projekte (Machine Learning & Computer Vision) und einige Bot-/Web-Automatisierungen.
- Stack fast durchgängig **TypeScript/JavaScript** mit moderner Toolchain (Vite, ESLint, Husky, pnpm).
- **Sicherheits-Scan: 0 Treffer** auf Tokens, Keys, Webhooks oder hartkodierte Passwörter.

| Kennzahl | Wert |
|---|---|
| Öffentliche Repos | 36 (davon 3 Forks, 5 archiviert) |
| Sterne gesamt | 3.495 |
| Forks gesamt | 400 |
| Gists | 3 |
| Codezeilen (lokal gezählt) | 380.697 |
| Dateien (lokal gezählt) | 82.657 |
| Größe der Klone | 3,4 GB |
| Markierte Repos (Sterne) | 11 |
| Lizenzen | 19× MIT, 17× keine |

---

## 1 · Sterne-Verteilung (logarithmisch)

| Repo | Sterne |
|---|---:|
| Yes-Steve-Model-Repo | ★ 3.363 |
| Elaina-theme | ★ 103 |
| Auto-Ban | ★ 5 |
| Pengu-plugins | ★ 5 |
| Elaina-theme-data | ★ 3 |
| Elaina69.github.io | ★ 3 |
| auto-message / Elaina69 / Get-Mastery-Score | ★ 2 |
| 8 weitere Repos | ★ 1 |
| 12 Repos | ★ 0 |

## 2 · Aktivität über die Zeit

| Jahr | Repos erstellt | letzter Push |
|---|---:|---:|
| 2023 | 15 | 8 |
| 2024 | 7 | 6 |
| 2025 | 7 | 1 |
| 2026 | 7 | **21** |

- **2023** – Gründungsphase: fast alles LoL-Client-Themes (Skadi, Nothing, Theme-Template, Legacy). Vieles heute archiviert.
- **2025** – 7 Repos angelegt, nur 1 berührt → Vorbereitung der TypeScript-Plugin-Serie.
- **2026** – 21 von 36 Repos zuletzt gepusht. Aktuelle Arbeit: Uni-Projekte, Vite-basierte TS-Plugins, Theme.

---

## 3 · Alle 36 Repos

| Repo | ★ | Forks | Sprache (lokal gezählt) | Zeilen | Dateien | Größe | Lizenz | Erstellt | Letzter Push |
|---|--:|--:|---|--:|--:|--:|---|---|---|
| Yes-Steve-Model-Repo | 3,363 | 382 | – (nur Assets/Text) | 36 | 1,116 | 796.1 MB | – | 2023-08-25 | 2026-08-18 |
| Elaina-theme | 103 | 11 | TS 10,875, CSS 2,709, JS 1,822 | 24,230 | 259 | 643.8 MB | MIT | 2023-02-01 | 2026-08-09 |
| Auto-Ban | 5 | 2 | JS 6,559, Shell 406 | 8,995 | 72 | 296.0 KB | MIT | 2025-08-05 | 2026-07-11 |
| Pengu-plugins | 5 | 0 | JS 527, TS 168 | 3,608 | 17 | 2.0 MB | – | 2023-05-19 | 2026-08-07 |
| Elaina-theme-data | 3 | 5 | JS 2,226 | 2,355 | 54 | 110.5 MB | MIT | 2023-07-11 | 2026-08-04 |
| Elaina69.github.io | 3 | 0 | JS 5,826, CSS 2,882, HTML 548 | 20,558 | 134 | 129.5 MB | – | 2024-12-11 | 2026-06-24 |
| auto-message | 2 | 0 | JS 80 | 91 | 4 | 3.0 KB | MIT | 2024-01-14 | 2024-01-14 |
| Elaina69 | 2 | 0 | – (nur Assets/Text) | 49 | 1 | 13.0 KB | – | 2023-03-13 | 2026-07-12 |
| Get-Mastery-Score | 2 | 0 | JS 92 | 93 | 5 | 3.0 KB | MIT | 2024-04-13 | 2024-04-13 |
| auto-honor-v2 | 1 | 0 | TS 1,127 | 4,362 | 16 | 47.0 KB | – | 2025-02-06 | 2026-05-09 |
| Auto-Signin-SKport-Endfield | 1 | 0 | JS 1,460, Shell 236 | 2,495 | 27 | 37.0 KB | – | 2026-03-08 | 2026-06-21 |
| Blank-Settings-Utils | 1 | 0 | JS 154 | 291 | 6 | 6.0 KB | MIT | 2024-06-03 | 2024-09-15 |
| Elaina-theme-legacy | 1 | 0 | CSS 534, JS 161 | 695 | 14 | 44.0 MB | – | 2023-01-15 | 2023-01-18 |
| LOL-audio-replacer | 1 | 0 | TS 1,495, JS 77 | 4,468 | 22 | 7.5 MB | – | 2026-06-14 | 2026-07-12 |
| Nothing-Theme *(archiviert)* | 1 | 0 | CSS 292, JS 261 | 561 | 5 | 8.0 KB | MIT | 2023-03-25 | 2023-03-26 |
| Wallpaper-Engine-for-LoL-activityCenter | 1 | 0 | TS 473, JS 9 | 1,421 | 11 | 21.0 KB | MIT | 2025-04-03 | 2026-05-10 |
| Auto-honor *(archiviert)* | 0 | 0 | JS 472 | 478 | 2 | 11.0 KB | – | 2023-11-14 | 2024-03-31 |
| Bad-apple-status | 0 | 0 | JS 90 | 92,089 | 4 | 36.1 MB | – | 2023-11-27 | 2024-01-03 |
| better-arknights-headhunting-history | 0 | 0 | JS 433 | 462 | 3 | 8.0 KB | MIT | 2026-01-17 | 2026-01-17 |
| Elaina-Vendetta *(archiviert)* | 0 | 0 | – (nur Assets/Text) | 193 | 2 | 26.0 KB | – | 2023-05-16 | 2023-05-17 |
| Elaina-web-scipts | 0 | 0 | JS 319, Userscript 100 | 423 | 6 | 8.0 KB | MIT | 2025-12-22 | 2026-03-30 |
| eog-mass-report | 0 | 0 | TS 1,021 | 4,255 | 17 | 46.0 KB | MIT | 2025-01-31 | 2026-06-13 |
| fake-reward-badge | 0 | 0 | TS 194 | 3,430 | 10 | 32.0 KB | MIT | 2024-12-12 | 2026-05-10 |
| fake-runes-pages | 0 | 0 | TS 999, JS 541 | 2,446 | 15 | 30.0 KB | – | 2025-02-04 | 2026-05-10 |
| Force-jungle-lane | 0 | 0 | JS 25 | 35 | 2 | 2.0 KB | – | 2023-11-06 | 2023-11-15 |
| Hide-friend-list | 0 | 0 | JS 1 | 3 | 2 | 24.0 KB | – | 2023-11-06 | 2023-11-15 |
| Invite-all-friends | 0 | 0 | JS 116 | 120 | 2 | 5.0 KB | – | 2023-11-06 | 2023-12-07 |
| Moe-Counter *(Fork)* | 0 | 0 | JS 758 | 2,432 | 555 | 1.9 MB | MIT | 2024-12-11 | 2024-12-03 |
| Old-Mastery-Icons | 0 | 0 | TS 353 | 1,263 | 9 | 13.0 KB | MIT | 2026-05-10 | 2026-05-10 |
| PenguLoader *(Fork)* | 0 | 0 | TS 2,034, TS 1,716, C 560 | 16,352 | 162 | 5.1 MB | MIT | 2025-12-10 | 2026-02-21 |
| plugin-hub *(Fork)* | 0 | 0 | TS 405, TS 47, HTML 18 | 2,778 | 23 | 1.3 MB | MIT | 2026-05-10 | 2025-12-18 |
| Project_Computer-Vision | 0 | 0 | Python 8,238, Notebook 2,475, JS 1,552 | 158,326 | 79,918 | 1.6 GB | MIT | 2026-07-10 | 2026-07-11 |
| Project_Machine-Learning | 0 | 0 | Notebook 11,954, Python 4,486, JS 590 | 19,437 | 142 | 163.9 MB | MIT | 2026-05-16 | 2026-07-12 |
| redirect-to-crafting | 0 | 0 | TS 174 | 1,079 | 8 | 13.0 KB | MIT | 2024-12-12 | 2026-05-10 |
| Skadi-Theme *(archiviert)* | 0 | 0 | CSS 269, JS 115 | 384 | 9 | 55.2 MB | – | 2023-01-16 | 2023-01-19 |
| Theme-Template *(archiviert)* | 0 | 0 | CSS 288, JS 115 | 404 | 3 | 4.0 KB | – | 2023-01-19 | 2023-01-19 |

---

## 4 · Themencluster

### 4.1 Minecraft / Yes Steve Model – der Publikumsmagnet
`Yes-Steve-Model-Repo` · ★ 3.363 · 382 Forks · 796 MB · **kein Quellcode, reine Asset-Sammlung**.
Lokal verifiziert: **137 Kategorien**, **906 `.ysm`-Modelle** + **208 `.zip`-Archive** (1.114 Dateien).

Größte Sammlungen: Unknown (208), Uncategorized (157), Arknights (61), BlueArchive (56),
HonkaiStarRail (54), GirlsFrontline (52), GenshinImpact (34), Command&ConquerSeries (33),
TouhouProject (29), Vtuber (24), AzurLane (19), Vocaloid-UTAU (19).

Rund ein Drittel der Dateien liegt unkategorisiert → erklärt die 382 Forks: Nutzer klonen das Repo als Model-Bibliothek.

### 4.2 League-of-Legends-Client-Modding – die Kernarbeit (25 Repos)
- **Elaina-theme** (★ 103) – 24.230 Zeilen, davon 10.875 TS. Build `tsc && vite build`, ESLint,
  Husky-Hooks, eigener Wiki-Generator (`scripts/generate-wiki.mjs`). Deps: `archiver`, `chalk`,
  `nano-jsx`, `pengu-upl`. Struktur `src/src/`: assets, config, locales (i18n), plugins, services,
  theme, updates, utils → echtes Anwendungsgerüst, kein Skript.
- **Elaina-theme-data** – 2.226 Zeilen JS, ausgelagerte Daten (Updates ohne Theme-Neubau).
- **Pengu-plugins** – Sammel-Repo mit **14+ Git-Submodules**, jedes Plugin ein eigenes Repo.
- **TS-Plugin-Serie** (alle 2026-05, Vite + tsconfig + pnpm, je 200–1.500 Zeilen):
  `auto-honor-v2`, `eog-mass-report`, `fake-reward-badge`, `fake-runes-pages`, `Old-Mastery-Icons`,
  `Wallpaper-Engine-for-LoL-activityCenter`, `redirect-to-crafting`.
- **JS-Vorgänger** (2023–24): `Auto-honor` (archiviert, 472 Zeilen), `Blank-Settings-Utils`,
  `Force-jungle-lane`, `Hide-friend-list`, `Invite-all-friends`, `Get-Mastery-Score`, `auto-message`,
  `Bad-apple-status` (91.979 Zeilen – fast alles eine eingebettete Frame-Datenliste für die Animation).
- **Themes der 1. Generation** (2023, CSS, alle archiviert): `Elaina-theme-legacy`, `Skadi-Theme`
  (inkl. `BG.mp4`, `UnderTides.mp3`), `Nothing-Theme`, `Theme-Template`.
- **Forks:** `PenguLoader` (Upstream-Framework, 16.352 Zeilen), `plugin-hub` (Vue/UnoCSS).

### 4.3 Uni-Projekte
- **Project_Computer-Vision** – 3,4 GB geklont, 79.918 Dateien, 52 Python-Module. Struktur: `app/`
  (backend, frontend, desktop, build_tools), `modules/` mit vietnamesisch benannten Bausteinen
  (CauHinh, DanhGiaMoHinh, GiamSatViPham, HuanLuyenMoHinh, LamSachBoDuLieu, PhanTichBoDuLieu),
  `configs/`, `fine-tunnedModels/`, `_OD-Models/`. Thema: **Kfz-Kennzeichenerkennung + OCR**
  (fast_plate_ocr, YOLO, train/valid/test-Splits).
- **Project_Machine-Learning** – 142 Dateien, Notebooks `main.ipynb` / `demo.ipynb`, `requirements.txt`.

### 4.4 Bots, Automatisierung & Web
- **Auto-Ban** (★ 5) – Discord-Bot, 6.559 Zeilen JS. Ungewöhnlich vollständig: `Dockerfile`,
  pm2- und tmux-Session-Scripts, `PrivacyPolicy.md`, `TermOfService.md`.
- **Auto-Signin-SKport-Endfield** – gleicher Deployment-Baukasten (Docker + pm2 + tmux).
- **Moe-Counter** – Fork von roffy3051.
- **Elaina69.github.io** – persönliche Seite, 20.558 Zeilen, viel JSON (Asset-Daten).
- **Elaina-web-scipts** – Userscripts: Endfield-Cred-Interceptor, AnimeVietsub-Scraper, Shopee-VN-Ausgaben-Exporter.
- **better-arknights-headhunting-history** – Gacha-History, 433 Zeilen JS.

---

## 5 · Technik-Stack & Codequalität

**Sprachen nach Repos:** JavaScript 15 · TypeScript 9 · CSS 3 · Jupyter 2 · ohne Sprache 7
**Lizenzen:** MIT 19 · keine 17

- Konsistente moderne Toolchain: **Vite + TypeScript + pnpm** bei allen 2026er-Plugins;
  `tsconfig.json` und `vite.config.ts` sind repoübergreifend fast identisch → durchdachtes Template.
- **Beide Lockfiles** eingecheckt (`package-lock.json` *und* `pnpm-lock.yaml`) – redundant.
- `nano-jsx` statt React – bewusst leichtgewichtig für ein Client-Overlay.
- CI nur in den Forks (PenguLoader, plugin-hub), nicht in den eigenen Plugins.
- **Keine Tests** in keinem einzigen Repo.
- 4 Repos ohne README: `Elaina-theme-legacy`, `Elaina69.github.io`, `LOL-audio-replacer`, `Skadi-Theme`.

> **Sicherheitsbefund: sauber.** Muster-Scan über alle Textdateien aller 36 Klone (GitHub-/Slack-/OpenAI-/
> Google-/AWS-/Telegram-Tokens, Discord-Webhooks, Private Keys, hartkodierte Passwörter) → **0 Treffer**.
> `Moe-Counter` liefert korrekt nur ein `.env.example`. E-Mails erscheinen nur als Commit-Autor.

---

## 6 · Punkte mit Klärungsbedarf

1. **`Yes-Steve-Model-Repo` ohne Lizenz.** 3.363 Sterne, aber keine LICENSE-Datei. Die README sagt
   „collected from various sources, free to use" – ohne Lizenz ist das rechtlich nicht gedeckt, und bei
   gesammelten Fremd-Assets ist die Herkunft unklar.
2. **Repo-Größe.** `Project_Computer-Vision` = 1,6 GB (GitHub-Angabe). Trainierte `.keras`-Modelle à 28 MB
   liegen mehrfach versioniert im Repo. GitHub warnt ab 1 GB, einzelne Dateien > 100 MB werden blockiert.
   → Git LFS oder Release-Artefakte.
3. **ToS-Grauzone bei LoL-Plugins.** `eog-mass-report` („Report all player right after end of game"),
   `fake-reward-badge`, `fake-runes-pages` können gegen die Riot-Nutzungsbedingungen verstoßen und
   im Extremfall zu Kontosperren führen – das betrifft auch die Nutzer des Themes.
4. **Keine `FUNDING.yml`** trotz 252 Followern und 3.495 Sternen.

---

## 7 · Markierte Repos (Sterne) – 11 Stück

| Repo | ★ | Sprache/Umfang | Beschreibung |
|---|--:|---|---|
| NguyenDevs/EcoLens | 7 | Kotlin 682 KB | Pflanzen-/Tierarten bestimmen (vietnamesisches Team) |
| CloudySn0w/BTLoader | 232 | Obj-C 48 KB, Logos 27 KB | iOS-Tweak-Loader, Fork von bunny-mod/BunnyTweak |
| aminalaghband/jetson-nano | 18 | – | Ultralytics für Jetson Nano, Python 3.6 |
| termux/termux-app | 61.107 | Java 2.093 KB | Terminal-Emulator für Android |
| shiftkey/desktop | 8.064 | TS 4.995 KB | GitHub Desktop für Linux-Distributionen |
| massgravel/Microsoft-Activation-Scripts | 191.311 | Batchfile 1.760 KB | Windows-/Office-Aktivator |
| Yudaotor/EsportsHelper | 193 | Python 277 KB | Esports-Kapseln farmen via Selenium |
| **Elaina69/Yes-Steve-Model-Repo** | 3.363 | – | eigenes Repo |
| **Elaina69/Elaina-theme-data** | 3 | JS 67 KB | eigenes Repo |
| **Elaina69/Elaina-theme** | 103 | TS 402 KB | eigenes Repo |
| Lyfhael/league-loader-plugins | 18 | JS 48 KB, CSS 42 KB | League-Loader-Plugins |

**Lesart:** 3 von 11 Sternen sind eigene Repos (Portfolio-Pinning). Fachlicher Bezug zu LoL
(league-loader-plugins, EsportsHelper) und zu KI/Uni (EcoLens, jetson-nano). `termux-app` und
`shiftkey/desktop` sind reines Tooling. `Microsoft-Activation-Scripts` (Aktivator) und `BTLoader`
(Jailbreak-Umfeld) sind rechtlich auffällig. Es existiert 1 Star-Liste (`stars/Elaina69/lists/all`).

---

## 8 · Gists (3)

| ID | Datei | Datum |
|---|---|---|
| a3ff4e2862f4ac66b8565bc9c67fa3f5 | cách_sử_dụng_API_key_AgentRouter_trên_VSCode.md | 2026-08-21 |
| 4b644a43037fc64eb8d4f6505d27fb66 | createQueue.js | 2024-06-27 |
| 2d836b7fbed89ddee266d0aecbc85def | getID.js | 2024-06-27 |

## 9 · Commit-Autorschaft

In den 33 eigenen Repos stammt der letzte Commit durchgängig von **Elaina Da Catto / Elaina69**.
Nur die 3 Forks tragen Fremd-Autoren (`roffy3051` → Moe-Counter; `Nguyen Duy` → PenguLoader, plugin-hub).
Verwendete Identitäten: `vipnoxhd123@gmail.com`, `94338907+Elaina69@users.noreply.github.com` und in den
2023er-Theme-Repos `94338907+Roydevil@users.noreply.github.com` (früherer Account-Name).

---

## Methodik & Grenzen

- GitHub-REST-API: `/users/Elaina69`, `/repos` (2 Seiten, 36 Treffer), `/starred` (11 Treffer, per HTML
  gegengeprüft), `/gists`, `/repos/{repo}/languages`.
- Alle 36 Repos mit `git clone --depth 1` geklont (36 OK, 0 Fehler), lokal ausgewertet.
- Zeilen-/Dateizählungen stammen aus den Klonen, **nicht** von GitHub Linguist.
- **Wegen des Shallow-Clones ist die Git-Historie auf den letzten Commit begrenzt** – Commit-Zahlen pro Repo
  und Contributors-Statistiken wurden deshalb **nicht** erhoben.
- Keine Schreiboperationen, kein authentifizierter API-Zugriff.
