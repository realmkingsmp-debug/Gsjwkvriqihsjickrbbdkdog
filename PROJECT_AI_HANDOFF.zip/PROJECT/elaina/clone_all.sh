#!/bin/bash
# Klont alle Repos von Elaina69 (shallow, depth=1) nach repos/
cd "$(dirname "$0")"
mkdir -p repos logs
export GIT_TERMINAL_PROMPT=0
: > clone_status.log

clone_one() {
  full="$1"
  name="$(basename "$full")"
  dest="repos/$name"
  if [ -d "$dest/.git" ]; then
    echo "SKIP  $full (already cloned)" >> clone_status.log
    return
  fi
  rm -rf "$dest"
  # zuerst shallow, falls das fehlschlaegt: normaler Clone
  if git clone --quiet --depth 1 "https://github.com/$full.git" "$dest" 2>> "logs/$name.err"; then
    echo "OK    $full shallow" >> clone_status.log
  elif git clone --quiet "https://github.com/$full.git" "$dest" 2>> "logs/$name.err"; then
    echo "OK    $full full" >> clone_status.log
  else
    echo "FAIL  $full -> $(tail -2 "logs/$name.err" | tr '\n' ' ')" >> clone_status.log
  fi
}

while IFS=$'\t' read -r full branch size url; do
  [ -z "$full" ] && continue
  clone_one "$full" &
  # max 4 parallel
  while [ "$(jobs -rp | wc -l)" -ge 4 ]; do sleep 1; done
done < repos_to_clone.txt
wait
echo "DONE_ALL" >> clone_status.log
