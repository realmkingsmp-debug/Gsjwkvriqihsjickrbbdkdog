#!/usr/bin/env python3
"""Erzeugt report.html (self-contained) und report.md aus den gesammelten Daten."""
import json, os, html
from collections import Counter
from datetime import date

ROOT = "/home/user/elaina"
raw = json.load(open(f"{ROOT}/data/analyse_raw.json"))
meta = json.load(open(f"{ROOT}/data/repos_p1.json")) + json.load(open(f"{ROOT}/data/repos_p2.json"))
stars = json.load(open(f"{ROOT}/data/stars_p1.json"))
user = json.load(open(f"{ROOT}/data/user.json"))
gists = json.load(open(f"{ROOT}/data/gists.json"))
ysm_top = json.load(open(f"{ROOT}/data/ysm_top.json"))
by = {m["name"]: m for m in meta}
e = html.escape

meta.sort(key=lambda m: (-m["stargazers_count"], m["name"].lower()))
tot_stars = sum(m["stargazers_count"] for m in meta)
tot_forks = sum(m["forks_count"] for m in meta)
own = [m for m in meta if not m["fork"]]
forks_repo = [m for m in meta if m["fork"]]
arch = [m for m in meta if m["archived"]]
lic = Counter(((m.get("license") or {}).get("spdx_id") or "keine") for m in meta)
langs = Counter(m["language"] for m in meta if m["language"])
push_year = Counter(m["pushed_at"][:4] for m in meta)
create_year = Counter(m["created_at"][:4] for m in meta)
tot_lines = sum(a.get("zeilen", 0) for a in raw.values())
tot_files = sum(a.get("dateien", 0) for a in raw.values())
tot_bytes = sum(a.get("bytes", 0) for a in raw.values())

CLUSTER = {
    "League-of-Legends / Pengu Loader": ["Elaina-theme", "Elaina-theme-data", "Elaina-theme-legacy",
        "Pengu-plugins", "PenguLoader", "plugin-hub", "LOL-audio-replacer", "auto-honor-v2", "Auto-honor",
        "eog-mass-report", "fake-reward-badge", "fake-runes-pages", "Old-Mastery-Icons",
        "Wallpaper-Engine-for-LoL-activityCenter", "redirect-to-crafting", "Blank-Settings-Utils",
        "Force-jungle-lane", "Hide-friend-list", "Invite-all-friends", "Get-Mastery-Score",
        "auto-message", "Bad-apple-status", "Theme-Template", "Skadi-Theme", "Nothing-Theme"],
    "Minecraft / YSM-Modelle": ["Yes-Steve-Model-Repo"],
    "Uni-Projekte (KI/CV/ML)": ["Project_Computer-Vision", "Project_Machine-Learning"],
    "Bots & Automatisierung": ["Auto-Ban", "Auto-Signin-SKport-Endfield", "Moe-Counter"],
    "Web / Userscripts": ["Elaina69.github.io", "Elaina-web-scipts", "better-arknights-headhunting-history",
                          "Elaina-Vendetta", "Elaina69"],
}
cluster_of = {}
for c, names in CLUSTER.items():
    for n in names:
        cluster_of[n] = c

def gb(b):
    for u in ("B", "KB", "MB", "GB"):
        if b < 1024: return f"{b:.0f} {u}" if u == "B" else f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} TB"

def bar_row(label, value, maxv, extra="", color="#c46bd4"):
    w = max(1, round(value / maxv * 100)) if maxv else 0
    return (f'<div class="brow"><div class="blabel">{label}</div>'
            f'<div class="btrack"><div class="bfill" style="width:{w}%;background:{color}"></div></div>'
            f'<div class="bval">{extra}</div></div>')

# ---------- SVG: Sterne-Verteilung (log-Skala, da ein Ausreisser) ----------
import math
svg_rows = []
maxstar = max(m["stargazers_count"] for m in meta) or 1
for m in meta[:12]:
    v = m["stargazers_count"]
    w = int(math.log10(v + 1) / math.log10(maxstar + 1) * 520)
    svg_rows.append(f'<div class="brow"><div class="blabel">{e(m["name"])}</div>'
                    f'<div class="btrack"><div class="bfill" style="width:{w/5.6:.1f}%;background:linear-gradient(90deg,#8b5cf6,#ec4899)"></div></div>'
                    f'<div class="bval">★ {v:,}</div></div>'.replace(",", "."))

# ---------- SVG: Aktivitaet pro Jahr ----------
years = sorted(set(list(push_year) + list(create_year)))
ymax = max(list(push_year.values()) + list(create_year.values()))
bars = ""
for y in years:
    h1 = int(push_year.get(y, 0) / ymax * 130)
    h2 = int(create_year.get(y, 0) / ymax * 130)
    bars += f'<g><rect x="{years.index(y)*130+15}" y="{160-h1}" width="46" height="{h1}" fill="#8b5cf6" rx="3"/>' \
            f'<rect x="{years.index(y)*130+68}" y="{160-h2}" width="46" height="{h2}" fill="#22d3ee" rx="3"/>' \
            f'<text x="{years.index(y)*130+38}" y="{155-h1}" fill="#c4b5fd" font-size="12" text-anchor="middle">{push_year.get(y,0)}</text>' \
            f'<text x="{years.index(y)*130+91}" y="{155-h2}" fill="#67e8f9" font-size="12" text-anchor="middle">{create_year.get(y,0)}</text>' \
            f'<text x="{years.index(y)*130+65}" y="180" fill="#94a3b8" font-size="13" text-anchor="middle">{y}</text></g>'
svg_years = (f'<svg viewBox="0 0 {len(years)*130+20} 200" style="width:100%;max-width:640px">'
             f'{bars}<line x1="0" y1="160" x2="{len(years)*130+20}" y2="160" stroke="#334155"/></svg>')

# ---------- Tabelle Repos ----------
CODE = {".ts": "TS", ".tsx": "TS", ".js": "JS", ".jsx": "JS", ".py": "Python", ".css": "CSS",
        ".scss": "SCSS", ".html": "HTML", ".user.js": "Userscript", ".c": "C", ".cpp": "C++",
        ".java": "Java", ".sh": "Shell", ".ipynb": "Notebook"}

def langstr(m):
    """Nur echte Programmiersprachen mit >0 Zeilen, sonst GitHub-Sprache."""
    a = raw.get(m["name"], {})
    code = [(CODE[l], z) for l, z in (a.get("sprachen") or []) if l in CODE and z > 0]
    if code:
        return ", ".join(f"{l} {z:,}".replace(",", ".") for l, z in code[:3])
    return m["language"] or "– (nur Assets/Text)"

rows_html = []
for m in meta:
    a = raw.get(m["name"], {})
    spr = langstr(m)
    cls = "fork" if m["fork"] else ""
    if m["archived"]: cls += " arch"
    rows_html.append(f"""<tr class="{cls}">
<td><a href="https://github.com/{e(m['full_name'])}" target="_blank">{e(m['name'])}</a></td>
<td class="n">★ {m['stargazers_count']:,}</td><td class="n">{m['forks_count']}</td>
<td>{e(spr)}</td><td class="n">{(a.get('zeilen') or 0):,}</td><td class="n">{(a.get('dateien') or 0):,}</td>
<td class="n">{gb(m['size']*1024)}</td>
<td>{e(((m.get('license') or {}).get('spdx_id') or '–'))}</td>
<td>{e(m['created_at'][:10])}</td><td>{e(m['pushed_at'][:10])}</td>
<td>{'Fork' if m['fork'] else ('Archiv' if m['archived'] else e(cluster_of.get(m['name'],'–')))}</td>
</tr>""".replace(",", "."))

# ---------- Sterne-Tabelle ----------
star_rows = []
for r in stars:
    lf = f"data/stars_lang/{r['full_name'].replace('/', '_')}.json"
    ld = json.load(open(f"{ROOT}/{lf}")) if os.path.exists(f"{ROOT}/{lf}") else {}
    lstr = ", ".join(f"{k} {round(v/1024)} KB" for k, v in sorted(ld.items(), key=lambda x: -x[1])[:3]) if ld else (r["language"] or "–")
    mine = " (eigenes Repo)" if r["owner"]["login"] == "Elaina69" else ""
    star_rows.append(f"""<tr>
<td><a href="https://github.com/{e(r['full_name'])}" target="_blank">{e(r['full_name'])}</a>{mine}</td>
<td class="n">★ {r['stargazers_count']:,}</td><td class="n">{r['forks_count']:,}</td>
<td>{e(lstr)}</td><td>{e(r['created_at'][:10])}</td><td>{e(r['pushed_at'][:10])}</td>
<td>{e((r.get('description') or '–')[:110])}</td></tr>""".replace(",", "."))

ysm_rows = "".join(f"<li><b>{e(k)}</b> – {v} Dateien</li>" for k, v in ysm_top[:12])
gist_rows = "".join(f"<li><code>{e(g['id'])}</code> – {e(list(g['files'].keys())[0])} ({g['created_at'][:10]})</li>" for g in gists)

HTML = f"""<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Analyse GitHub-Account Elaina69</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:#0b1020;color:#e2e8f0;font:15px/1.6 -apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif}}
.wrap{{max-width:1120px;margin:0 auto;padding:32px 20px 80px}}
h1{{font-size:34px;margin:0 0 6px;background:linear-gradient(90deg,#a78bfa,#f472b6);-webkit-background-clip:text;background-clip:text;color:transparent}}
h2{{font-size:22px;margin:44px 0 14px;padding-bottom:8px;border-bottom:1px solid #1e293b;color:#f1f5f9}}
h3{{font-size:17px;margin:26px 0 10px;color:#c4b5fd}}
.sub{{color:#94a3b8;margin:0 0 24px}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:20px 0}}
.card{{background:#111831;border:1px solid #1e293b;border-radius:14px;padding:16px}}
.card .k{{font-size:28px;font-weight:700;color:#f0abfc}}
.card .l{{font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.6px}}
table{{width:100%;border-collapse:collapse;font-size:13.5px;margin:12px 0;background:#0e1428;border-radius:12px;overflow:hidden}}
th,td{{padding:8px 10px;text-align:left;border-bottom:1px solid #1a2340;vertical-align:top}}
th{{background:#151d38;color:#a5b4fc;font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.4px;position:sticky;top:0}}
td.n{{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}}
tr.fork{{opacity:.65}} tr.arch{{opacity:.5}}
tr:hover{{background:#141c37}}
a{{color:#7dd3fc;text-decoration:none}} a:hover{{text-decoration:underline}}
.scroll{{overflow-x:auto;border:1px solid #1e293b;border-radius:12px}}
.note{{background:#141b33;border-left:4px solid #8b5cf6;padding:12px 16px;border-radius:0 10px 10px 0;margin:14px 0}}
.warn{{background:#2a1520;border-left:4px solid #f43f5e;padding:12px 16px;border-radius:0 10px 10px 0;margin:14px 0}}
.ok{{background:#0f2620;border-left:4px solid #10b981;padding:12px 16px;border-radius:0 10px 10px 0;margin:14px 0}}
code{{background:#1a2340;padding:2px 6px;border-radius:5px;font-size:12.5px;color:#fbcfe8}}
pre{{background:#0d1329;border:1px solid #1e293b;padding:14px;border-radius:10px;overflow-x:auto;font-size:12.5px;color:#cbd5e1}}
.brow{{display:flex;align-items:center;gap:10px;margin:4px 0}}
.blabel{{width:210px;font-size:13px;color:#cbd5e1;flex-shrink:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
.btrack{{flex:1;background:#1a2340;border-radius:6px;height:14px;overflow:hidden}}
.bfill{{height:100%;border-radius:6px}}
.bval{{width:110px;font-size:12px;color:#94a3b8;text-align:right;font-variant-numeric:tabular-nums}}
ul{{margin:8px 0 8px 0;padding-left:22px}} li{{margin:3px 0}}
.tag{{display:inline-block;background:#1e293b;color:#a5b4fc;border-radius:20px;padding:2px 10px;font-size:12px;margin:2px}}
.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:20px}}
@media(max-width:800px){{.grid2{{grid-template-columns:1fr}}}}
.small{{font-size:12.5px;color:#64748b}}
</style></head><body><div class="wrap">

<h1>GitHub-Analyse: Elaina69</h1>
<p class="sub">„{e(user['name'])}" · {e(user['location'] or '')} · {e(user['blog'] or '')} · Account seit {user['created_at'][:10]}
· {user['followers']} Follower · Stand {date.today().isoformat()} · Quelle: GitHub-API + 36 lokale Klone</p>

<div class="cards">
<div class="card"><div class="k">{user['public_repos']}</div><div class="l">Öffentliche Repos</div></div>
<div class="card"><div class="k">{tot_stars:,}</div><div class="l">Sterne gesamt</div></div>
<div class="card"><div class="k">{tot_forks}</div><div class="l">Forks gesamt</div></div>
<div class="card"><div class="k">{user['public_gists']}</div><div class="l">Gists</div></div>
<div class="card"><div class="k">{tot_lines:,}</div><div class="l">Codezeilen</div></div>
<div class="card"><div class="k">{tot_files:,}</div><div class="l">Dateien</div></div>
<div class="card"><div class="k">{gb(tot_bytes)}</div><div class="l">Größe (geklont)</div></div>
<div class="card"><div class="k">{user['following']}</div><div class="l">Following</div></div>
</div>

<div class="note"><b>Kurzfazit.</b> Das Profil ist kein Sammelbecken, sondern ein klar umrissenes Portfolio:
<b>96 % aller Sterne ({by['Yes-Steve-Model-Repo']['stargazers_count']:,} von {tot_stars:,})</b> kommen aus einem einzigen Repo
(Yes-Steve-Model-Repo). Die eigentliche Engineering-Arbeit steckt in einem zweiten Cluster –
<b>25 von {len(meta)} Repos</b> drehen sich um Themes und Plugins für den League-of-Legends-Client
(Pengu Loader / League Loader). Dazu kommen zwei vietnamesische Uni-Projekte (ML &amp; Computer Vision)
und ein paar Discord-/Bot-Automatisierungen. Tech-Stack fast durchgängig <b>TypeScript/JavaScript</b>,
moderne Toolchain (Vite, ESLint, Husky, pnpm).</div>

<h2>1 · Sterne-Verteilung</h2>
<p class="small">Logarithmische Balken – ein einziger Ausreißer dominiert das Profil.</p>
{"".join(svg_rows)}

<h2>2 · Aktivität über die Zeit</h2>
<div class="grid2">
<div>{svg_years}
<p class="small">Violett = Repos mit letztem Push im Jahr · Cyan = Repos, die in dem Jahr erstellt wurden.</p></div>
<div>
<h3>Lesart</h3>
<ul>
<li><b>2023</b> – Gründungsphase: {create_year.get('2023',0)} Repos angelegt, fast alle LoL-Client-Themes
(Skadi, Nothing, Theme-Template, Legacy). Vieles davon ist heute archiviert.</li>
<li><b>2024</b> – {create_year.get('2024',0)} neue Repos, aber nur {push_year.get('2024',0)} mit letztem Push in 2024 → Übergangsjahr.</li>
<li><b>2025</b> – nur {push_year.get('2025',0)} Repo berührt, aber {create_year.get('2025',0)} neu angelegt →
Vorbereitung der TypeScript-Plugin-Serie.</li>
<li><b>2026</b> – {push_year.get('2026',0)} von {len(meta)} Repos zuletzt gepusht. Hier liegt die aktuelle Arbeit:
Uni-Projekte (CV/ML), die Vite-basierten TS-Plugins und das Theme.</li>
</ul>
</div></div>

<h2>3 · Alle {len(meta)} Repos</h2>
<div class="scroll"><table>
<thead><tr><th>Repo</th><th>Sterne</th><th>Forks</th><th>Sprachen</th><th>Zeilen</th><th>Dateien</th>
<th>Größe</th><th>Lizenz</th><th>Erstellt</th><th>Letzter Push</th><th>Cluster</th></tr></thead>
<tbody>{"".join(rows_html)}</tbody></table></div>
<p class="small">Abgeblendete Zeilen = Forks (Moe-Counter, PenguLoader, plugin-hub) bzw. archivierte Repos
({", ".join(e(m['name']) for m in arch)}). Größenangabe = GitHub-Repo-Größe inkl. Git-Historie.</p>

<h2>4 · Themencluster im Detail</h2>

<h3>4.1 Minecraft / Yes Steve Model – der Publikumsmagnet</h3>
<p><b>Yes-Steve-Model-Repo</b> · ★ {by['Yes-Steve-Model-Repo']['stargazers_count']:,} · {by['Yes-Steve-Model-Repo']['forks_count']} Forks ·
{gb(by['Yes-Steve-Model-Repo']['size']*1024)} · kein Quellcode, reine Asset-Sammlung.</p>
<p>Inhalt lokal verifiziert: <b>137 Kategorien</b>, <b>906 <code>.ysm</code>-Modelle</b> + <b>208 <code>.zip</code>-Archive</b>
(1.114 Dateien, {gb(raw['Yes-Steve-Model-Repo']['bytes'])}). Größte Sammlungen:</p>
<ul>{ysm_rows}</ul>
<p>365 Dateien liegen in <code>Uncategorized</code>/{e('Unknown')} – also rund ein Drittel ohne Zuordnung.
Das erklärt die 382 Forks: Nutzer klonen das Repo als Model-Bibliothek.</p>

<h3>4.2 League-of-Legends-Client-Modding – die Kernarbeit ({len(CLUSTER['League-of-Legends / Pengu Loader'])} Repos)</h3>
<p>Das ist der technisch interessanteste Teil. Architektur: ein Haupt-Theme als Build-Projekt,
dazu einzelne Plugins als Git-Submodules in einem Sammel-Repo.</p>
<ul>
<li><b>Elaina-theme</b> (★ {by['Elaina-theme']['stargazers_count']}) – {raw['Elaina-theme']['zeilen']:,} Zeilen, davon
{dict(raw['Elaina-theme']['sprachen']).get('.ts',0):,} Zeilen TypeScript. Build: <code>tsc &amp;&amp; vite build</code>,
Linting mit ESLint, Pre-Commit-Hooks über Husky, eigener Wiki-Generator (<code>scripts/generate-wiki.mjs</code>).
Dependencies: <code>archiver</code>, <code>chalk</code>, <code>nano-jsx</code>, <code>pengu-upl</code>.
Struktur unter <code>src/src/</code>: assets, config, locales (i18n), plugins, services, theme, updates, utils –
also ein echtes Anwendungsgerüst, kein Skript.</li>
<li><b>Elaina-theme-data</b> – {dict(raw['Elaina-theme-data']['sprachen']).get('.js',0):,} Zeilen JS, ausgelagerte Daten
(für schnelle Updates ohne Theme-Neubau).</li>
<li><b>Pengu-plugins</b> – Sammel-Repo mit <b>14+ Git-Submodules</b>, jedes Plugin ein eigenes Repo. Saubere Trennung.</li>
<li><b>TypeScript-Plugin-Serie</b> (alle Vite + tsconfig + pnpm, alle 2026-05):
<code>auto-honor-v2</code>, <code>eog-mass-report</code>, <code>fake-reward-badge</code>, <code>fake-runes-pages</code>,
<code>Old-Mastery-Icons</code>, <code>Wallpaper-Engine-for-LoL-activityCenter</code>, <code>redirect-to-crafting</code>.
 Jeweils ~200–1.500 Zeilen TS.</li>
<li><b>JavaScript-Vorgänger</b> (2023–2024): <code>Auto-honor</code> (archiviert, 472 Zeilen), <code>Blank-Settings-Utils</code>,
<code>Force-jungle-lane</code>, <code>Hide-friend-list</code>, <code>Invite-all-friends</code>, <code>Get-Mastery-Score</code>,
<code>auto-message</code>, <code>Bad-apple-status</code> (91.979 Zeilen – davon ist fast alles eine in JS eingebettete
Bild-/Frame-Datenliste für die Bad-Apple-Animation).</li>
<li><b>Themes der ersten Generation</b> (2023, CSS-basiert, alle archiviert): <code>Elaina-theme-legacy</code>,
<code>Skadi-Theme</code> (inkl. <code>BG.mp4</code>, <code>UnderTides.mp3</code>, Arknights-Assets),
<code>Nothing-Theme</code>, <code>Theme-Template</code>.</li>
<li><b>Forks:</b> <code>PenguLoader</code> (Upstream-Framework, 16.352 Zeilen) und <code>plugin-hub</code> (Vue/UnoCSS).</li>
</ul>

<h3>4.3 Uni-Projekte</h3>
<ul>
<li><b>Project_Computer-Vision</b> – mit {gb(raw['Project_Computer-Vision']['bytes'])} das bei weitem größte Repo.
{raw['Project_Computer-Vision']['dateien']:,} Dateien, 52 Python-Module. Struktur: <code>app/</code>
(backend, frontend, desktop, build_tools), <code>modules/</code> mit vietnamesisch benannten Bausteinen
(CauHinh, DanhGiaMoHinh, GiamSatViPham, HuanLuyenMoHinh, LamSachBoDuLieu, PhanTichBoDuLieu),
<code>configs/</code>, <code>fine-tunnedModels/</code>, <code>_OD-Models/</code>.
Thema: <b>Kfz-Kennzeichen-Erkennung + OCR</b> (fast_plate_ocr, YOLO-Modelle, train/valid/test-Splits).</li>
<li><b>Project_Machine-Learning</b> – 142 Dateien, Jupyter-Notebooks (<code>main.ipynb</code>, <code>demo.ipynb</code>)
plus <code>requirements.txt</code>. Sauber als Lehrprojekt aufgesetzt.</li>
</ul>

<h3>4.4 Bots, Automatisierung &amp; Web</h3>
<ul>
<li><b>Auto-Ban</b> (★ 5) – Discord-Bot, {dict(raw['Auto-Ban']['sprachen']).get('.js',0):,} Zeilen JS. Auffällig professionell
aufgesetzt: <code>Dockerfile</code>, <code>docker-compose</code>-artige Scripts, pm2- und tmux-Session-Scripts,
<code>PrivacyPolicy.md</code>, <code>TermOfService.md</code> – für ein Hobby-Projekt ungewöhnlich vollständig.</li>
<li><b>Auto-Signin-SKport-Endfield</b> – gleicher Deployment-Baukasten (Docker + pm2 + tmux) für
Arknights-Endfield-Signin.</li>
<li><b>Moe-Counter</b> – Fork von roffy3051 (letzte Commit-Autoren: roffy3051, Commit-Datum 2024-11-02).</li>
<li><b>Elaina69.github.io</b> – persönliche Seite, {raw['Elaina69.github.io']['zeilen']:,} Zeilen,
viel JSON (Champion-/Asset-Daten).</li>
<li><b>Elaina-web-scipts</b> – Userscripts/Tampermonkey: Endfield-Cred-Interceptor,
AnimeVietsub-Listenscraper, Shopee-VN-Ausgaben-Exporter.</li>
<li><b>better-arknights-headhunting-history</b> – Arknights-Gacha-History, 433 Zeilen JS.</li>
</ul>

<h2>5 · Technik-Stack &amp; Codequalität</h2>
<div class="grid2"><div>
<h3>Sprachen (nach Repos)</h3>
{"".join(bar_row(e(k or 'ohne Sprache'), v, max(langs.values()), f"{v} Repos") for k, v in langs.most_common())}
<h3>Lizenzen</h3>
{"".join(bar_row(e(k), v, max(lic.values()), f"{v} Repos", "#10b981") for k, v in lic.most_common())}
</div><div>
<h3>Beobachtungen</h3>
<ul>
<li>Konsistente moderne Toolchain: <b>Vite + TypeScript + pnpm</b> bei allen 2026er-Plugins,
<code>tsconfig.json</code> und <code>vite.config.ts</code> sind über die Repos hinweg nahezu identisch →
klar kopiertes, durchdachtes Template.</li>
<li>Beide Lockfiles eingecheckt (<code>package-lock.json</code> <i>und</i> <code>pnpm-lock.yaml</code>) –
redundant, pnpm ist offensichtlich der echte Paketmanager.</li>
<li>Elaina-theme nutzt <b>nano-jsx</b> statt React – bewusst leichtgewichtig für ein Client-Overlay.</li>
<li>CI ist nur spärlich: in PenguLoader/plugin-hub liegen Workflows, in den eigenen Plugins nicht.</li>
<li>Tests fehlen komplett – in keinem Repo gibt es ein Testverzeichnis oder Test-Skript.</li>
<li>4 Repos haben keine README: <code>{", ".join(e(n) for n in ['Elaina-theme-legacy','Elaina69.github.io','LOL-audio-replacer','Skadi-Theme'])}</code>.</li>
</ul>
</div></div>

<div class="ok"><b>Sicherheitsbefund: sauber.</b> Ein Muster-Scan über alle Textdateien aller 36 Klone
(Token-Formate, API-Keys, Webhooks, Private Keys, hartkodierte Passwörter) ergab
<b>0 Treffer</b>. <code>Moe-Counter</code> liefert korrekt nur ein <code>.env.example</code>.
E-Mail-Adressen erscheinen ausschließlich als Git-Commit-Autor
(<code>vipnoxhd123@gmail.com</code> bzw. GitHub-noreply) – das ist normal und öffentlich sichtbar.</div>

<h2>6 · Punkte mit Klärungsbedarf</h2>
<div class="warn"><ul>
<li><b>Yes-Steve-Model-Repo ohne Lizenz.</b> {by['Yes-Steve-Model-Repo']['stargazers_count']:,} Sterne, aber
{lic.get('keine',0)} Repos – darunter dieses – haben <b>keine Lizenzdatei</b>. Die README sagt „collected from
various sources, free to use"; ohne LICENSE ist das rechtlich aber nicht gedeckt, und bei gesammelten
Fremd-Assets ist die Herkunft unklar. Empfehlung: Lizenz ergänzen bzw. Quelle pro Modell dokumentieren.</li>
<li><b>Repo-Größe.</b> Project_Computer-Vision ist {gb(by['Project_Computer-Vision']['size']*1024)}
(GitHub-Angabe) – trainierte <code>.keras</code>-Modelle à 28 MB liegen mehrfach versioniert im Repo.
GitHub warnt ab 1 GB und blockt einzelne Dateien &gt; 100 MB. Besser: Modelle/Trainingsdaten via
Git LFS oder als Release-Artefakt auslagern.</li>
<li><b>Terms-of-Service-Grauzone bei einigen LoL-Plugins.</b> <code>eog-mass-report</code>
(„Report all player right after end of game"), <code>fake-reward-badge</code> und <code>fake-runes-pages</code>
verändern das Client-Erlebnis bzw. automatisieren Meldungen. Solche Mods können gegen die
Riot-Nutzungsbedingungen verstoßen und im Extremfall zu Kontosperren führen – das betrifft Nutzer
des Themes, nicht nur die Autorin.</li>
<li><b>Kein <code>following = 0</code>-Signal, aber auch keine Sponsoring-/Funding-Datei.</b>
Bei {user['followers']} Followern und {tot_stars:,} Sternen wäre eine <code>FUNDING.yml</code> naheliegend.</li>
</ul></div>

<h2>7 · Markierte Repos (Sterne) – {len(stars)} Stück</h2>
<div class="scroll"><table>
<thead><tr><th>Repo</th><th>Sterne</th><th>Forks</th><th>Sprachen / Umfang</th><th>Erstellt</th><th>Letzter Push</th><th>Beschreibung</th></tr></thead>
<tbody>{"".join(star_rows)}</tbody></table></div>

<h3>Was die Sterne über das Profil aussagen</h3>
<ul>
<li><b>3 von 11 Sternen gehen an eigene Repos</b> (Yes-Steve-Model-Repo, Elaina-theme, Elaina-theme-data) –
das sind die „Pinning"-Sterne fürs eigene Portfolio.</li>
<li><b>Fachlicher Bezug:</b> <code>Lyfhael/league-loader-plugins</code> und <code>Yudaotor/EsportsHelper</code>
passen direkt zum LoL-Ökosystem; <code>NguyenDevs/EcoLens</code> (Kotlin, vietnamesisches Team) und
<code>aminalaghband/jetson-nano</code> (Ultralytics/YOLO) zum KI-/Uni-Strang.</li>
<li><b>Tooling/Infrastruktur:</b> <code>termux/termux-app</code> (61.107 ★) und <code>shiftkey/desktop</code>
(GitHub Desktop für Linux) – beides Werkzeuge, kein Inhalt.</li>
<li><b>Rechtlich auffällig:</b> <code>massgravel/Microsoft-Activation-Scripts</code> (191.311 ★) ist ein
Windows-/Office-Aktivator. Als Stern unkritisch, aber ein Hinweis darauf, dass auch nicht ganz
saubere Toolchains im Blickfeld liegen. <code>CloudySn0w/BTLoader</code> ist ein iOS-Tweak-Loader
(Fork von BunnyTweak), also Jailbreak-Umfeld.</li>
<li><b>1 Star-Liste</b> existiert: <code>stars/Elaina69/lists/all</code> mit 1 Eintrag.</li>
</ul>

<h2>8 · Gists</h2>
<ul>{gist_rows}</ul>

<h2>9 · Commit-Autorschaft</h2>
<p>In {len([m for m in meta if not m['fork']])} eigenen Repos stammt der letzte Commit durchgängig von
<b>Elaina Da Catto / Elaina69</b>. Nur die drei Forks tragen Fremd-Autoren
(<code>roffy3051</code> für Moe-Counter, <code>Nguyen Duy</code> für PenguLoader und plugin-hub).
Verwendete Identitäten: <code>vipnoxhd123@gmail.com</code>,
<code>94338907+Elaina69@users.noreply.github.com</code> und in den 2023er-Theme-Repos noch
<code>94338907+Roydevil@users.noreply.github.com</code> – ein früherer Account-Name.</p>

<h2>10 · Dateien im Workspace</h2>
<pre>elaina/
  report.html          <- dieser Report
  report.md            <- gleiche Inhalte als Markdown
  out_repos.csv        <- alle {len(meta)} Repos, eine Zeile pro Repo
  out_stars.csv        <- alle {len(stars)} markierten Repos
  data/analyse_raw.json  Rohdaten der lokalen Analyse (Zeilen, Dateien, Sprachen, READMEs, Paket-Deps)
  data/repos_p*.json     GitHub-API-Antworten
  repos/               36 Klone (shallow, depth=1) – ca. 6 GB</pre>
<p class="small">Methodik: GitHub-REST-API (User, Repos, Stars, Gists, Languages) + lokale Klone mit
<code>git clone --depth 1</code>. Zeilen-/Dateizählungen stammen aus den Klonen, nicht von GitHub Linguist;
Git-Historie ist wegen des Shallow-Clones auf den letzten Commit begrenzt – Commit-Zahlen pro Repo wurden
daher <b>nicht</b> erhoben. Kein API-Zugriff mit Authentifizierung, keine Schreiboperationen.</p>

</div></body></html>"""

import re as _re
# ---------- Tausendertrenner auf deutsch normieren (VOR dem Schreiben/Pruefen) ----------
HTML = _re.sub(r"(\d),(?=\d{3}(?!\d))", r"\1.", HTML)

open(f"{ROOT}/report.html", "w", encoding="utf-8").write(HTML)


# ---------- Selbstpruefung: HTML-Tabelle gegen out_repos.csv ----------
import csv as _csv
rows = {r["name"]: r for r in _csv.DictReader(open(f"{ROOT}/out_repos.csv", encoding="utf-8-sig"))}
Q = chr(34)
N = '<td class=' + Q + 'n' + Q + '>'
pat = _re.compile(
    r">([A-Za-z0-9_.\-]+)</a></td>\s*"
    + N + r"\u2605 ([\d.]+)</td>" + N + r"(\d+)</td>\s*"
    r"<td>([^<]*)</td>\s*"
    + N + r"([\d.]+)</td>" + N + r"([\d.]+)</td>"
)
found = {m.group(1): m.groups()[1:] for m in pat.finditer(HTML)}
bad = []
for n, r in rows.items():
    g = found.get(n)
    if not g:
        bad.append((n, "Zeile nicht gefunden")); continue
    exp = (f"{int(r['stars']):,}".replace(",", "."), r["forks"], None,
           f"{int(r['code_zeilen']):,}".replace(",", "."), f"{int(r['dateien']):,}".replace(",", "."))
    got = (g[0], g[1], None, g[3], g[4])
    if any(x is not None and x != y for x, y in zip(exp, got)):
        bad.append((n, got, exp))
print(f"Selbstpruefung HTML-Tabelle: {len(found)}/{len(rows)} Zeilen gefunden, {len(bad)} Abweichungen")
for b in bad[:6]:
    print("  ABWEICHUNG:", b)
assert len(found) == len(rows) and not bad, "HTML-Tabelle stimmt nicht mit der CSV ueberein"

# Sterne-Tabelle gegenpruefen
stars_csv = list(_csv.DictReader(open(f"{ROOT}/out_stars.csv", encoding="utf-8-sig")))
assert len(star_rows) == len(stars_csv) == 11, "Sterne-Tabelle unvollstaendig"
print("Sterne-Tabelle: 11/11 Zeilen - OK")
# Zahlentest: englische Trenner duerfen nicht mehr vorkommen
_leftover = _re.findall(r"(?<![\w.])(\d{1,3},\d{3})(?![\d])", HTML)
assert not _leftover, f"englische Tausendertrenner uebrig: {_leftover[:5]}"
for _k in ("3.495", "3.363", "82.657", "380.697"):
    assert _k in HTML, f"Kernzahl {_k} fehlt im HTML"
print("Zahlenformat deutsch + Kernzahlen 3.495 / 3.363 / 82.657 / 380.697 - OK")
print("report.html geschrieben:", len(HTML), "Zeichen - verifiziert")
